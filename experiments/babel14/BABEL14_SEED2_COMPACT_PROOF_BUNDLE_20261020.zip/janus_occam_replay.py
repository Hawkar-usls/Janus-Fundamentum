#!/usr/bin/env python3
"""Rebuild JANUS frozen SCL-126 controls; replay the Occam core without imports from old verifiers."""

import csv
import hashlib
import json
from collections import deque
from pathlib import Path

from janus_occam_solver import solve, gf2_kernel, kernel_search, syndrome_search


EXPECTED_SHA = "3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899"
FIXTURES = (
    ("E4.11_SAT2", "1248a49249141249229208a29244a2514524924522524921", 2, 111),
    ("E4.11_UNSAT", "f3f8bcef56c536a5d5a2a6967e9947a803340bba408e0c5", 0, 111),
    ("E4.12b_MULTI_Z_SAT4", "1248a49249141249229209aa9244a65145a5b24d26534960", 4, 110),
)


def source_triples(path):
    data = Path(path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == EXPECTED_SHA
    full = [[int(c) for c in row] for row in csv.reader(data.decode().splitlines())]
    assert len(full) == 126 and all(len(row) == 126 for row in full)
    colors = [-1] * 126
    colors[0] = 0
    queue = deque([0])
    while queue:
        a = queue.popleft()
        for b in range(126):
            if not full[a][b]:
                continue
            if colors[b] == -1:
                colors[b] = colors[a] ^ 1
                queue.append(b)
            else:
                assert colors[a] != colors[b]
    left = [i for i in range(126) if colors[i] == 0]
    right = [i for i in range(126) if colors[i] == 1]
    assert len(left) == len(right) == 63
    return [tuple(j for j, v in enumerate(right) if full[i][v]) for i in left]


def cover(triples, mask_hex):
    voltage = int(mask_hex, 16)
    shifts = {}
    edge = 0
    for i, triple in enumerate(triples):
        for j in triple:
            shifts[i, j] = (voltage >> edge) & 1
            edge += 1
    assert edge == 189 and voltage >> edge == 0
    return [[j + 63 * (sheet ^ shifts[i, j]) for j in triple]
            for sheet in (0, 1) for i, triple in enumerate(triples)]


def main():
    triples = source_triples(Path(__file__).with_name("tutte12.am.csv"))
    result = {}
    for name, mask, expected_count, expected_rank in FIXTURES:
        instance = cover(triples, mask)
        got = solve(instance, 126, count_all=True)
        assert (got["exact_count"], got["rank"], got["status"]) == (
            expected_count, expected_rank, "SAT" if expected_count else "UNSAT")
        result[name] = got

    # Additional unit test: the alternative syndrome DP exactly matches Gray
    # enumeration on arbitrary homogeneous 4-column matrices of every rank.
    total_checks = 0
    for a in range(1 << 4):
        for b in range(1 << 4):
            rows = [a, b]
            row_basis, kernel = gf2_kernel(rows, 4)
            for t in range(5):
                count_gray, _, _ = kernel_search(kernel, t, True)
                count_dp, _, _ = syndrome_search(row_basis, 4, t, True)
                assert count_gray == count_dp
                total_checks += 1
    result["DP_vs_Gray_on_all_2x4_matrices_and_weights"] = total_checks
    result["source_csv_sha256"] = EXPECTED_SHA
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
