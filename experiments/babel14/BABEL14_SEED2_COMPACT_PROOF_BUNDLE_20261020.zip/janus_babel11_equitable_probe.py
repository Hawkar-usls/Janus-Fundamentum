#!/usr/bin/env python3
"""Diagnostic only: equitable refinement of the SOS4 Fourier normal graph.

If an exact equitable partition into <=m cells exists and mod-p Krylov
dimension equals m with nonzero constant, then Q membership follows via
invertibility of the integer operator on the rational cell-constant subspace.
This probe reports refinement growth, not a proof unless stabilized.
"""

import argparse
import json
import time
from collections import defaultdict
from pathlib import Path

from janus_babel8_krylov_exact import matrices


def refine(bit=94, max_rounds=10, threshold=6000):
    _, matrix, transpose, _, _=matrices(bit)
    C=(matrix @ transpose).tocsr()
    n=C.shape[0]
    colors=[int(i!=0) for i in range(n)]
    records=[]
    start=time.monotonic()
    for round_index in range(1,max_rounds+1):
        signatures=[]
        for i in range(n):
            weighted=defaultdict(int)
            for pos in range(C.indptr[i],C.indptr[i+1]):
                weighted[colors[C.indices[pos]]]+=int(C.data[pos])
            signatures.append((colors[i],tuple(sorted(weighted.items()))))
        dictionary={}
        updated=[]
        for signature in signatures:
            updated.append(dictionary.setdefault(signature,len(dictionary)))
        count=len(dictionary)
        records.append({'round':round_index,'cells':count,
                        'seconds':round(time.monotonic()-start,2)})
        print(json.dumps(records[-1],sort_keys=True),flush=True)
        if updated==colors:
            return {'stabilized':True,'cell_count':count,'rounds':records}
        colors=updated
        if count>threshold:
            return {'stabilized':False,'over_threshold':True,
                    'cell_count':count,'rounds':records}
    return {'stabilized':False,'cell_count':len(set(colors)),
            'rounds':records}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bit',type=int,default=94)
    p.add_argument('--max-rounds',type=int,default=10)
    p.add_argument('--threshold',type=int,default=6000)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_BIT94_EQUITABLE_PROBE.json'))
    a=p.parse_args()
    result=refine(a.bit,a.max_rounds,a.threshold)
    result['flipped_edge_index']=a.bit
    result['status']='STRUCTURAL_DIAGNOSTIC_ONLY'
    a.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
