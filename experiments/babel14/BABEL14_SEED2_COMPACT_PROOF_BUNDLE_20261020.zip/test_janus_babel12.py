#!/usr/bin/env python3
"""Independent exact regression tests for BABEL-12 active-only construction."""

import json
import os
import unittest
from pathlib import Path

import numpy as np

from janus_babel10_degree_scan import frozen_instances
from janus_babel12_active_normal import active_normal, refine
from janus_babel12_sparse_oracle import brute_component, explore_zero


class TestBabel12(unittest.TestCase):
    def test_tiny_cyclic_independent_brute(self):
        rows=[[i,(i+1)%21,(i+5)%21] for i in range(21)]
        for ell in (0,1,2):
            state=explore_zero(rows,ell,include_vertices=True)
            assert set(state['vertices'])==brute_component(rows,ell)
            support,C,meta=active_normal(rows,ell)
            assert meta['active_frequencies']==len(state['vertices'])
            assert len(support)==len(state['vertices'])
            assert int(C[0,0])==meta['distinct_planes']

    def test_exact_scl126_active_equitable_quotient(self):
        rows=frozen_instances()['SCL126_flip68']
        state=explore_zero(rows,2,include_vertices=True)
        frequencies,C,meta=active_normal(rows,2)
        assert meta['active_frequencies']==20464
        assert meta['unique_affine_plane_cosets']==162837
        assert list(frequencies)==state['vertices']
        assert state['zero_incidence_component_cosets']==162837
        _,history=refine(C,4)
        assert history[-1]['stable'] and history[-1]['cells']==556

    def test_ambient_scl126_independent_exact_equality(self):
        from janus_babel8_krylov_exact import matrices
        rows=frozen_instances()['SCL126_flip68']
        frequency,C,meta=active_normal(rows,2)
        _,mat,transpose,_,_=matrices(68)
        full=(mat@transpose).tocsr()
        assert full.shape==(32768,32768)
        reduced=full[frequency,:][:,frequency].tocsr()
        assert (reduced-C).nnz==0
        diagonal=np.array(full.diagonal())
        assert np.count_nonzero(diagonal)==len(frequency)
        assert np.all(diagonal[frequency]>0)

    @unittest.skipUnless(os.getenv('BABEL12_DEEP')=='1','enable BABEL12_DEEP=1')
    def test_scl252_frozen_support_replay(self):
        rows=frozen_instances()['SCL252_seed0']
        state=explore_zero(rows,2,include_vertices=True)
        freq,C,meta=active_normal(rows,2)
        assert meta['active_frequencies']==81313
        assert meta['unique_affine_plane_cosets']==1454182
        assert list(freq)==state['vertices']
        assert state['zero_incidence_component_cosets']==1454182
        _,history=refine(C,4)
        assert history[-1]['stable'] and history[-1]['cells']==50692


if __name__=='__main__':unittest.main()
