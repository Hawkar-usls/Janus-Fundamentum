#!/usr/bin/env python3
"""Independent exact OCCAM-2 certificate checker.

Crucially: this checker never constructs the full length-2**d Walsh array,
never evaluates all Walsh scores and never calls the proof generator.
"""

import argparse
import json
from collections import defaultdict
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate


def verify(cert):
    if not __debug__:
        raise RuntimeError('exact verifier must run with assertions enabled (no python -O)')
    if cert.get('format') != 'JANUS_OCCAM2_Walsh_subcube_L1_v1':
        raise ValueError('unknown proof format')
    n = cert['n']
    triples = cert['row_triples']
    rows = validate(triples, n)
    rowspace, basis = gf2_kernel(rows, n)
    d = len(basis)
    assert cert['GF2_rank'] == len(rowspace)
    assert cert['GF2_nullity'] == d
    order = cert['basis_bit_order']
    assert sorted(order) == list(range(d))
    selector = int(cert['witness_selector_hex'], 16)
    assert 0 <= selector < (1 << d)
    word = 0
    for k, v in enumerate(basis):
        if (selector >> k) & 1:
            word ^= v
    assert hex(word) == cert['witness_kernel_word_hex']
    assert all((row & word).bit_count() % 2 == 0 for row in rows)
    target = n - 2 * word.bit_count()
    assert target == cert['minimum_walsh_score']

    # Build only n syndrome column labels, never a 2**d Fourier vector.
    q_columns = []
    for col in range(n):
        q_columns.append(sum(((v >> col) & 1) << k
                             for k, v in enumerate(basis)))
    assert target == sum(1 if not ((q & selector).bit_count() & 1) else -1
                         for q in q_columns)

    paths = cert['proof_leaves']
    assert len(paths) == cert['leaf_count']
    trie = {}
    coverage = 0
    worst_leaf_bound = None
    for path, asserted_bound in paths:
        assert isinstance(path, str) and len(path) <= d
        assert set(path) <= {'0', '1'}
        node = trie
        for sign in path:
            assert '#' not in node, 'an ancestor is already a leaf'
            node = node.setdefault(sign, {})
        assert not node, 'duplicate leaf or a prior descendant'
        node['#'] = True
        coverage += 1 << (d - len(path))

        # Recompute a_r from scratch, directly from column syndromes and
        # fixed signs, without importing any generator recurrence.
        selected = sum((1 << order[pos]) for pos, s in enumerate(path) if s == '1')
        assigned = sum(1 << order[pos] for pos in range(len(path)))
        grouped = defaultdict(int)
        for q in q_columns:
            free_q = q & ~assigned
            grouped[free_q] += -1 if (q & selected).bit_count() % 2 else 1
        a0 = grouped.get(0, 0)
        lower = a0 - sum(abs(value) for q, value in grouped.items() if q)
        assert asserted_bound == lower
        assert lower >= target, (path, lower, target)
        worst_leaf_bound = lower if worst_leaf_bound is None else min(worst_leaf_bound, lower)

    assert coverage == (1 << d), 'incomplete partition of selectors'
    assert coverage == cert['states_covered_symbolically']
    assert len(paths) >= 1
    return {
        'status': 'PROVED_EXACT_OPTIMUM',
        'n': n, 'rank': len(rowspace), 'nullity': d,
        'minimum_walsh_score': target,
        'maximum_kernel_weight': word.bit_count(),
        'minimum_defect': n - 3 * word.bit_count() // 2,
        'leaf_count': len(paths),
        'states_covered_symbolically': coverage,
        'least_subcube_bound': worst_leaf_bound,
        'individual_scores_tested': 1,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate', type=Path)
    args = parser.parse_args()
    result = verify(json.loads(args.certificate.read_text()))
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
