#!/usr/bin/env python3
"""Exact no-go theorem for BABEL's global rank-2/triangle LP relaxation.

For SCL with no zero GF(2)-kernel column syndromes, *all* triangle-local
convex constraints admit the uniform pseudo-character value -1/3. The
weighted objective is precisely -n/3, regardless of exact SAT status.
"""

import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def exact_rank2_barrier(triples):
    rows = validate(triples, len(triples))
    n = len(rows)
    _, kernel = gf2_kernel(rows, n)
    q = columns_of_kernel(kernel, n)
    if 0 in q:
        raise ValueError('the uniform nonzero-character argument requires B1=0')
    multiplicities = Counter(q)
    assert sum(multiplicities.values()) == n
    for row in rows:
        cols = [j for j in range(n) if (row >> j) & 1]
        assert len(cols) == 3
        a,b,c = (q[j] for j in cols)
        assert a and b and c and len({a,b,c}) == 3 and a ^ b ^ c == 0

    pseudo = Fraction(-1, 3)
    # The four facets of the convex hull of sign triples with product +1.
    facets = [(1,1,1), (1,-1,-1), (-1,1,-1), (-1,-1,1)]
    assert all(sum(sign*pseudo for sign in signs) >= -1 for signs in facets)
    pseudo_objective = sum(mult*pseudo for mult in multiplicities.values())
    assert pseudo_objective == Fraction(-n, 3)
    # Summing the first facet for each SCL row: every column is counted
    # three times, so 3*objective >= -n. Thus the pseudo point is optimal.
    assert sum(row.bit_count() for row in rows) == 3*n
    assert 3*pseudo_objective == -n
    return {'n': n, 'nullity': len(kernel),
            'number_of_constraints_from_rows': n,
            'nonzero_syndrome_types': len(multiplicities),
            'uniform_pseudo_character': '-1/3',
            'all_four_rank2_facets': 'PASS',
            'rank2_local_LP_optimum_exact': f'-{n}/3',
            'rank2_optimum_integer_if_divisible3': -n//3 if n%3==0 else None,
            'proof': 'uniform feasible point + sum of original row inequalities'}


def main():
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    result = {'SCL63': exact_rank2_barrier(source)}
    for name, mask, _, _ in FIXTURES[:2]:
        result[name] = exact_rank2_barrier(cover(source, mask))
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
