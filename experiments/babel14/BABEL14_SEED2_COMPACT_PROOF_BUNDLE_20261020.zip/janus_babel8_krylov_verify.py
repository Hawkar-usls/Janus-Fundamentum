#!/usr/bin/env python3
"""Independent exact-integer verification of compact BABEL-8 degree-4 SOS.

No finite-field, Krylov-discovery, linear-solver, floating-point or SDP
library is imported here. The 245-step integer recurrence itself is replayed.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from math import gcd
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate


def input_data(bit=16):
    csv = Path(__file__).with_name('tutte12.am.csv')
    source = source_triples(csv)
    covered = cover(source, format(int(FIXTURES[1][1], 16) ^ (1 << bit), 'x'))
    _, kernel = gf2_kernel(validate(covered, 126), 126)
    assert len(kernel) == 15
    labels = [sum(((word >> j) & 1) << k
                  for k, word in enumerate(kernel)) for j in range(126)]
    basis = {0, *labels}
    for a in labels:
        for b in labels:
            basis.add(a ^ b)
    basis = sorted(basis)
    assert 0 < len(basis) <= 126 * 127 // 2 + 1
    origins = {}
    for r, triple in enumerate(covered):
        a, b, c = (labels[i] for i in triple)
        assert a ^ b ^ c == 0
        for u in basis:
            foursome = tuple(sorted((u, u ^ a, u ^ b, u ^ c)))
            assert len(set(foursome)) == 4
            origins.setdefault(foursome, (r, u))
    eq = sorted(origins)
    return covered, labels, basis, eq, origins


def normal(vector, equations):
    out = [0] * 32768
    for a, b, c, d in equations:
        t = vector[a] + vector[b] + vector[c] + vector[d]
        if t:
            out[a] += t
            out[b] += t
            out[c] += t
            out[d] += t
    return out


def verify(proof_path, output=None):
    document = json.loads(Path(proof_path).read_text())
    assert document['format'] == 'BABEL8_INTEGER_KRYLOV_DEGREE4_CERTIFICATE_V1'
    assert document['CRT_modulus_exceeds_twice_coefficient_bound'] is True
    polynomial = document['polynomial_coefficients_low_to_high']
    assert len(polynomial) >= 2 and polynomial[-1] == 1
    assert all(type(c) is int for c in polynomial)
    assert polynomial[0] != 0
    flip = document.get('flipped_base_edge_index', 16)
    assert 0 <= flip < 189
    covered, labels, basis, equations, origins = input_data(flip)
    assert document['number_of_distinct_row_products'] == len(equations)
    assert document['degree2_fourier_basis_size'] == len(basis)

    # Evaluate Q(C)e0, where Q(t)=(P(t)-P(0))/t, entirely over Z.
    vec = [0] * 32768
    for k, coefficient in enumerate(reversed(polynomial[1:])):
        vec = normal(vec, equations)
        vec[0] += coefficient
        if (k + 1) % 50 == 0:
            print(json.dumps({'exact_horner_steps': k + 1,
                              'total_horner_steps': len(polynomial) - 1}),
                  flush=True)
    result = normal(vec, equations)
    assert result[0] == -polynomial[0]
    assert all(v == 0 for v in result[1:]), 'exact P(C)e_0 recurrence FAIL'

    sign = -1 if polynomial[0] > 0 else 1
    D = abs(polynomial[0])
    row_l1 = [0] * 126
    nonzero_terms = 0
    coefficient_gcd = D
    for a, b, c, d in equations:
        y = sign * (vec[a] + vec[b] + vec[c] + vec[d])
        if y:
            origin = origins[(a, b, c, d)]
            row_l1[origin[0]] += abs(y)
            nonzero_terms += 1
            coefficient_gcd = gcd(coefficient_gcd, abs(y))
    C = sum(x * x for x in row_l1)
    assert C > 0
    gap = Fraction(D * D, 12 * C)
    assert gap > 0
    report = {'status': 'BABEL8_EXACT_DEGREE4_RATIONAL_SOS_PASS',
              'instance': f'balanced_UNSAT_SCL126_flip{flip}',
              'degree2_multiplier_fourier_basis': len(basis),
              'moment_matrix_dimension': len(basis),
              'normal_operator_dim': 32768,
              'integer_normal_operator_terms': len(equations),
              'recurrence_degree': len(polynomial) - 1,
              'nonzero_integer_dual_multipliers': nonzero_terms,
              'integer_normalization_D': str(D),
              'integer_row_norm_upper_C': str(C),
              'common_factor_of_dual_coefficients': str(coefficient_gcd),
              'strict_gap_numerator': str(gap.numerator),
              'strict_gap_denominator': str(gap.denominator),
              'certificate_sha256': hashlib.sha256(
                  Path(proof_path).read_bytes()).hexdigest(),
              'exact_integer_frequency_replay': 'PASS',
              'rational_SOS_degree': 4}
    if output:
        Path(output).write_text(json.dumps(report, indent=2,
                                           sort_keys=True) + '\n')
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('proof', type=Path)
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    report = verify(args.proof, args.output)
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ('integer_row_norm_upper_C',
                                   'integer_normalization_D',
                                   'strict_gap_numerator',
                                   'strict_gap_denominator',
                                   'common_factor_of_dual_coefficients')},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
