#!/usr/bin/env python3
"""BABEL-1 tests for universal legality, exactness and proof tamper safety."""

import copy
import json
from pathlib import Path

from janus_occam_replay import source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_babel1_solver import certified_minimum
from janus_babel1_verify import verify


def nine_point_scl():
    triples = []
    for i in range(3):
        triples.append([3*i+j for j in range(3)])
    for j in range(3):
        triples.append([3*i+j for i in range(3)])
    for k in range(3):
        triples.append([3*i+j for i in range(3) for j in range(3)
                        if (i+j) % 3 == k])
    return triples


def must_reject(cert):
    try:
        verify(cert)
    except (AssertionError, ValueError, KeyError, TypeError):
        return
    raise AssertionError('checker accepted a corrupted proof')


def main():
    nine = nine_point_scl()
    _, k9 = gf2_kernel(validate(nine, 9), 9)
    proof9 = certified_minimum(nine)
    nine_audit = verify(proof9)
    assert nine_audit['minimum_F'] == -3
    assert nine_audit['minimum_violated_rows'] == 0
    all_scores = []
    for c in range(1 << len(k9)):
        word = 0
        for i, basisword in enumerate(k9):
            if c & (1 << i):
                word ^= basisword
        all_scores.append(9 - 2*word.bit_count())
    assert min(all_scores) == nine_audit['minimum_F']

    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    source_proof = certified_minimum(source)
    source_audit = verify(source_proof)
    assert (source_audit['nullity'], source_audit['minimum_F'],
            source_audit['maximum_kernel_weight']) == (14, -17, 40)

    damaged = copy.deepcopy(source_proof)
    damaged['proof_leaves'][0][1] += 2
    must_reject(damaged)
    damaged = copy.deepcopy(source_proof)
    damaged['proof_leaves'].pop()
    damaged['proof_leaf_count'] -= 1
    must_reject(damaged)
    damaged = copy.deepcopy(source_proof)
    damaged['witness_selector_hex'] = hex(int(damaged['witness_selector_hex'], 16) ^ 1)
    must_reject(damaged)
    damaged = copy.deepcopy(source_proof)
    for leaf in damaged['proof_leaves']:
        if leaf[2]:
            leaf[2][0][2] ^= 1
            break
    else:
        raise AssertionError('test did not find a populated XOR triple')
    must_reject(damaged)

    print(json.dumps({'SCL_9_SAT': nine_audit,
                      'SCL_63_UNSAT': source_audit,
                      'tamper_rejections': 4,
                      'SCL_9_exhaustive_crosscheck': 'PASS',
                      'search_evaluated_scores_SCL63':
                          source_proof['individual_score_evaluations_during_search']},
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
