#!/usr/bin/env python3
"""Exactly check a sparse rational rank-three pseudomodel (NO scipy).

Observed q -> -1/3; q missing from some 5-observed rank3 plane -> +1/3;
all other q -> 0. The checker checks *every* rank3 plane containing at least
three observed frequencies, hence is a rigorous finite countermodel for
that precisely scoped root-level LP if all inequalities pass.
"""

import json
from collections import Counter
from itertools import combinations
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def all_root_planes(observed):
    support=sorted(observed)
    result=set()
    for a,b,c in combinations(support,3):
        if a^b==c:
            continue
        space=(a,b,c,a^b,a^c,b^c,a^b^c)
        result.add(tuple(sorted(space)))
    return sorted(result)


def exact_dense5_pseudo(triples):
    """Exact feasible point for all five-observed planes + observed triples."""
    rows=validate(triples,len(triples))
    n=len(rows)
    _,basis=gf2_kernel(rows,n)
    observed=set(columns_of_kernel(basis,n))
    assert 0 not in observed
    dense=[p for p in all_root_planes(observed)
           if sum(q in observed for q in p)==5]
    positive={q for p in dense for q in p if q not in observed}
    minimum=100
    tested=0
    for p in dense:
        span={0:0}
        for q in p:
            if q not in span:
                k=(len(span)).bit_length()-1
                span.update({v^q:m|(1<<k) for v,m in list(span.items())})
        assert len(span)==8
        for z in range(8):
            numerator=3+sum((-1 if q in observed else 1 if q in positive else 0)
                            *(-1 if (mask&z).bit_count()&1 else 1)
                            for q,mask in span.items() if q)
            minimum=min(minimum,numerator)
            tested+=1
            if numerator<0:
                raise AssertionError((p,z,numerator))
    triangles=set()
    for p,q in combinations(sorted(observed),2):
        r=p^q
        if r in observed:
            triangles.add(tuple(sorted((p,q,r))))
    for p,q,r in triangles:
        for signs in ((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)):
            assert 3-sum(signs)>=0
    return {'status':'EXACT_DENSE5_RANK3_PSEUDOMODEL_FEASIBLE',
            'n':n,'nullity':len(basis),'observed_frequencies':len(observed),
            'positive_auxiliary_frequencies':len(positive),
            'dense_rank3_planes_checked':len(dense),
            'rank3_probability_inequalities_checked':tested,
            'observed_rank2_facets_checked':4*len(triangles),
            'min_24_times_probability':minimum,
            'objective':f'-{n}/3'}


def exact_sparse_pseudo(triples):
    rows=validate(triples,len(triples))
    n=len(rows)
    _,basis=gf2_kernel(rows,n)
    observed=set(columns_of_kernel(basis,n))
    assert 0 not in observed
    planes=all_root_planes(observed)
    rich_planes=[p for p in planes if sum(q in observed for q in p)==5]
    positive={q for p in rich_planes for q in p if q not in observed}
    assert not observed.intersection(positive)
    t=Counter(sum(q in observed for q in p) for p in planes)
    # Check *every* rank-two local marginal facet involving nonzero pseudo
    # moments. Triples with fewer than three nonzero moments are automatic.
    nonzero=sorted(observed|positive)
    nonzero_set=set(nonzero)
    rank2_checked=0
    rank2_violation=None
    for p,q in combinations(nonzero,2):
        r=p^q
        if r<=q or r not in nonzero_set:
            continue
        moments=[-1 if v in observed else 1 for v in (p,q,r)]
        for signs in ((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)):
            rank2_checked+=1
            if 3+sum(v*s for v,s in zip(moments,signs))<0:
                rank2_violation={'syndromes':[p,q,r],'facet':signs}
                break
        if rank2_violation:
            break
    minimum_margin=None
    tested=0
    violation=None
    for p in planes:
        # Reconstruct rank-three basis from any independent observed triple
        # (the first sorted 3 can be dependent, so select via span).
        span={0:0}
        for q in p:
            if q not in span:
                k=(len(span)).bit_length()-1
                span.update({v^q:pattern|(1<<k) for v,pattern in list(span.items())})
        assert len(span)==8
        for z in range(8):
            # 24 * Pr[z] = 3 + sum_q (3*s_q) * chi_q(z).
            numerator=3+sum((-1 if q in observed else 1 if q in positive else 0)
                            * (-1 if (mask&z).bit_count()&1 else 1)
                            for q,mask in span.items() if q)
            minimum_margin=numerator if minimum_margin is None else min(minimum_margin,numerator)
            tested+=1
            if numerator<0:
                violation={'plane':list(p),'z':z,'24_times_probability':numerator}
                break
        if violation:
            break
    status=('EXACT_RANK3_PSEUDOMODEL_FEASIBLE'
            if violation is None and rank2_violation is None
            else 'RANK3_PSEUDOMODEL_REJECTED')
    objective_numerator=-sum(1 for q in columns_of_kernel(basis,n))
    return {'status':status,'n':n,'d':len(basis),'observed_nonzero_syndromes':len(observed),
            'pseudo_neg_one_third_syndromes':len(observed),
            'pseudo_pos_one_third_syndromes':len(positive),
            'all_other_syndromes_assigned_zero':True,
            'rank3_planes_containing_at_least_three_observed':len(planes),
            'root_plane_occupancy':dict(sorted(t.items())),
            'all_rank2_facets_on_nonzero_pseudo_support_checked':rank2_checked,
            'rank2_first_violation':rank2_violation,
            'rank3_local_probabilities_checked':tested,
            'minimum_24_times_probability':minimum_margin,
            'root_objective':f'{objective_numerator}/3',
            'first_violation':violation}


def main():
    root=Path(__file__).resolve().parent
    source=source_triples(root/'tutte12.am.csv')
    result={'SCL63':exact_sparse_pseudo(source)}
    result['SCL63_DENSE5']=exact_dense5_pseudo(source)
    for name,mask,_,_ in FIXTURES[:2]:
        lifted=cover(source,mask)
        result[name]=exact_sparse_pseudo(lifted)
        result[name+'_DENSE5']=exact_dense5_pseudo(lifted)
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
