#!/usr/bin/env python3
"""Exact low-degree identity for the non-diagonal sector of UNSAT SCL126.

For a base variable i, its two cover frequencies differ either by zero or
by one common extra frequency e. The 40 differing variables form a cubic
signed graph induced by 60 rows with two differing variables.  A negative
signed cycle yields an exact group-algebra identity certifying
chi_e == +1 whenever all lifted Exact-One row defects vanish.
"""

import argparse
import json
from collections import defaultdict,deque
from pathlib import Path

from janus_babel5_kernel import source_data
from janus_babel5_projection import linear_projection
from janus_occam_replay import source_triples


def build_signed_edges():
    full,labels,_,_=source_data()
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    split={i for i in range(63) if labels[i]!=labels[i+63]}
    assert len(split)==40
    graph=defaultdict(list)
    edges={}
    for r,base_row in enumerate(source):
        two=sorted(split.intersection(base_row))
        assert len(two) in (0,2)
        if not two:
            continue
        a,b=two
        signs={}
        for j in two:
            selected=next(c for c in full[r] if c%63==j)
            assert labels[selected] in (labels[j],labels[j+63])
            signs[j]=1 if labels[selected]==labels[j] else -1
        relation=-signs[a]*signs[b]
        edges[r]={'source_row':r,'a':a,'b':b,
                  'sa':signs[a],'sb':signs[b],
                  'relation':relation}
        graph[a].append((b,r,relation))
        graph[b].append((a,r,relation))
    assert len(edges)==60 and len(graph)==40
    return full,labels,graph,edges,split


def negative_cycle(graph):
    assigned={}
    parent={}
    depth={}
    for root in sorted(graph):
        if root in assigned:
            continue
        assigned[root]=1
        parent[root]=(None,None)
        depth[root]=0
        todo=deque([root])
        while todo:
            u=todo.popleft()
            for v,r,ratio in sorted(graph[u]):
                predicted=assigned[u]*ratio
                if v not in assigned:
                    assigned[v]=predicted
                    parent[v]=(u,r)
                    depth[v]=depth[u]+1
                    todo.append(v)
                elif assigned[v]!=predicted:
                    # Path from u to v through the tree, then conflicting edge.
                    up=[]
                    down=[]
                    a,b=u,v
                    while depth[a]>depth[b]:
                        up.append((a,parent[a][1],parent[a][0]))
                        a=parent[a][0]
                    while depth[b]>depth[a]:
                        down.append((parent[b][0],parent[b][1],b))
                        b=parent[b][0]
                    while a!=b:
                        up.append((a,parent[a][1],parent[a][0]))
                        down.append((parent[b][0],parent[b][1],b))
                        a=parent[a][0]
                        b=parent[b][0]
                    path=up+list(reversed(down))+[(v,r,u)]
                    assert path[0][0]==u and path[-1][2]==u
                    assert all(path[j][2]==path[j+1][0]
                               for j in range(len(path)-1))
                    return path
    raise AssertionError('No negative signed cycle found')


def cycle_certificate():
    full,labels,graph,edges,split=build_signed_edges()
    path=negative_cycle(graph)
    start=path[0][0]
    coefficients=[]
    previous=None
    for i,(u,row,v) in enumerate(path):
        edge=edges[row]
        sign_u=edge['sa'] if u==edge['a'] else edge['sb']
        sign_v=edge['sa'] if v==edge['a'] else edge['sb']
        if i==0:
            lam=sign_u
        else:
            lam=-previous*sign_u
        previous=lam*sign_v
        coefficients.append(lam)
    assert coefficients[0] in (-1,1) and previous==1
    # Verify sum lambda_e (g_{row,0}-g_{row,1}) * chi_start
    # == 2*(1-chi_extra) in the full 15D group algebra.
    expansion=defaultdict(int)
    ref=labels[start]
    for (_,r,_),lam in zip(path,coefficients):
        for sheet,row_sign in ((0,1),(1,-1)):
            row_index=r+63*sheet
            for term in (0,*(labels[j] for j in full[row_index])):
                expansion[ref^term]+=lam*row_sign
    _,extra,_=linear_projection()
    assert expansion.get(0,0)==2 and expansion.get(extra,0)==-2
    assert all(x==0 for q,x in expansion.items() if q not in (0,extra))
    return {'format':'BABEL5_EXACT_SIGNED_CYCLE_SECTOR_MINUS_V1',
        'source':'UNSAT126','cycle_length':len(path),'start_split_var':start,
        'extra_frequency':extra,
        'oriented_edges':[{'from':u,'row':r,'to':v,'lambda':lam}
                          for (u,r,v),lam in zip(path,coefficients)],
        'identity':'chi_start*sum(lambda*(g_row0-g_row1))=2*(1-chi_extra)',
        'Fourier_coefficient_checks':1<<15,
        'status':'EXACT_BOOLEAN_GROUP_IDENTITY_VERIFIED'}


def anchor_identities():
    """For all 40 split columns i: sum mu[i,r]*(g_r0-g_r1)=4 P_- chi_i."""
    full,labels,graph,edges,split=build_signed_edges()
    record=cycle_certificate()
    root=record['start_split_var']
    root_coeff=defaultdict(int)
    for edge in record['oriented_edges']:
        root_coeff[edge['row']]+=edge['lambda']
    relations={root:dict(root_coeff)}
    todo=deque([root])
    while todo:
        u=todo.popleft()
        for v,r,_ in graph[u]:
            if v in relations:
                continue
            edge=edges[r]
            su=edge['sa'] if u==edge['a'] else edge['sb']
            sv=edge['sa'] if v==edge['a'] else edge['sb']
            vals=defaultdict(int)
            for row,a in relations[u].items():
                vals[row]-=su*sv*a
            vals[r]+=2*sv
            relations[v]={row:a for row,a in vals.items() if a}
            todo.append(v)
    assert len(relations)==len(split)==40
    extra=record['extra_frequency']
    for i,coefficients in relations.items():
        expansion=defaultdict(int)
        for row,c in coefficients.items():
            for sheet,sign in ((0,1),(1,-1)):
                for q in (0,*(labels[j] for j in full[row+63*sheet])):
                    expansion[q]+=c*sign
        assert expansion.get(labels[i],0)==2
        assert expansion.get(labels[i]^extra,0)==-2
        assert all(a==0 for q,a in expansion.items()
                   if q not in (labels[i],labels[i]^extra))
    return relations


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    outcome=cycle_certificate()
    if args.output:
        args.output.write_text(json.dumps(outcome,indent=2,sort_keys=True)+'\n')
    print(json.dumps(outcome,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
