#!/usr/bin/env python3
"""BABEL-10: deterministic connected 2-lifts of frozen UNSAT SCL-126.

Exact GF(2) kernel size, connectivity and Exact-One enumeration are verified
before any conclusions about SOS degree are drawn. No extrapolation from a
finite sample is claimed.
"""

import argparse
import hashlib
import json
import random
from collections import deque
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_occam_solver import gf2_kernel, kernel_search, validate


def make_lift(rows, seed):
    n = len(rows)
    rng = random.Random(seed)
    voltage = [rng.getrandbits(1) for _ in range(3 * n)]
    result = [[] for _ in range(2 * n)]
    offset = 0
    for i, triple in enumerate(rows):
        for sheet in (0, 1):
            result[i + sheet * n] = [j + n * (sheet ^ voltage[offset + k])
                                     for k, j in enumerate(triple)]
        offset += 3
    validate(result, 2 * n)
    return result, voltage


def connected_incidence(rows):
    n = len(rows)
    adjacency = [[] for _ in range(2 * n)]
    for i, triple in enumerate(rows):
        for j in triple:
            adjacency[i].append(n + j)
            adjacency[n + j].append(i)
    seen = {0}
    queue = deque([0])
    while queue:
        for v in adjacency[queue.popleft()]:
            if v not in seen:
                seen.add(v)
                queue.append(v)
    return len(seen) == 2 * n


def audit(name, rows, seed, max_nullity=20):
    lifted, voltage = make_lift(rows, seed)
    assert connected_incidence(lifted)
    _, kernel = gf2_kernel(validate(lifted, len(lifted)), len(lifted))
    nullity = len(kernel)
    result = {'instance': f'{name}_sheet2_seed{seed}',
              'source_rows': len(rows), 'lift_rows': len(lifted),
              'incidence_vertices': 2 * len(lifted),
              'random_seed': seed,
              'voltage_bits_sha256': hashlib.sha256(
                  bytes(voltage)).hexdigest(),
              'legal_linear_cubic': True,
              'connected': True,
              'GF2_nullity': nullity,
              'GF2_rank': len(lifted) - nullity}
    if nullity <= max_nullity:
        count, witness, visited = kernel_search(
            kernel, 2 * len(lifted) // 3, True)
        result.update({'exact_SAT_count': count,
                       'checked_kernel_states': visited,
                       'status': 'SAT' if count else 'UNSAT'})
    else:
        result.update({'exact_SAT_count': None,
                       'checked_kernel_states': None,
                       'status': 'UNVERIFIED_RESOURCE_LIMIT'})
    return result, lifted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', default='SCL126_flip68')
    parser.add_argument('--seeds', type=int, nargs='+', default=[0, 1, 2, 3])
    parser.add_argument('--output', type=Path,
                        default=Path('babel10_CONNECTED_SCL252_AUDIT.json'))
    parser.add_argument('--freeze-seed', type=int, default=0)
    args = parser.parse_args()
    source = frozen_instances()[args.source]
    result = []
    for seed in args.seeds:
        report, rows = audit(args.source, source, seed)
        result.append(report)
        if seed == args.freeze_seed:
            Path(f'babel10_SCL{len(rows)}_seed{seed}_ROWS.json').write_text(
                json.dumps({'n': len(rows), 'rows': rows,
                            'source': args.source, 'seed': seed},
                           sort_keys=True, separators=(',', ':')) + '\n')
        print(json.dumps(report, sort_keys=True), flush=True)
    args.output.write_text(json.dumps(result, sort_keys=True,
                                      indent=2) + '\n')


if __name__ == '__main__':
    main()
