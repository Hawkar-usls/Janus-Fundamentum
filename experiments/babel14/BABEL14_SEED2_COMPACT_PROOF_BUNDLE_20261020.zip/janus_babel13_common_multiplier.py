#!/usr/bin/env python3
"""BABEL-13: exact universal *instance-specific* rational multiplier.

For a legal 3-regular cubic SCL and a parity codeword v, the number of
all-zero constraint rows equals s(v)=n-3*weight(v)/2. UNSAT means s(v)>0.
Set L=lcm(s(v):v in K); the integer function T(v)=L/s(v) is positive.
Its unnormalized Walsh coefficients H_q obey

    sum_r (1+chi_a+chi_b+chi_c) * sum_q H_q chi_q = 4*L*2**d

pointwise on K. Represent chi_q by coordinate monomials to obtain an exact
rational JANUS Fourier-multiplier identity. This *does not* determine the
minimum possible degree among row-dependent multipliers.
"""

import argparse
import gzip
import hashlib
import json
from collections import Counter
from math import lcm
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import make_lift
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


def fwht(values):
    """Unnormalized exact integral Walsh-Hadamard transform in-place."""
    n=len(values)
    assert n>0 and n&(n-1)==0
    step=1
    while step<n:
        block=step<<1
        for start in range(0,n,block):
            for j in range(start,start+step):
                a,b=values[j],values[j+step]
                values[j],values[j+step]=a+b,a-b
        step=block
    return values


def kernel_weights(labels,d):
    masks=[sum(1<<j for j,v in enumerate(labels) if (v>>k)&1)
           for k in range(d)]
    state=0
    previous=0
    weights=[0]*(1<<d)
    for i in range(1<<d):
        gray=i^(i>>1)
        diff=gray^previous
        if diff:
            state^=masks[diff.bit_length()-1]
        weights[gray]=state.bit_count()
        previous=gray
    return weights


def frozen_rows(seed):
    cases=frozen_instances()
    return cases['SCL252_seed0'] if seed==0 else make_lift(cases['SCL126_flip68'],seed)[0]


def exact_shared_multiplier(rows, max_degree=5, coefficients_path=None):
    n=len(rows)
    rows_digest=hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()
    labels,_,d=xor_labels(rows)
    weights=kernel_weights(labels,d)
    assert all(w%2==0 for w in weights)
    s=[n-3*w//2 for w in weights]
    sat=sum(x==0 for x in s)
    if sat:
        return {'status':'SAT_EXACT_WITNESSES_FOUND','n':n,'nullity':d,
                'sat_count':sat}
    assert min(s)>0
    L=lcm(*set(s))
    t=[L//a for a in s]
    H=fwht(t.copy())
    active=[i for i,v in enumerate(H) if v]
    spectrum={}
    counted=set()
    best=None
    for ell in range(max_degree+1):
        current=set(degree_witnesses(labels,ell))
        subset=[q for q in active if q in current and q not in counted]
        spectrum[ell]=len(subset)
        counted.update(subset)
        if len(counted)==len(active):
            best=ell
            break
    assert best is not None
    # A wholly independent inverse exact Walsh transform proves that
    # the Fourier coefficients specify the intended integer T(v).
    inverse=fwht(H.copy())
    N=1<<d
    assert all(inverse[z]==N*t[z] for z in range(N))
    assert all(4*a*b==4*L for a,b in zip(s,t))
    digest=hashlib.sha256(json.dumps(H,separators=(',',':')).encode()).hexdigest()
    if coefficients_path is not None:
        payload={'format':'BABEL13_EXPLICIT_INTEGER_WALSH_COEFFICIENTS_V1',
                 'SHA256_ordered_rows':rows_digest,'nullity':d,
                 'integer_Fourier_H_sha256':digest,
                 'coefficients_H_by_binary_character':H}
        with gzip.open(coefficients_path,'wt',encoding='utf-8',compresslevel=7) as stream:
            json.dump(payload,stream,separators=(',',':'))
    coefficient_l1=sum(abs(x) for x in H)
    return {'format':'BABEL13_SHARED_MULTIPLIER_INTEGER_FOURIER_V1',
        'status':'EXACT_SHARED_INTEGER_FOURIER_IDENTITY_PASS',
        'SHA256_ordered_rows':rows_digest,
        'n':n,'nullity':d,'complete_parity_states_verified':N,
        'sat_count':0,'bad_row_count_min':min(s),
        'bad_row_count_max':max(s),
        'bad_row_count_histogram':dict(sorted(Counter(s).items())),
        'integer_L_lcm_bad_counts':str(L),
        'L_bit_length':L.bit_length(),
        'integer_normalization_D_equals_4_L_2powd':str(4*L*N),
        'integer_H_total_absolute_coefficient':str(coefficient_l1),
        'largest_H_coefficient_bit_length':max(abs(v).bit_length() for v in H),
        'unnormalized_integer_walsh_support_size':len(active),
        'degree_spectrum_of_nonzero_walsh_coefficients':spectrum,
        'minimal_coordinate_degree_for_this_SHARED_multiplier':best,
        'resulting_JANUS_SOS_degree_upper_bound':2*best,
        'integer_Fourier_H_sha256':digest,
        'exact_pointwise_identity':'SUM_r_g_r(v)*SUM_q_H_q_chi_q(v)=4*L*2^d',
        'exact_inverse_Walsh_identity':'PASS',
        'integer_exact_summand_identity':'PASS',
        'does_not_prove_minimal_degree':True}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--output',type=Path)
    p.add_argument('--coefficients-output',type=Path)
    args=p.parse_args()
    result=exact_shared_multiplier(frozen_rows(args.seed),coefficients_path=args.coefficients_output)
    result['frozen_seed']=args.seed
    if args.output:
        args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in (
        'integer_L_lcm_bad_counts','bad_row_count_histogram')},sort_keys=True),
        flush=True)


if __name__=='__main__':main()
