#!/usr/bin/env python3
"""Modular discovery of a compact exact global SOS dual for BABEL-5.

The integer symmetric operator C=A.T@A has A rows equal to distinct
four-character supports g_r * chi_u.  Its Krylov minimal polynomial at
e0, when its constant term is nonzero, gives an *integer* group-algebra
identity.  Modular Berlekamp-Massey and CRT are discovery tools; the final
integer polynomial is verified by a full exact C-matvec recurrence.
"""

import argparse
import json
from pathlib import Path

from janus_babel5_kernel import equations_and_origins,source_data


PRIMES=(1000000007,1000000009,998244353,1000000021,1000000033,
        1000000087,1000000093,1000000097,1000000103,1000000123,
        1000000181,1000000207,1000000223,1000000241,1000000271,
        1000000289,1000000297,1000000321,1000000349,1000000363,
        1000000403,1000000409,1000000411,1000000427,1000000433,
        1000000439,1000000447,1000000453,1000000459,1000000483)


def berlekamp_massey(sequence,prime):
    c=[1]
    b=[1]
    length=0
    interval=1
    previous_discrepancy=1
    for i,value in enumerate(sequence):
        discrepancy=sum(c[j]*sequence[i-j]
                        for j in range(length+1))%prime
        if not discrepancy:
            interval+=1
            continue
        old=c[:]
        ratio=discrepancy*pow(previous_discrepancy,-1,prime)%prime
        if len(c)<len(b)+interval:
            c+=[0]*(len(b)+interval-len(c))
        for j,t in enumerate(b):
            c[j+interval]=(c[j+interval]-ratio*t)%prime
        if 2*length<=i:
            length=i+1-length
            b=old
            previous_discrepancy=discrepancy
            interval=1
        else:
            interval+=1
    assert len(c)==length+1
    return c


def modular_moments(equations,prime,degree):
    import numpy as np
    from scipy.sparse import csr_matrix
    m=len(equations)
    indices=np.fromiter((q for support in equations for q in support),
                        dtype=np.int32,count=4*m)
    ptr=np.arange(0,4*(m+1),4,dtype=np.int64)
    a=csr_matrix((np.ones(4*m,dtype=np.int64),indices,ptr),
                 shape=(m,32768))
    at=a.transpose().tocsr()
    v=np.zeros(32768,dtype=np.int64)
    v[0]=1
    seq=[]
    for i in range(degree):
        seq.append(int(v[0]))
        v=(at@(a@v))%prime
    return seq


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--moment-count',type=int,default=340)
    p.add_argument('--prime-count',type=int,default=3)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    assert 1<=args.prime_count<=len(PRIMES)
    _,_,defects,basis=source_data()
    eq=equations_and_origins(defects,basis)
    reports=[]
    for prime in PRIMES[:args.prime_count]:
        seq=modular_moments(eq,prime,args.moment_count)
        poly=berlekamp_massey(seq,prime)
        reports.append({'prime':prime,'minimal_polynomial_degree_mod_p':len(poly)-1,
            'nonzero_constant':bool(poly[-1]),
            'constant_mod_p':poly[-1],
            'polynomial_coefficients_mod_p':poly})
        print(json.dumps({k:v for k,v in reports[-1].items()
                          if k!='polynomial_coefficients_mod_p'}),flush=True)
    result={'status':'MODULAR_DISCOVERY_ONLY','moment_sequence_length':args.moment_count,
        'matrix_dimension':2781,'equations':len(eq),'reports':reports}
    if args.output:
        args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':
    main()
