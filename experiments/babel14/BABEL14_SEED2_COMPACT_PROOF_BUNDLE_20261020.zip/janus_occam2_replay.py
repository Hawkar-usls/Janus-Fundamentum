#!/usr/bin/env python3
"""Frozen OCCAM-2 exact UNSAT optimum certificate + independent replay."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import make_certificate, selector_for_word
from janus_occam2_verify import verify


ORDER = [9, 0, 1, 5, 8, 12, 11, 2, 14, 4, 3, 13, 6, 7, 10]
OPTIMUM_WORD = int('2be9ecc9ff8b9765d7d3d993ff172ecb', 16)
SOURCE_SHA256 = '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899'
OUTPUT_FILE = 'JANUS_OCCAM2_UNSAT_L1_certificate_20261018.json'


def main():
    source_path = Path(__file__).with_name('tutte12.am.csv')
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == SOURCE_SHA256
    source = source_triples(source_path)
    name, mask, expected_sat, expected_rank = FIXTURES[1]
    assert (name, expected_sat, expected_rank) == ('E4.11_UNSAT', 0, 111)
    triples = cover(source, mask)
    rows = validate(triples, 126)
    rank_basis, kernel = gf2_kernel(rows, 126)
    assert len(rank_basis) == 111 and len(kernel) == 15
    selector = selector_for_word(kernel, OPTIMUM_WORD)
    certificate = make_certificate(
        triples, selector, ORDER,
        metadata={
            'frozen_fixture': name,
            'mask': mask,
            'tutte12_am_csv_sha256': SOURCE_SHA256,
        })
    assert certificate['witness_kernel_word_hex'] == hex(OPTIMUM_WORD)
    assert certificate['minimum_walsh_score'] == -34
    result = verify(certificate)
    assert result['minimum_defect'] == 6
    assert result['maximum_kernel_weight'] == 80
    target_path = Path(__file__).with_name(OUTPUT_FILE)
    target_path.write_text(json.dumps(certificate, sort_keys=True, indent=1) + '\n')
    result['certificate_path'] = str(target_path)
    result['certificate_sha256'] = hashlib.sha256(target_path.read_bytes()).hexdigest()
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
