#!/usr/bin/env python3
"""Exact independent checker of rank-4 marginal LP *primal* certificates.

This does NOT claim an UNSAT certificate: a feasible rational pseudomoment
vector with objective -n/3 certifies failure of a specified local relaxation
to prove the desired strict gap. No floating-point arithmetic is used by the
verification routine.
"""

import argparse
import hashlib
import json
from collections import Counter
from fractions import Fraction
from functools import reduce
from itertools import combinations
from math import lcm
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel
from janus_babel3_exact_pseudomodel import all_root_planes
from janus_babel4_scan import selected_rank4_planes, basis_patterns, moment_three


HERE=Path(__file__).resolve().parent


def instance_rows(name):
    source=source_triples(HERE/'tutte12.am.csv')
    return source if name=='SCL63' else cover(source,FIXTURES[0 if name=='SAT126' else 1][1])


def chosen_spaces(observed, rank4_limit):
    all3=all_root_planes(observed)
    dense=[p for p in all3 if sum(q in observed for q in p)==5]
    rank4,_=selected_rank4_planes(observed)
    positive={q for p in dense for q in p if q not in observed}
    if rank4_limit:
        rated=[]
        for p in rank4:
            _,span=basis_patterns(p[1:])
            worst=min(3+sum(moment_three(q,observed,positive)
                            *(-1 if (mask&z).bit_count()&1 else 1)
                            for q,mask in span.items() if q)
                      for z in range(16))
            rated.append((worst,p))
        rated.sort()
        rank4=[p for _,p in rated[:rank4_limit]]
    return dense,rank4


def reconstruct_numeric_primal(instance, rank4_limit, denominator_limit=1000000,
                               time_limit=180, method='highs-ipm'):
    """Untrusted extraction from floating LP, followed by *exact* checks."""
    from janus_babel4_lp import make_model, solve_lp
    model=make_model(instance_rows(instance),rank4_limit=rank4_limit)
    solution=solve_lp(model,time_limit=time_limit,method=method)
    if not solution.success:
        return None,{'status':'NUMERIC_LP_NOT_SOLVED','message':solution.message}
    vals=[Fraction(float(x)).limit_denominator(denominator_limit)
          for x in solution.x]
    den=reduce(lcm,(v.denominator for v in vals),1)
    record={'format':'BABEL4_PSEUDOMOMENTS_V1',
            'instance':instance,'rank4_limit':rank4_limit,
            'denominator':den,
            'frequencies':model['freqs'],
            'integer_numerators':[int(v*den) for v in vals],
            'numeric_objective_is_not_proof':float(solution.fun)}
    return record,verify(record)


def verify(record):
    assert record['format']=='BABEL4_PSEUDOMOMENTS_V1'
    instance=record['instance']
    rows=validate(instance_rows(instance),len(instance_rows(instance)))
    n=len(rows)
    _,basis=gf2_kernel(rows,n)
    counts=Counter(columns_of_kernel(basis,n))
    assert 0 not in counts
    observed=set(counts)
    dense,rank4=chosen_spaces(observed,record['rank4_limit'])
    den=int(record['denominator'])
    freqs=record['frequencies']
    nums=record['integer_numerators']
    assert den>0 and len(freqs)==len(nums) and len(freqs)==len(set(freqs))
    assert freqs==sorted(freqs) and 0 not in freqs
    moments=dict(zip(freqs,nums))
    assert all(-den<=a<=den for a in nums)
    assert set(observed)<=set(moments)
    triangles=set()
    for a,b in combinations(sorted(observed),2):
        c=a^b
        if c in observed:
            triangles.add(tuple(sorted((a,b,c))))
    min_margin=None
    checked=0
    for tri in sorted(triangles):
        for signs in ((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)):
            margin=den+sum(moments[q]*s for q,s in zip(tri,signs))
            if margin<0:
                raise AssertionError(('rank2',tri,signs,margin,den))
            min_margin=margin if min_margin is None else min(min_margin,margin)
            checked+=1
    for level,spaces in ((3,dense),(4,rank4)):
        for space in spaces:
            _,span=basis_patterns(space if level==3 else space[1:])
            assert len(span)==(1<<level)
            for z in range(1<<level):
                margin=den+sum(moments.get(q,0)*(-1 if (mask&z).bit_count()&1 else 1)
                               for q,mask in span.items() if q)
                if margin<0:
                    raise AssertionError((f'rank{level}',space,z,margin,den))
                min_margin=min(min_margin,margin)
                checked+=1
    numerator=sum(counts[q]*moments[q] for q in observed)
    assert numerator*3 == -n*den if n in (63,126) else True
    return {'status':'EXACT_PRIMAL_VERIFIED',
            'instance':instance,'n':n,'nullity':len(basis),
            'observed_frequency_types':len(observed),
            'moment_variable_count':len(moments),
            'rank2_triangles':len(triangles),'rank3_dense_planes':len(dense),
            'rank4_planes':len(rank4),
            'local_inequalities_checked_exactly':checked,
            'minimum_integer_scaled_inequality_margin':min_margin,
            'rational_objective':str(Fraction(numerator,den)),
            'exactly_at_original_triangle_lower_bound':numerator*3 == -n*den,
            'conclusion':'this selected local rank<=4 relaxation CANNOT certify F>-n/3'}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--instance',choices=['SCL63','SAT126','UNSAT126'],default='SCL63')
    ap.add_argument('--rank4-limit',type=int,default=1000)
    ap.add_argument('--time-limit',type=float,default=180)
    ap.add_argument('--denominator-limit',type=int,default=1000000)
    ap.add_argument('--method',choices=['highs','highs-ipm','highs-ds'],default='highs-ipm')
    ap.add_argument('--output',type=Path)
    ap.add_argument('--verify',type=Path)
    args=ap.parse_args()
    if args.verify:
        record=json.loads(args.verify.read_text())
        outcome=verify(record)
    else:
        record,outcome=reconstruct_numeric_primal(args.instance,args.rank4_limit,
                args.denominator_limit,args.time_limit,args.method)
        if record is not None and args.output is not None:
            args.output.write_text(json.dumps(record,sort_keys=True,separators=(',',':'))+'\n')
    print(json.dumps(outcome,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
