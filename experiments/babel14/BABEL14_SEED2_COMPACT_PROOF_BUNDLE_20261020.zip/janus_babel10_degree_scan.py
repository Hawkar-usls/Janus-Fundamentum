#!/usr/bin/env python3
"""BABEL-10: scan MINIMAL possible character-multiplier SOS degree.

Numerical image distances are *diagnostics*. An exact non-membership witness
is supplied for ell=0 when none of the coordinate characters is constant.
Positive degree-2/3 statuses must be backed by archived integer certificates.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsmr

from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses
from janus_occam_replay import FIXTURES, cover


def frozen_instances():
    source, _, _ = load_base()
    result = {'SCL63': source}
    for bit in (16, 59, 68, 81, 94, 132, 168, 169):
        mask = format(int(FIXTURES[1][1], 16) ^ (1 << bit), 'x')
        result[f'SCL126_flip{bit}'] = cover(source, mask)
    frozen252 = Path(__file__).with_name('babel10_SCL252_seed0_ROWS.json')
    if frozen252.exists():
        data = json.loads(frozen252.read_text())
        assert data['n'] == 252 and data['seed'] == 0
        result['SCL252_seed0'] = data['rows']
    return result


def character_products(rows, ell):
    labels, _, d = xor_labels(rows)
    multipliers = degree_witnesses(labels, ell)
    generators = set()
    for row in rows:
        a, b, c = (labels[i] for i in row)
        for u in multipliers:
            # Four contributions may coalesce in a general legal SCL.
            # The frozen family has four distinct frequencies per product.
            support = tuple(sorted((u, u ^ a, u ^ b, u ^ c)))
            assert len(set(support)) == 4
            generators.add(support)
    return labels, d, len(multipliers), sorted(generators)


def certificate_degree0_impossibility(rows, labels, products):
    """Integer row-functional h0=3, h[distinct nonzero qi]=-1."""
    if 0 in labels:
        return {'status': 'UNPROVEN_DEGENERATE_COORDINATES'}
    linear_forms = {0: 3}
    linear_forms.update({q: -1 for q in labels})
    for q0, q1, q2, q3 in products:
        assert sum(linear_forms.get(q, 0)
                   for q in (q0, q1, q2, q3)) == 0
    assert linear_forms[0] == 3
    return {'status': 'EXACT_INTEGER_LEFT_KERNEL_WITNESS',
            'nonzero_frequency_count': len(linear_forms),
            'constant_frequency_pairing': 3,
            'generator_pairing': 0}


def scan(rows, ell, max_iterations=4000):
    labels, d, basis_size, products = character_products(rows, ell)
    n = len(rows)
    a = coo_matrix((np.ones(4 * len(products)),
                    ([q for support in products for q in support],
                     np.repeat(np.arange(len(products)), 4))),
                   shape=(1 << d, len(products))).tocsr()
    target = np.zeros(1 << d)
    target[0] = 1.
    fit = lsmr(a, target, atol=1e-13, btol=1e-13,
               maxiter=max_iterations)
    result = {'n': n, 'parity_kernel_dimension': d,
              'character_multiplier_degree': ell,
              'corresponding_SOS_degree': 2 * ell,
              'multiplier_basis_size': basis_size,
              'distinct_row_products': len(products),
              'floating_relative_residual': float(fit[3]),
              'floating_iterations': int(fit[2]),
              'floating_istop': int(fit[1]),
              'scientific_status': 'NUMERICAL_ONLY'}
    if ell == 0:
        result['exact_degree0_obstruction'] = (
            certificate_degree0_impossibility(rows, labels, products))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--names', nargs='+', default=[
        'SCL63', 'SCL126_flip16', 'SCL126_flip68'])
    parser.add_argument('--degrees', nargs='+', type=int, default=[0, 1])
    parser.add_argument('--max-iterations', type=int, default=4000)
    parser.add_argument('--output', type=Path,
                        default=Path('babel10_FROZEN_DEGREE01_SCAN.json'))
    args = parser.parse_args()
    instances = frozen_instances()
    result = []
    for name in args.names:
        for ell in args.degrees:
            report = scan(instances[name], ell, args.max_iterations)
            report['instance'] = name
            print(json.dumps(report, sort_keys=True), flush=True)
            result.append(report)
    args.output.write_text(json.dumps(result, sort_keys=True,
                                      indent=2) + '\n')


if __name__ == '__main__':
    main()
