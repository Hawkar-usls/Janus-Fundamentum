#!/usr/bin/env python3
"""Generate frozen BABEL-2 block and product-certificate gate artifacts."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel2_solver import certified_minimum
from janus_babel2_verify import verify
from janus_babel2_factor import prove as factor_prove
from janus_babel2_factor_verify import verify as factor_verify


ORDER=[9,0,1,5,8,12,11,2,14,4,3,13,6,7,10]
SHA='3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899'


def write(path, certificate):
    path.write_text(json.dumps(certificate,sort_keys=True,indent=1)+'\n')
    return {'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'bytes':path.stat().st_size}


def main():
    root=Path(__file__).resolve().parent
    csv=root/'tutte12.am.csv'
    assert hashlib.sha256(csv.read_bytes()).hexdigest()==SHA
    src=source_triples(csv)
    results={}
    for name,mask,expected_sat,expected_rank in FIXTURES[:2]:
        cert=certified_minimum(cover(src,mask),order=ORDER,block_width=6,
                               metadata={'frozen_fixture':name,
                                         'tutte12_sha256':SHA,
                                         'mask_hex':mask})
        result=verify(cert)
        assert result['rank']==expected_rank
        assert (result['minimum_defect']==0)==bool(expected_sat)
        filename='JANUS_BABEL2_'+name+'_BLOCK6_20261018.json'
        meta=write(root/filename,cert)
        results[name]={**result,**meta,
                       'direct_scores_reported_by_generator':
                           cert['individual_scores_evaluated_by_constructor']}

    triple_copy=[[j+63*k for j in row]
                 for k in range(3) for row in src]
    factor_cert=factor_prove(triple_copy,block_width=0)
    factor_cert['input_metadata']={'source_sha256':SHA,
                                  'operation':'three disjoint SCL63 copies',
                                  'connected':False}
    result=factor_verify(factor_cert)
    meta=write(root/'JANUS_BABEL2_3xSCL63_FACTOR_20261018.json',factor_cert)
    results['3xSCL63']={**result,**meta}
    print(json.dumps(results,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
