#!/usr/bin/env python3
"""Bind BABEL-1 self-contained proof certificates to frozen voltage masks."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel1_verify import verify


def main():
    directory = Path(__file__).resolve().parent
    csv_path = directory / 'tutte12.am.csv'
    sha = hashlib.sha256(csv_path.read_bytes()).hexdigest()
    source = source_triples(csv_path)
    report = {}
    for name, mask, sat_count, rank in FIXTURES[:2]:
        path = directory / ('JANUS_BABEL1_' + name + '_certificate_20261018.json')
        cert = json.loads(path.read_text())
        assert cert['input_metadata'] == {
            'frozen_fixture': name,
            'tutte12_am_csv_sha256': sha,
            'voltage_mask_hex': mask,
        }
        assert cover(source, mask) == cert['row_triples']
        verdict = verify(cert)
        assert verdict['rank'] == rank
        assert (verdict['minimum_violated_rows'] == 0) == (sat_count != 0)
        report[name] = {**verdict, 'frozen_source_verified': True}
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
