#!/usr/bin/env python3
"""Exact degree-2 SOS audit of the high-nullity cyclic SCL scout.

Unlike modular probes, each membership is decided by rational elimination in
the *complete* cyclic invariant Fourier subspace. Group averaging proves the
quotient is exact for e0, not a relaxation.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from janus_babel11_cyclic_orbit import quotient_membership
from janus_babel11_cyclic_scout import cyclic


def audit(path=Path('babel11_CYCLIC_SCOUT126.json'),
          output=Path('babel11_CYCLIC_HIGHNULLITY_SOS2_EXACT.json')):
    scout = json.loads(path.read_text())
    results = []
    by_status = Counter()
    contradictions = []
    for index, item in enumerate(scout['cases']):
        if item['status'] not in ('SAT', 'UNSAT'):
            continue
        result = quotient_membership(cyclic(item['n'], item['a'], item['b']), 1)
        expected = item['status'] == 'UNSAT'
        if result['member'] != expected:
            contradictions.append({**item, 'SOS2_reaches_constant':result['member']})
        label = (item['n'], item['nullity'], item['status'],
                 'SOS2_PASS' if result['member'] else 'SOS2_NO')
        by_status[label] += 1
        if index % 200 == 0:
            print(json.dumps({'checked': index + 1,
                              'total': len(scout['cases'])}), flush=True)
        results.append({**item, 'SOS2_reaches_constant': result['member'],
                        'orbit_count': result['orbit_count'],
                        'orbit_rank': result['quotient_rank']})
    assert not contradictions, contradictions[:3]
    document = {'source_scout': str(path),
                'instances_exactly_checked': len(results),
                'all_averaged_memberships_match_exact_SAT': True,
                'summary': [list(keys) + [value] for keys, value
                            in sorted(by_status.items())],
                'records': results}
    output.write_text(
        json.dumps(document, sort_keys=True, indent=2) + '\n')
    print(json.dumps({k:v for k,v in document.items() if k!='records'},
                     sort_keys=True), flush=True)
    return document


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scout', type=Path,
                        default=Path('babel11_CYCLIC_SCOUT126.json'))
    parser.add_argument('--output', type=Path,
                        default=Path('babel11_CYCLIC_HIGHNULLITY_SOS2_EXACT.json'))
    args = parser.parse_args()
    audit(args.scout, args.output)
