#!/usr/bin/env python3
"""OCCAM-2 small independent checks, alternative SCL and tamper tests."""

import copy
import json
from pathlib import Path

from janus_occam_replay import source_triples
from janus_occam_solver import gf2_kernel, kernel_search, validate
from janus_occam2_prove import make_certificate, selector_for_word
from janus_occam2_verify import verify


def nine_point_scl():
    triples = []
    for i in range(3):
        triples.append([3 * i + j for j in range(3)])
    for j in range(3):
        triples.append([3 * i + j for i in range(3)])
    for k in range(3):
        triples.append([3 * i + j for i in range(3)
                        for j in range(3) if (i + j) % 3 == k])
    return triples


def expect_rejection(cert):
    try:
        verify(cert)
    except (AssertionError, ValueError, TypeError, KeyError):
        return
    raise AssertionError('broken certificate was accepted')


def main():
    report = {}
    triples = nine_point_scl()
    rows = validate(triples, 9)
    _, basis = gf2_kernel(rows, 9)
    x = sum(1 << (3 * i + i) for i in range(3))
    assert all((r & x).bit_count() == 1 for r in rows)
    v = ((1 << 9) - 1) ^ x
    sel = selector_for_word(basis, v)
    cert = make_certificate(triples, sel)
    verified = verify(cert)
    # Exhaustive cross-check only on this nine-variable test, not in the
    # 126-variable certificate generator or independent verifier.
    scores = []
    for c in range(1 << len(basis)):
        word = 0
        for j, b in enumerate(basis):
            if (c >> j) & 1:
                word ^= b
        scores.append(9 - 2 * word.bit_count())
    assert verified['minimum_walsh_score'] == min(scores) == -3
    report['nine_variable_SAT'] = verified

    # This 63-variable, 3-uniform, 3-regular linear source is a separate
    # architecture from the frozen 126-variable two-cover input.
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    source_rows = validate(source, 63)
    _, basis63 = gf2_kernel(source_rows, 63)
    found, word63, scanned = kernel_search(basis63, 40, False)
    assert found and word63.bit_count() == 40
    cert63 = make_certificate(source, selector_for_word(basis63, word63))
    verified63 = verify(cert63)
    assert verified63['maximum_kernel_weight'] == 40
    assert verified63['minimum_walsh_score'] == -17
    report['source_63_UNSAT'] = {**verified63,
                                 'witness_search_states': scanned}

    # A spoiled leaf bound, an omitted subcube and a wrong witness must fail.
    broken = copy.deepcopy(cert63)
    broken['proof_leaves'][0][1] += 1
    expect_rejection(broken)
    broken = copy.deepcopy(cert63)
    broken['proof_leaves'].pop()
    broken['leaf_count'] -= 1
    expect_rejection(broken)
    broken = copy.deepcopy(cert63)
    broken['witness_selector_hex'] = hex(int(broken['witness_selector_hex'], 16) ^ 1)
    expect_rejection(broken)
    report['tamper_tests'] = 3
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
