#!/usr/bin/env python3
"""BABEL-5 exact degree-four SOS dual for connected frozen UNSAT SCL126.

Proof construction, without giant exact matrix inversion:
1. Lift the exact BABEL-4c SCL63 dual to the + sector of the 2-lift.
2. Build a 6-edge negative signed cycle and transport its 40 identities.
3. Correct every -sector remainder character with one split anchor.
4. Produce an integer identity sum_(row,u) Y[row,u] g_row chi_u = D.

The final integer identity is independently verifiable by integer Fourier
coefficient accumulation, and yields F >= -42 + D^2/(12*C) under full PSD.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from janus_babel4c_kernel import source_data as source63
from janus_babel5_kernel import source_data as source126
from janus_babel5_projection import linear_projection
from janus_babel5_signed_cycle import anchor_identities


def collect_proof():
    parent=json.loads(Path(__file__).with_name(
           'babel4c_SCL63_krylov_rational_dual.json').read_text())
    _,_,source_defects,source_basis=source63()
    cover,cover_labels,_,cover_basis=source126()
    apply,extra,_=linear_projection()
    Qset=set(cover_basis)
    origins={}
    for r,(a,b,c) in enumerate(source_defects):
        for u in source_basis:
            support=tuple(sorted((u,u^a,u^b,u^c)))
            origins.setdefault(support,(r,u))
    assert len(origins)==len(parent['multipliers'])==60354
    representatives={}
    for q in cover_basis:
        representatives.setdefault(apply(q),q)
    assert len(representatives)==1450
    # Terms of the lifted source certificate (without multiplication by 4).
    H=defaultdict(int)
    terms=defaultdict(int)

    def add_term(row,u,coefficient):
        assert 0<=row<126 and u in Qset
        if coefficient:
            terms[(row,u)]+=coefficient

    for support,multiplier in zip(sorted(origins),parent['multipliers']):
        r,b=origins[support]
        u=representatives[b]
        add_term(r,u,4*multiplier)
        H[u]+=multiplier
        for column in cover[r]:
            H[u^cover_labels[column]]+=multiplier
    D=parent['normalization_D']
    positive=defaultdict(int)
    for q,value in H.items():
        positive[apply(q)]+=value
    assert positive[0]==D and all(not v for b,v in positive.items() if b)

    # Pick one coherent section q_b (chosen by zeroing the selected e-bit).
    bit=extra&-extra
    section={}
    for q in range(1<<15):
        if q&bit==0:
            section[apply(q)]=q
    assert len(section)==1<<14
    anchors=anchor_identities()
    split=sorted(anchors)
    corrections=0
    correction_rows=0
    for b,q in sorted(section.items()):
        t=H[q]-H[q^extra]
        c=(D if b==0 else 0)-t
        if not c:
            continue
        # D-H=sum_b c_b*P_minus*chi_(q_b),
        # and 4*P_minus*chi_(q_b) is a signed 2-lift-row identity.
        choices=[]
        for current_q,sector_sign in ((q,1),(q^extra,-1)):
            for i in split:
                multiplier_q=current_q^cover_labels[i]
                if multiplier_q in Qset:
                    weight=sum(abs(x) for x in anchors[i].values())
                    choices.append((weight,len(anchors[i]),i,
                                    multiplier_q,sector_sign))
        assert choices, ('unreachable minus-sector character',b,q)
        _,_,anchor,multiplier_q,sector_sign=min(choices)
        coefficient=c*sector_sign
        for source_row,local_coefficient in anchors[anchor].items():
            add_term(source_row,multiplier_q,
                     coefficient*local_coefficient)
            add_term(source_row+63,multiplier_q,
                     -coefficient*local_coefficient)
            correction_rows+=2
        corrections+=1

    terms={k:v for k,v in terms.items() if v}
    aggregate=[0]*(1<<15)
    for (r,u),y in terms.items():
        aggregate[u]+=y
        for col in cover[r]:
            aggregate[u^cover_labels[col]]+=y
    exact_D=4*D
    assert aggregate[0]==exact_D and all(v==0 for v in aggregate[1:])
    row_l1=[0]*126
    for (r,u),y in terms.items():
        row_l1[r]+=abs(y)
    C=sum(x*x for x in row_l1)
    gap=Fraction(exact_D*exact_D,12*C)
    record={'format':'BABEL5_UNSAT126_INTEGER_SOS_DUAL_V1',
       'source_SCL63_dual_D':D,
       'instance':'UNSAT126','source_mask_hex':
             'f3f8bcef56c536a5d5a2a6967e9947a803340bba408e0c5',
       'degree2_matrix_dimension':2781,
       'integer_group_algebra_dimension':32768,
       'source_positive_sector_terms':len(origins),
       'minus_sector_corrections':corrections,
       'minus_sector_anchor_uses_before_combining':correction_rows,
       'normalization_D':exact_D,
       'dual_norm_upper_bound_C':C,
       'strict_F_gap_numerator':gap.numerator,
       'strict_F_gap_denominator':gap.denominator,
       'terms':[[r,u,y] for (r,u),y in sorted(terms.items())]}
    return record


def verify_full(record):
    assert record['format']=='BABEL5_UNSAT126_INTEGER_SOS_DUAL_V1'
    assert record['instance']=='UNSAT126'
    assert record['source_mask_hex']==\
           'f3f8bcef56c536a5d5a2a6967e9947a803340bba408e0c5'
    rows,labels,_,basis=source126()
    assert len(basis)==record['degree2_matrix_dimension']==2781
    assert len(rows)==126
    assert record['integer_group_algebra_dimension']==32768
    assert len(record['terms'])==len(set((r,u) for r,u,_ in record['terms']))
    assert record['terms']==sorted(record['terms'])
    assert all(type(v) is int for term in record['terms'] for v in term)
    frequencies=[0]*32768
    l1=[0]*126
    for r,u,y in record['terms']:
        assert 0<=r<126 and u in basis and y
        l1[r]+=abs(y)
        frequencies[u]+=y
        for i in rows[r]:
            frequencies[u^labels[i]]+=y
    D=record['normalization_D']
    assert D>0 and frequencies[0]==D and all(v==0 for v in frequencies[1:])
    C=sum(x*x for x in l1)
    assert C==record['dual_norm_upper_bound_C']
    gap=Fraction(D*D,12*C)
    assert gap==Fraction(record['strict_F_gap_numerator'],
                         record['strict_F_gap_denominator'])
    assert gap>0
    return {'status':'BABEL5_EXACT_GLOBAL_DEGREE4_RATIONAL_SOS_DUAL_PASS',
      'instance':'UNSAT126',
      'PSD_matrix_dimension':2781,
      'group_algebra_coefficients_verified':32768,
      'row_character_multipliers':len(record['terms']),
      'D':str(D),'C':str(C),
      'rational_strict_gap':str(gap),
      'rational_F_bound':f'-42+{gap}'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    p.add_argument('--verify',type=Path)
    args=p.parse_args()
    if args.verify:
        outcome=verify_full(json.loads(args.verify.read_text()))
    else:
        cert=collect_proof()
        outcome=verify_full(cert)
        if args.output:
            args.output.write_text(json.dumps(cert,sort_keys=True,
                                              separators=(',',':'))+'\n')
    print(json.dumps(outcome,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
