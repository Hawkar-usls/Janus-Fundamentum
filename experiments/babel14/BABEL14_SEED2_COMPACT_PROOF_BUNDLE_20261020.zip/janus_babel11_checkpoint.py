#!/usr/bin/env python3
"""Freeze BABEL-11 exact scientific checkpoint with input-output SHA256s."""

import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze():
    bits=(16,59,68,81,94,132,168,169)
    evidence=[]
    for bit in bits:
        name=f'babel11_BIT{bit}_SOS4_EXACT_QUOTIENT_DET.json'
        item=json.loads((ROOT/name).read_text())
        assert item['status']=='EXACT_RATIONAL_SOS4_EXISTENCE_PASS'
        assert item['determinant_mod_prime']
        lower=ROOT/f'babel10_SCL126_flip{bit}_EXACT_DEGREE1_OBSTRUCTION.json'
        assert lower.exists()
        evidence.append({'bit':bit,'minimum_SOS_degree':4,
                         'upper_quotient_dim':item['rational_invariant_quotient_dimension'],
                         'determinant_mod_prime':item['determinant_mod_prime'],
                         'upper_proof_sha256':sha(ROOT/name),
                         'lower_integer_proof_sha256':sha(lower)})
    for bit in (94,168,169):
        new=json.loads((ROOT/f'babel11_BIT{bit}_INDEPENDENT_DET.json').read_text())
        assert new['independent_modular_gaussian_full_rank']
        assert new['exact_GF_p_determinant_mod_p']==next(
            x['determinant_mod_prime'] for x in evidence if x['bit']==bit)
    noncover=json.loads((ROOT/'babel11_NONCOVER_SCL63_EXACT_MIN_DEGREES.json').read_text())
    assert noncover['minimum_SOS_degree_4_verified']==12
    cyclic=json.loads((ROOT/'babel11_CYCLIC_P_POLY_SOLVER_REGRESSION.json').read_text())
    assert cyclic['total_connected_linear_cyclic_cases']==83304
    assert cyclic['SAT']==20148 and cyclic['UNSAT']==63156
    orbit=json.loads((ROOT/'babel11_CYCLIC_ALL_NONZERO126_SOS2_EXACT.json').read_text())
    assert orbit['instances_exactly_checked']==25788
    assert orbit['all_averaged_memberships_match_exact_SAT']
    rigid={}
    for bit in (16,68,94):
        result=json.loads((ROOT/f'babel11_THREE_ROW_EXHAUSTIVE_BIT{bit}.json').read_text())
        assert result['exhaustive'] and result['found']==0
        rigid[str(bit)]={'examined_row_triples':result['row_triples_total'],
                         'different_character_line_trade_count':0}
    reproducible=(list(ROOT.glob('babel11_*.json'))+
                  [ROOT/'JANUS_BABEL11_EXACT_QUOTIENT_AND_CYCLIC_THEOREM_20261019.md'])
    hashes={p.name:sha(p) for p in reproducible}
    document={'gate':'BABEL-11',
              'date':'2026-10-19',
              'scientific_status':'LOCAL_EXACT_PASS',
              'GitHub_CI':'NOT_RUN',
              'universal_SolveLinearCubicXSAT':'NOT_CONSTRUCTED',
              'P_vs_NP':'OPEN',
              'frozen_SCL126_eight_exact_minima':evidence,
              'new_noncover_SCL63_exact_minimum4':12,
              'complete_connected_legal_cyclic_census_n_le126':cyclic,
              'two_row_trade_fourier_span':'PROVED_INVARIANT',
              'three_row_rigidity_controls':rigid,
              'previous_BABEL10_SCL252_min_SOS_bound':'>=4',
              'SOS_minimum6_example':'NOT_FOUND',
              'rational_certificate_format':
                 'SYMBOLIC_ADJUGATE_PLUS_EXACT_MODULAR_DETERMINANT',
              'compressed_quotient_discovery_exhausts_2^d':'YES',
              'deep_unittest':'4_PASSED_LOCALLY',
              'files_sha256':dict(sorted(hashes.items()))}
    target=ROOT/'babel11_GATE_CHECKPOINT.json'
    target.write_text(json.dumps(document,sort_keys=True,indent=2)+'\n')
    return {'checkpoint':str(target),'checkpoint_sha256':sha(target),
            'closed_SCL126_minima':len(evidence),
            'new_SCL63_exact_min4':12,
            'cyclic_cases':cyclic['total_connected_linear_cyclic_cases'],
            'status':'LOCAL_EXACT_PASS'}


if __name__=='__main__':
    print(json.dumps(freeze(),sort_keys=True))
