#!/usr/bin/env python3
"""Check actual rational Fourier idempotent identities in BABEL-3 packets.

For an r-dimensional XOR packet with minimum m:
sum_q a_q chi_q - m = sum_z (score(z)-m) *
                        2**(-r) * product_j (1+(-1)**z_j chi_basis_j).
All score(z)-m are nonnegative integers. This checks coefficients using
fractions.Fraction, without assuming floating point or enumerating 2**d.
"""

import argparse
import json
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate
from janus_babel3_verify import verify as verify_proof


def identity(coeff, group):
    # Express all frequencies as binary sums of up to three generators.
    span={0:0}
    basis=[]
    for q in group:
        if q not in span:
            k=len(basis)
            basis.append(q)
            span.update({v^q: mask|(1<<k) for v,mask in list(span.items())})
    r=len(basis)
    assert r==(2 if len(group)==3 else 3)
    scores=[sum(coeff[q]*(-1 if (span[q]&z).bit_count()&1 else 1)
                for q in group) for z in range(1<<r)]
    minimum=min(scores)
    combined=defaultdict(Fraction)
    for z,score in enumerate(scores):
        delta=score-minimum
        assert type(delta) is int and delta>=0
        for q,mask in span.items():
            sign=-1 if (mask&z).bit_count()&1 else 1
            combined[q]+=Fraction(delta*sign,1<<r)
    lhs=defaultdict(Fraction)
    lhs[0]-=minimum
    for q in group:
        lhs[q]+=coeff[q]
    assert all(combined[q]==lhs[q] for q in set(combined)|set(lhs))
    return r, min(scores), max(scores), max(abs(v.denominator) for v in combined.values())


def verify(cert):
    base=verify_proof(cert)
    n=cert['n']
    rows=validate(cert['row_triples'],n)
    _,basis=gf2_kernel(rows,n)
    columns=[sum(((word>>j)&1)<<k for k,word in enumerate(basis)) for j in range(n)]
    order=cert['basis_bit_order']
    ids=Counter()
    for path,mode,_,packets in cert['proof_leaves']:
        if mode!='overlap':
            continue
        fixedmask=ones=0
        for depth,bit in enumerate(path):
            fixedmask|=1<<order[depth]
            if bit=='1':
                ones|=1<<order[depth]
        coeff=defaultdict(int)
        for q in columns:
            coeff[q&~fixedmask]+= -1 if (q&ones).bit_count()&1 else 1
        for group in packets:
            r,_,_,_=identity(coeff,group)
            ids[r]+=1
    assert ids[3]==base['overlapping_five_term_packets_verified']
    assert ids[2]==base['xor_triples_verified']
    return {**base,'rational_idempotent_identities_exact':sum(ids.values()),
            'rank2_identities_exact':ids[2],'rank3_identities_exact':ids[3],
            'rational_denominators':'2^rank (at most 8)'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate',type=Path)
    args=p.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),
                     sort_keys=True,indent=2))


if __name__=='__main__':
    main()
