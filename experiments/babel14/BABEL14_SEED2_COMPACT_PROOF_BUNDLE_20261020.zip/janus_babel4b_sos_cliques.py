#!/usr/bin/env python3
"""Find short exact global degree-four SOS separators among five characters.

Each q belongs to span of at most two observed q's. A rational candidate is
rejected whenever L((chi_q1+...+chi_q5)^2)<0; this is a global PSD cut,
potentially involving ten different observed variables and absent from any
single observed-generated rank-four local distribution.
"""

import argparse
import json
from itertools import combinations
from pathlib import Path

from janus_babel4b_psd import exact_rayleigh, moment_basis
from janus_babel4_rational_certificate import instance_rows
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel


def find_negative_five_squares(record, *, maximum=50, exclude=None):
    basis=moment_basis(record['instance'])
    den=record['denominator']
    m=dict(zip(record['frequencies'],record['integer_numerators']))
    exclude=exclude or set()
    # Require a strictly negative pair correlation, pruning the search.
    adjacency={q:set() for q in basis}
    for i,q in enumerate(basis):
        for r in basis[:i]:
            if 4*m.get(q^r,0) < -den:
                adjacency[q].add(r)
                adjacency[r].add(q)
    result=[]
    def dfs(clique,candidates):
        if len(result)>=maximum:
            return
        if len(clique)==5:
            if tuple(clique) in exclude:
                return
            num=exact_rayleigh(record,clique,[1]*5)
            if num<0:
                result.append({'queries':list(clique),'integer_coefficients':[1]*5,
                               'integer_numerator':num,'denominator':den})
            return
        if len(candidates)+len(clique)<5:
            return
        for q in candidates:
            if len(result)>=maximum:
                return
            nxt=[r for r in candidates if r>q and r in adjacency[q]]
            if len(nxt)+len(clique)+1>=5:
                dfs(clique+[q],nxt)
    dfs([],basis)
    return result


def verify_square(record,square):
    allowed=set(moment_basis(record['instance']))
    qs=square['queries']
    coefficients=square['integer_coefficients']
    assert len(qs)==len(coefficients)==5 and len(set(qs))==5
    assert set(qs)<=allowed
    numerator=exact_rayleigh(record,qs,coefficients)
    assert numerator==square['integer_numerator'] and numerator<0
    assert square['denominator']==record['denominator']
    return numerator


def characters_as_observed_monomials(instance,queries):
    rows=validate(instance_rows(instance),len(instance_rows(instance)))
    _,kernel=gf2_kernel(rows,len(rows))
    observed=sorted(set(columns_of_kernel(kernel,len(rows))))
    degree2={}
    for a,b in combinations(observed,2):
        degree2.setdefault(a^b,(a,b))
    result=[]
    for q in queries:
        support=[] if q==0 else ([q] if q in observed else list(degree2[q]))
        assert len(support)<=2
        result.append(support)
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('certificate',type=Path)
    ap.add_argument('--maximum',type=int,default=1)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    record=json.loads(args.certificate.read_text())
    result=find_negative_five_squares(record,maximum=args.maximum)
    for square in result:
        assert verify_square(record,square)<0
        square['monomials_in_observed_frequencies']=characters_as_observed_monomials(
            record['instance'],square['queries'])
    report={'status':'EXACT_GLOBAL_SOS_SQUARES_FOUND' if result else 'NO_CUT_FOUND',
            'instance':record['instance'],'count':len(result),'squares':result}
    if args.output:
        args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
