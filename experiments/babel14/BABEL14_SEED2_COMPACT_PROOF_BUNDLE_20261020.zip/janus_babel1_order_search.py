#!/usr/bin/env python3
"""Optional reproducible search for compact BABEL-1 certificate bit orders."""

import argparse
import json
import random
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel1_solver import certified_minimum


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--trials', type=int, default=10)
    args = p.parse_args()
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    instances = [cover(source, fixture[1]) for fixture in FIXTURES[:2]]
    rand = random.Random(20261018)
    baseline = [9, 0, 1, 5, 8, 12, 11, 2, 14, 4, 3, 13, 6, 7, 10]
    result = {}
    for k, instance in enumerate(instances):
        # Keep the same reproducible random schedule for each instance,
        # then select the shortest *independently verified* certificate.
        local_rng = random.Random(20261018)
        best = None
        for index in range(args.trials):
            order = list(baseline) if index == 0 else local_rng.sample(range(15), 15)
            cert = certified_minimum(instance, order=order)
            candidate = (cert['proof_leaf_count'],
                         cert['individual_score_evaluations_during_search'])
            if best is None or candidate < best[0]:
                best = (candidate, order, index)
        result[FIXTURES[k][0]] = {'leaf_count': best[0][0],
                                  'evaluated_scores': best[0][1],
                                  'order': best[1], 'trial': best[2]}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
