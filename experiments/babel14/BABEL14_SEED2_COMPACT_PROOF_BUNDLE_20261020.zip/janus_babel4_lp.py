#!/usr/bin/env python3
"""EXPLORATORY rank4 marginal LP. SciPy floats are NOT proof authority.

The primal variables are shared pseudo-Fourier characters s_q for all
frequencies in selected rank2/3/4 subspaces. Each rank-r subspace enforces
all 2**r exact nonnegative local probabilities. A later rational dual
reconstruction is required for a strict exact lower-bound certificate.
"""

import argparse
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from janus_occam_replay import FIXTURES,cover,source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel
from janus_babel3_exact_pseudomodel import all_root_planes
from janus_babel4_scan import selected_rank4_planes,basis_patterns,moment_three


def make_model(triples, *, rank4_limit=0, prioritize_violation=True,
               selected_rank4=None,sos_squares=None):
    rows=validate(triples,len(triples))
    n=len(rows)
    _,kernel=gf2_kernel(rows,n)
    freq_count=Counter(columns_of_kernel(kernel,n))
    assert 0 not in freq_count
    observed=set(freq_count)
    all3=all_root_planes(observed)
    dense=[p for p in all3 if sum(q in observed for q in p)==5]
    rank4,_=selected_rank4_planes(observed)
    positive={q for p in dense for q in p if q not in observed}
    if selected_rank4 is not None:
        rank4=sorted(set(tuple(p) for p in selected_rank4))
    elif rank4_limit:
        if prioritize_violation:
            rated=[]
            for p in rank4:
                _,span=basis_patterns(p[1:])
                worst=min(3+sum(moment_three(q,observed,positive)
                                *(-1 if (mask&z).bit_count()&1 else 1)
                                for q,mask in span.items() if q)
                          for z in range(16))
                rated.append((worst,p))
            rated.sort()
            rank4=[p for _,p in rated[:rank4_limit]]
        else:
            rank4=rank4[:rank4_limit]
    sos_squares=sos_squares or []
    square_frequencies={q[i]^q[j] for q,_ in sos_squares
                        for i in range(len(q)) for j in range(i)}
    frequencies=sorted((set(observed).union(*(set(p) for p in dense),
                                             *(set(p) for p in rank4)) |
                        square_frequencies) - {0})
    index={q:i for i,q in enumerate(frequencies)}
    row_index=[];col_index=[];values=[];labels=[];rhs=[]

    def add(coeff,label,right=1):
        k=len(labels)
        for q,s in coeff.items():
            row_index.append(k)
            col_index.append(index[q])
            values.append(-s)
        labels.append(label)
        rhs.append(right)

    triangles=set()
    for p,q in combinations(sorted(observed),2):
        t=p^q
        if t in observed:
            triangles.add(tuple(sorted((p,q,t))))
    for triple in sorted(triangles):
        for signs in ((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)):
            add(dict(zip(triple,signs)),('T',triple,signs))
    for level,spaces in ((3,dense),(4,rank4)):
        for space in spaces:
            basis,rep=basis_patterns(space if level==3 else space[1:])
            assert len(basis)==level
            for z in range(1<<level):
                add({q:(-1 if (pattern&z).bit_count()&1 else 1)
                     for q,pattern in rep.items() if q},
                    (f'R{level}',space,z))
    for qs,coeffs in sos_squares:
        assert len(qs)==len(coeffs) and len(set(qs))==len(qs)
        offdiag=Counter()
        for i in range(len(qs)):
            for j in range(i):
                offdiag[qs[i]^qs[j]]+=2*coeffs[i]*coeffs[j]
        add(dict(offdiag),('SOS',tuple(qs),tuple(coeffs)),
            right=sum(v*v for v in coeffs))
    # Global SOS cuts can have coefficients much larger than 127; int8 would
    # silently wrap and invalidate the relaxation.
    mat=coo_matrix((np.array(values,dtype=np.int64),
                    (row_index,col_index)),
                   shape=(len(labels),len(frequencies))).tocsr()
    c=np.array([freq_count.get(q,0) for q in frequencies],dtype=float)
    return {'n':n,'d':len(kernel),'freqs':frequencies,'c':c,
            'A':mat,'b':np.array(rhs,dtype=float),
            'labels':labels,'rank2_triangles':len(triangles),
            'rank3_planes':len(dense),'rank4_planes':len(rank4),
            'sos_cuts':len(sos_squares)}


def solve_lp(model, *, time_limit=120, method='highs-ds'):
    result=linprog(model['c'],A_ub=model['A'],b_ub=model['b'],
                   bounds=(-1,1),method=method,
                   options={'time_limit':time_limit})
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--instance',choices=['SCL63','SAT126','UNSAT126'],default='SCL63')
    p.add_argument('--rank4-limit',type=int,default=500)
    p.add_argument('--time-limit',type=float,default=120)
    p.add_argument('--method',choices=['highs-ds','highs-ipm','highs'],default='highs-ds')
    p.add_argument('--save-numeric-dual',type=Path)
    args=p.parse_args()
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    rows=source if args.instance=='SCL63' else cover(source,FIXTURES[0 if args.instance=='SAT126' else 1][1])
    model=make_model(rows,rank4_limit=args.rank4_limit)
    result=solve_lp(model,time_limit=args.time_limit,method=args.method)
    summary={'instance':args.instance,'status_code':result.status,
             'solver_message':result.message,'success':bool(result.success),
             'n':model['n'],'d':model['d'],
             'variables':len(model['freqs']),
             'constraints':len(model['labels']),
             'rank2_triangles':model['rank2_triangles'],
             'rank3_planes':model['rank3_planes'],
             'rank4_planes':model['rank4_planes'],
             'objective_FLOAT_ONLY':float(result.fun) if result.fun is not None else None,
             'marginal_dual_unverified':True}
    if result.success and args.save_numeric_dual:
        record={'instance':args.instance,'rank4_limit':args.rank4_limit,
                'frequencies':model['freqs'],
                'inequality_labels':model['labels'],
                'dual_row_marginals_FLOAT':result.ineqlin.marginals.tolist(),
                'dual_low_marginals_FLOAT':result.lower.marginals.tolist(),
                'dual_up_marginals_FLOAT':result.upper.marginals.tolist(),
                'primal_FLOAT':result.x.tolist()}
        args.save_numeric_dual.write_text(json.dumps(record))
    print(json.dumps(summary,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
