#!/usr/bin/env python3
"""Exact signed-graph rank test for the anti-deck SOS4 correction sector.

For an ordinary one-extra-character 2-lift, a pair of lift-row defects
has difference (1-chi_e)*(s_a*chi_a+s_b*chi_b) for a split row.
After multiplication by a degree-2 character, the anti-deck sector is a
signed edge-incidence system. Its components are full-rank over Q iff
they contain a frustrated signed cycle. This is only the anti-sector;
it does not assert membership of the full e_0 target.
"""

import argparse
import json
from collections import Counter,defaultdict
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import make_lift
from janus_babel6_transfer import (make_projection,signed_graph,
                                   xor_labels)
from janus_babel7_degree_audit import degree_witnesses


class ParityDSU:
    def __init__(self):
        self.parent={}
        self.sign={}
        self.bad=set()
        self.edges=0

    def find(self,a):
        if a not in self.parent:
            self.parent[a]=a
            self.sign[a]=1
        p=self.parent[a]
        if p!=a:
            root,sgn=self.find(p)
            self.sign[a]*=sgn
            self.parent[a]=root
        return self.parent[a],self.sign[a]

    def add(self,a,b,ratio):
        self.edges+=1
        root_a,sa=self.find(a)
        root_b,sb=self.find(b)
        if root_a==root_b:
            if sa!=ratio*sb:
                self.bad.add(root_a)
            return
        self.parent[root_a]=root_b
        self.sign[root_a]=ratio*sb*sa
        if root_a in self.bad or root_b in self.bad:
            self.bad.add(root_b)
            self.bad.discard(root_a)


def audit(seed):
    source=frozen_instances()['SCL126_flip68']
    lift=make_lift(source,seed)[0]
    base_labels,base_D2,d=xor_labels(source)
    labels,Q,D=xor_labels(lift)
    result={'seed':seed,'base_nullity':d,'lift_nullity':D}
    if D!=d+1:
        result['status']='NOT_ONE_EXTRA_SECTOR'
        return result
    pi,e=make_projection(base_labels,labels,d,D)
    split,_,rows=signed_graph(source,lift,labels,e)
    bit=e&-e
    def canon(q):
        return (q^e,-1) if q&bit else (q,1)
    checked_samples=0
    for r,(a,b,sa,sb) in list(rows.items())[:12]:
        for u in sorted(Q)[:8]:
            lhs=defaultdict(int)
            for rr,coeff in ((r,1),(r+len(source),-1)):
                lhs[u]+=coeff
                for i in lift[rr]:
                    lhs[u^labels[i]]+=coeff
            expected=defaultdict(int)
            for i,sign in ((a,sa),(b,sb)):
                q=u^labels[i]
                expected[q]+=sign
                expected[q^e]-=sign
            assert {q:c for q,c in lhs.items() if c}=={q:c for q,c in expected.items() if c}
            checked_samples+=1
    dsu=ParityDSU()
    for a,b,sa,sb in rows.values():
        for u in Q:
            qa,oa=canon(u^labels[a]);qb,ob=canon(u^labels[b])
            ratio=-sa*sb*oa*ob
            dsu.add(qa,qb,ratio)
    count=Counter()
    for q in list(dsu.parent):
        root,_=dsu.find(q)
        count[root]+=1
    active=degree_witnesses(labels,3)
    active_canonical={canon(q)[0] for q in active}
    representatives={}
    for q in sorted(Q):
        representatives.setdefault(pi(q),q)
    lifted_source_support=set()
    for x in base_D2:
        u=representatives[x]
        lifted_source_support.add(canon(u)[0])
        for row in lift[:len(source)]:
            for i in row:
                lifted_source_support.add(canon(u^labels[i])[0])
    missing_lifted_source=lifted_source_support-set(dsu.parent)
    absent=0
    full=0
    for q in active_canonical:
        if q not in dsu.parent:
            absent+=1
        elif dsu.find(q)[0] in dsu.bad:
            full+=1
    result.update({'split_vertices':len(split),'split_rows':len(rows),
        'independent_row_difference_fourier_checks':checked_samples,
        'raw_antisector_edge_count':dsu.edges,
        'sector_graph_touched_nodes':len(dsu.parent),
        'components':len(count),'frustrated_full_rank_components':len(dsu.bad),
        'frustrated_full_rank_vertices':sum(count[c] for c in dsu.bad),
        'canonical_active_D3':len(active_canonical),
        'active_D3_nodes_in_full_rank_components':full,
        'active_D3_nodes_missing_from_graph':absent,
        'active_D3_nodes_in_balanced_components':len(active_canonical)-full-absent,
        'possible_lifted_source_support_pair_count':len(lifted_source_support),
        'possible_lifted_source_support_pairs_not_touched_by_antisector':len(missing_lifted_source),
        'all_active_D3_antisector_frequencies_correctable':full==len(active_canonical),
        'status':'EXACT_SIGNED_GRAPH_SECTOR_RANK_AUDIT'})
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    out=audit(args.seed)
    if args.output:
        args.output.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(json.dumps(out,sort_keys=True),flush=True)
