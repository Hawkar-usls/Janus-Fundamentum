#!/usr/bin/env python3
"""BABEL-6: frozen sparse transfer and one-edge obstruction census.

The main transfer performs no 2**d enumeration. The optional finite census
does enumerate the tiny frozen parity kernels to verify UNSAT of each control.
No GitHub CI is invoked by this program.
"""

import argparse
import hashlib
import json
from collections import Counter, deque
from pathlib import Path

from janus_babel4c_exact_dual import equation_origins
from janus_babel4c_kernel import source_data
from janus_babel6_transfer import (make_projection, negative_cycle_in_component,
                                   signed_graph,
                                   transfer, xor_labels)
from janus_occam_replay import FIXTURES, cover
from janus_occam_solver import gf2_kernel, kernel_search, validate


ROOT = Path(__file__).resolve().parent
PROOF = ROOT / 'babel4c_SCL63_krylov_rational_dual.json'
FROZEN_UNSAT = FIXTURES[1][1]


def load_base():
    rows, _, defects, basis = source_data()
    proof = json.loads(PROOF.read_text())
    origins = equation_origins(defects, basis)
    assert len(origins) == len(proof['multipliers']) == 60354
    terms = {origins[key]: value
             for key, value in zip(sorted(origins), proof['multipliers'])
             if value}
    return rows, terms, proof['normalization_D']


def bfs_vertex_count(rows):
    n = len(rows)
    adj = [[] for _ in range(2 * n)]
    for i, triple in enumerate(rows):
        for j in triple:
            adj[i].append(n + j)
            adj[n + j].append(i)
    seen = {0}
    queue = deque([0])
    while queue:
        for v in adj[queue.popleft()]:
            if v not in seen:
                seen.add(v)
                queue.append(v)
    return len(seen)


def run_transfer():
    rows, base_terms, D = load_base()
    covered = cover(rows, FROZEN_UNSAT)
    terms, data = transfer(rows, covered, base_terms, D)
    data['status'] = 'BABEL6_SPARSE_CONDITIONAL_TRANSFER_EXACT_PASS'
    data['frozen_mask'] = FROZEN_UNSAT
    data['connected_incidence_vertices'] = bfs_vertex_count(covered)
    result = {'format':'JANUS_BABEL6_SPARSE_TRANSFER_DUAL_V1',
              'normalization_D':data['D'],
              'dual_norm_upper_bound_C':data['C'],
              'source_csv_sha256':
                  '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899',
              'cover_mask_hex':FROZEN_UNSAT,
              'terms':[[r,u,v] for (r,u),v in sorted(terms.items())]}
    return result, data


def one_edge_census():
    rows, _, _ = load_base()
    src_labels, _, src_dim = xor_labels(rows)
    start = int(FROZEN_UNSAT,16)
    counts = Counter()
    graph_counts = Counter()
    witnesses = {}
    per_edge = []
    for bit in range(189):
        mask = format(start ^ (1 << bit), 'x')
        doubled = cover(rows, mask)
        _, kernel = gf2_kernel(validate(doubled,126),126)
        assert bfs_vertex_count(doubled) == 252
        dim = len(kernel)
        count, witness, checked = kernel_search(kernel, 84, count_all=True)
        assert checked == 1 << dim
        if count:
            raise AssertionError(f'unexpected SAT one-edge neighbor: {bit}')
        counts[dim] += 1
        profile = f'nullity_{dim}'
        if dim == src_dim + 1:
            labels, _, _ = xor_labels(doubled)
            _, extra = make_projection(src_labels,labels,src_dim,dim)
            split, graph, edges = signed_graph(rows,doubled,labels,extra)
            visited, positive_cycles, balanced = set(), 0, 0
            for vertex in sorted(split):
                if vertex in visited:
                    continue
                comp,cycle = negative_cycle_in_component(graph,vertex) \
                    if vertex in graph else ({vertex},None)
                visited.update(comp)
                positive_cycles += bool(cycle)
                balanced += not bool(cycle)
            assert visited == split
            profile = ('unbalanced' if positive_cycles and not balanced
                       else 'balanced' if balanced and not positive_cycles
                       else 'mixed')
            graph_counts[profile] += 1
            if profile == 'balanced' and 'balanced_same_nullity' not in witnesses:
                witnesses['balanced_same_nullity'] = {
                  'flipped_edge_index_zero_based':bit, 'mask_hex':mask,
                  'nullity':dim,'SAT_count':count,'states_checked':checked,
                  'split_vertices':len(split),'signed_edges':len(edges),
                  'signed_graph_balanced':True,
                  'connected_incidence_vertices':bfs_vertex_count(doubled)}
        if dim == src_dim + 2 and 'two_extra_sectors' not in witnesses:
            witnesses['two_extra_sectors'] = {
              'flipped_edge_index_zero_based':bit, 'mask_hex':mask,
              'nullity':dim,'SAT_count':count,'states_checked':checked,
              'connected_incidence_vertices':bfs_vertex_count(doubled)}
        if dim == src_dim and 'no_extra_sector' not in witnesses:
            witnesses['no_extra_sector'] = {
              'flipped_edge_index_zero_based':bit, 'mask_hex':mask,
              'nullity':dim,'SAT_count':count,'states_checked':checked,
              'connected_incidence_vertices':bfs_vertex_count(doubled)}
        per_edge.append([bit,dim,count,profile])
    assert sum(counts.values()) == 189
    assert counts == {14:72,15:99,16:18}
    assert graph_counts == {'unbalanced':91,'balanced':8}
    return {'status':'BABEL6_ONE_EDGE_LOCAL_CENSUS_EXACT_PASS',
            'origin_mask_hex':FROZEN_UNSAT,
            'neighbor_definition':'flip one of the 189 physical base-edge voltages',
            'neighbor_count':189,
            'all_neighbors_legal_and_UNSAT':True,
            'nullity_histogram':dict(sorted(counts.items())),
            'among_nullity_15_signed_graphs':dict(sorted(graph_counts.items())),
            'all_189_neighbors_connected':True,
            'per_edge_results_bit_nullity_SATcount_signedgraph':per_edge,
            'minimal_Hamming_1_obstructions':witnesses,
            'minimality_scope':'one flipped edge from this mask; NOT minimum n among all SCL'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--proof',type=Path)
    parser.add_argument('--report',type=Path)
    parser.add_argument('--scan-neighbors',action='store_true')
    args = parser.parse_args()
    record, data = run_transfer()
    if args.proof:
        args.proof.write_text(json.dumps(record,sort_keys=True,
                                         separators=(',',':'))+'\n')
        data['proof_file_sha256'] = hashlib.sha256(args.proof.read_bytes()).hexdigest()
    if args.scan_neighbors:
        data['one_edge_census'] = one_edge_census()
    if args.report:
        args.report.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
    summary = dict(data)
    if 'one_edge_census' in summary:
        summary['one_edge_census'] = dict(summary['one_edge_census'])
        summary['one_edge_census'].pop(
            'per_edge_results_bit_nullity_SATcount_signedgraph',None)
    print(json.dumps(summary,sort_keys=True,indent=2))


if __name__ == '__main__':
    main()
