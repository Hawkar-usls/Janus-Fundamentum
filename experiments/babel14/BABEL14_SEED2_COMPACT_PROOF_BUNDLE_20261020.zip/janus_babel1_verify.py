#!/usr/bin/env python3
"""Independent checker of JANUS BABEL-1 XOR-triple Walsh certificates.

The verifier does not import the certificate constructor, its greedy
packing algorithm, or any precomputed Fourier transform.
"""

import argparse
import json
from collections import defaultdict
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate


def verify(data):
    if not __debug__:
        raise RuntimeError('BABEL exact checker must run with assertions enabled')
    if data.get('format') != 'JANUS_BABEL1_XOR_triple_partition_v1':
        raise ValueError('unknown or unsupported proof format')

    n = data['n']
    rows = validate(data['row_triples'], n)
    rowspace, basis = gf2_kernel(rows, n)
    d = len(basis)
    assert len(rowspace) == data['rank_GF2']
    assert d == data['nullity_GF2']
    order = data['basis_bit_order']
    assert sorted(order) == list(range(d))

    # Check the equality witness from the original incidence matrix.
    selector = int(data['witness_selector_hex'], 16)
    assert 0 <= selector < (1 << d)
    witness = 0
    for bit, vector in enumerate(basis):
        if selector & (1 << bit):
            witness ^= vector
    assert hex(witness) == data['witness_kernel_word_hex']
    assert all((witness & row).bit_count() % 2 == 0 for row in rows)
    claimed_minimum = n - 2 * witness.bit_count()
    assert claimed_minimum == data['optimum_F']
    x = ((1 << n) - 1) ^ witness
    exact_one = all((row & x).bit_count() == 1 for row in rows)
    status = 'SAT' if exact_one else 'UNSAT'
    assert data['exact_one_status'] == status
    assert exact_one == (n % 3 == 0 and claimed_minimum == -(n//3))
    if exact_one:
        assert data['witness_true_variables'] == [i for i in range(n) if (x >> i) & 1]
    else:
        assert 'witness_true_variables' not in data
    q_columns = [sum(((v >> j) & 1) << bit
                     for bit, v in enumerate(basis)) for j in range(n)]
    assert sum(-1 if (q & selector).bit_count() & 1 else 1
               for q in q_columns) == claimed_minimum

    # A trie checks pairwise disjointness; the exact binary Kraft sum then
    # proves that these leaves cover the entire 2**d selector library.
    leaves = data['proof_leaves']
    assert len(leaves) == data['proof_leaf_count']
    assert len(leaves) >= 1
    prefix_tree = {}
    covered = 0
    triple_count = 0
    deepest = 0
    for path, stated_bound, triples in leaves:
        assert isinstance(path, str) and len(path) <= d
        assert all(character in '01' for character in path)
        branch = prefix_tree
        for character in path:
            assert 'leaf' not in branch, 'overlap: parent already certified'
            branch = branch.setdefault(character, {})
        assert not branch, 'overlap: duplicate leaf or certified descendants'
        branch['leaf'] = True
        covered += 1 << (d - len(path))
        deepest = max(deepest, len(path))

        mask = 0
        values = 0
        for level, character in enumerate(path):
            bit = 1 << order[level]
            mask |= bit
            if character == '1':
                values |= bit
        coeff = defaultdict(int)
        for q in q_columns:
            phase = -1 if (q & values).bit_count() & 1 else 1
            coeff[q & ~mask] += phase
        baseline = coeff[0] - sum(abs(a) for q, a in coeff.items() if q)

        used = set()
        gain = 0
        for packet in triples:
            assert isinstance(packet, list) and len(packet) == 3
            p, q, t = packet
            assert type(p) is type(q) is type(t) is int
            assert p != 0 and q != 0 and t != 0
            assert p != q and p != t and q != t and (p ^ q) == t
            assert coeff[p] and coeff[q] and coeff[t]
            assert p not in used and q not in used and t not in used
            used.update((p, q, t))
            ap, aq, at = coeff[p], coeff[q], coeff[t]
            # Four local sign assignments; no global selector enumeration.
            local_minimum = min(ap*x + aq*y + at*x*y
                                for x in (-1, 1) for y in (-1, 1))
            local_gain = local_minimum + abs(ap) + abs(aq) + abs(at)
            assert local_gain >= 0
            gain += local_gain
            triple_count += 1
        exact_bound = baseline + gain
        assert stated_bound == exact_bound
        assert exact_bound >= claimed_minimum, (path, exact_bound, claimed_minimum)

    assert covered == 1 << d
    assert covered == data['symbolically_covered_selectors']
    return {
        'status': 'PROVED_EXACT_WALSH_MINIMUM',
        'n': n, 'rank': len(rowspace), 'nullity': d,
        'minimum_F': claimed_minimum,
        'maximum_kernel_weight': witness.bit_count(),
        'minimum_violated_rows': n - 3*witness.bit_count()//2,
        'exact_one_status': status,
        'leaf_count': len(leaves),
        'covered_selectors': covered,
        'verified_xor_packets': triple_count,
        'deepest_leaf': deepest,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate', type=Path)
    args = p.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
