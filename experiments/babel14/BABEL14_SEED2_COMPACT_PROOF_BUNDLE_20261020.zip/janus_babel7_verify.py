#!/usr/bin/env python3
"""Clean-room exact verifier for BABEL-7 local and full SOS certificates.

No imports from the BABEL-7 certificate constructors or degree audit.
Every group-algebra equality is checked with integer Fourier addition.
"""

import argparse
import hashlib
import json
from collections import defaultdict,deque
from fractions import Fraction
from pathlib import Path

from janus_occam_replay import cover,source_triples
from janus_occam_solver import gf2_kernel,validate


def degree_map(columns,limit):
    result={0:0}
    frontier={0}
    for degree in range(1,limit+1):
        nxt={q^v for q in frontier for v in set(columns)}-result.keys()
        result.update((v,degree) for v in nxt)
        frontier=nxt
    return result


def verify_record(record):
    src=Path(__file__).with_name('tutte12.am.csv')
    base=source_triples(src)
    mask=record.get('cover_mask_hex',record.get('source_mask_hex'))
    lift=cover(base,mask)
    n=len(lift)
    validate(lift,n)
    _,kernel=gf2_kernel(validate(lift,n),n)
    labels=[sum(((word>>j)&1)<<i for i,word in enumerate(kernel))
            for j in range(n)]
    freq=defaultdict(int)
    seen=set()
    l1=[0]*n
    is_local=record['format']=='BABEL7_BALANCED_UNSAT_LOCAL_SECTOR_INTEGER_DUAL_V1'
    if is_local:
        degree_limit=2
        D=record['normalization_D']
        extra=record['extra_character']
    else:
        assert record['format'] in (
            'JANUS_BABEL7_BALANCED_UNSAT126_DEGREE8_SOS_DUAL_V1',
            'JANUS_BABEL7_BALANCED_UNSAT126_DEGREE6_SOS_DUAL_V1')
        assert hashlib.sha256(src.read_bytes()).hexdigest()==record['source_csv_sha256']
        degree_limit=record['degree_limit_for_multiplier_characters']
        assert degree_limit in (3,4)
        assert record['degree_limit_for_SOS']==2*degree_limit
        D=record['normalization_D']
    representable=degree_map(labels,degree_limit)
    maxdeg=0
    for r,u,c in record['terms']:
        assert all(type(v) is int for v in (r,u,c))
        assert 0<=r<n and u in representable and c
        assert (r,u) not in seen
        seen.add((r,u))
        maxdeg=max(maxdeg,representable[u])
        l1[r]+=abs(c)
        freq[u]+=c
        for col in lift[r]:
            freq[u^labels[col]]+=c
    support={q:c for q,c in freq.items() if c}
    if is_local:
        assert support=={0:D,extra:-D}
        return {'status':'BABEL7_INDEPENDENT_LOCAL_SECTOR_DUAL_PASS',
                'full_fourier_domain':1<<len(kernel),
                'integer_terms':len(seen),
                'normalization_D':str(D),
                'max_character_degree':maxdeg,
                'exact_support':support}
    assert support=={0:D}
    assert sum(v*v for v in l1)==record['dual_norm_upper_bound_C']
    gap=Fraction(D*D,12*record['dual_norm_upper_bound_C'])
    a=record.get('rational_strict_gap_numerator',
                 record.get('strict_gap_numerator'))
    b=record.get('rational_strict_gap_denominator',
                 record.get('strict_gap_denominator'))
    assert gap==Fraction(a,b)
    assert gap>0
    return {'status':f'BABEL7_INDEPENDENT_EXACT_DEGREE{2*degree_limit}_SOS_DUAL_PASS',
            'GF2_nullity':len(kernel),
            'moment_matrix_basis_size':len(representable),
            'integer_terms':len(seen),
            'frequency_additions':4*len(seen),
            'normalization_D':str(D),
            'dual_norm_C':str(record['dual_norm_upper_bound_C']),
            'max_character_degree':maxdeg,
            'SOS_degree_limit':2*degree_limit,
            'strict_gap':str(gap),
            'lower_bound_F':f'-42+{gap}'}


def verify(path):
    return verify_record(json.loads(Path(path).read_text()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('proof_json',type=Path)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    result=verify(args.proof_json)
    if args.output:args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':main()
