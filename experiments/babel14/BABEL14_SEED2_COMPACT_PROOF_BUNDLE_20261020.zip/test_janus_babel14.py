#!/usr/bin/env python3
"""BABEL-14 scientific regression tests.  Every gate uses exact arithmetic."""

import json
import unittest
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import audit, make_lift
from janus_babel10_transfer_lower import exact_base_lower_functional, verify_lift
from janus_babel14_exact_transfer import verify as verify_compact
from janus_babel14_expand_exact import independent_verify

HERE=Path(__file__).resolve().parent


class Babel14Exact(unittest.TestCase):
    def test_01_legal_unsat_connected_seed2(self):
        result,_=audit('SCL126_flip68',frozen_instances()['SCL126_flip68'],2)
        self.assertTrue(result['legal_linear_cubic'])
        self.assertTrue(result['connected'])
        self.assertEqual(result['GF2_nullity'],16)
        self.assertEqual(result['exact_SAT_count'],0)
        self.assertEqual(result['checked_kernel_states'],65536)

    def test_02_exact_antisector_and_compact_circuit(self):
        record=json.loads((HERE/'babel14_SEED2_EXACT_RATIONAL_TRANSFER_CIRCUIT.json').read_text())
        v=verify_compact(record)
        self.assertEqual(v['status'],'EXACT_SEED2_TRANSFER_Q_CERTIFICATE_REPLAY_PASS')
        self.assertEqual(v['witnessed_singletons'],425)
        self.assertEqual(v['forced_base_zero_frequencies'],19)
        self.assertEqual(v['frustrated_chords'],2)

    def test_03_source_krylov_replay_record(self):
        d=json.loads((HERE/'babel14_SEED2_SOURCE_KRYLOV_REPLAY.json').read_text())
        self.assertEqual(d['exact_integer_frequency_replay'],'PASS')
        self.assertEqual(d['recurrence_degree'],556)
        self.assertEqual(d['integer_normal_operator_terms'],162837)

    def test_04_exact_degree_below_four_obstruction(self):
        src,labels,d,h=exact_base_lower_functional()
        r=verify_lift(src,labels,d,h,make_lift(src,2)[0])
        self.assertEqual(r['degree1_row_generators_checked'],26536)
        self.assertEqual(r['SOS_degree_less_than_4'],'EXCLUDED')

    def test_05_independent_expanded_all_frequency_replay(self):
        result=independent_verify(HERE/'babel14_SEED2_EXPLICIT_INTEGER_IDENTITY.json.gz')
        self.assertEqual(result['status'],'BABEL14_INDEPENDENT_EXACT_ALL_FREQUENCY_REPLAY_PASS')
        self.assertEqual(result['nonzero_integer_multipliers'],186325)


if __name__=='__main__':
    unittest.main(verbosity=2)
