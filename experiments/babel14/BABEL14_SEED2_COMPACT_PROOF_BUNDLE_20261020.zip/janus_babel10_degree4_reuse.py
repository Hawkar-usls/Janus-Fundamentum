#!/usr/bin/env python3
"""Try SAME integer P(t) from bit16 on other balanced 126-covers.

The observed modular equality is not sufficient: independent all-frequency
integer verification MUST succeed for each instance, or the clone is invalid.
"""

import hashlib
import json
from pathlib import Path

from janus_babel8_krylov_verify import verify


BASE = Path(__file__).with_name('babel8_DEGREE4_KRYLOV_RATIONAL_DUAL.json')


def main():
    template = json.loads(BASE.read_text())
    for bit in (59, 81, 132):
        document = dict(template)
        document['flipped_base_edge_index'] = bit
        path = Path(__file__).with_name(
            f'babel10_SCL126_BIT{bit}_DEGREE4_REUSED_POLYNOMIAL.json')
        path.write_text(json.dumps(document, sort_keys=True,
                                   separators=(',', ':')) + '\n')
        result = verify(path)
        result['proof_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        report_path = Path(__file__).with_name(
            f'babel10_SCL126_BIT{bit}_DEGREE4_VERIFICATION.json')
        report_path.write_text(json.dumps(result, sort_keys=True,
                                          indent=2) + '\n')
        print(json.dumps({key: value for key, value in result.items()
                          if key not in ('strict_gap_numerator',
                                         'strict_gap_denominator',
                                         'integer_normalization_D',
                                         'integer_row_norm_upper_C')},
                         sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
