#!/usr/bin/env python3
"""Discover legal non-cover UNSAT SCL via rank-preserving cubic 2-row trades.

Every inserted triple annihilates the frozen parity kernel. If the new kernel
dimension remains exactly d, it equals the old kernel, hence XSAT status is
unchanged. Every accepted mutation also passes cubic linearity and connection.
"""

import argparse
import hashlib
import json
import random
from itertools import combinations
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import connected_incidence
from janus_babel6_transfer import xor_labels
from janus_occam_solver import gf2_kernel, validate, kernel_search


def moves(rows, labels, fixed_nullity):
    n = len(rows)
    proposals = []
    for i, j in combinations(range(n), 2):
        support = set(rows[i]) | set(rows[j])
        if len(support) != 6:
            continue
        support = sorted(support)
        for two in combinations(support[1:], 2):
            new_first = tuple(sorted((support[0], *two)))
            if set(new_first) in (set(rows[i]), set(rows[j])):
                continue
            if labels[new_first[0]] ^ labels[new_first[1]] ^ labels[new_first[2]]:
                continue
            new_second = tuple(sorted(set(support) - set(new_first)))
            modified = list(rows)
            modified[i], modified[j] = new_first, new_second
            try:
                masks = validate(modified, n)
            except ValueError:
                continue
            if len(gf2_kernel(masks, n)[1]) != fixed_nullity:
                continue
            if not connected_incidence(modified):
                continue
            proposals.append((i, j, new_first, new_second))
    return proposals


def mutate(base_bit=94, seeds=(0, 1, 2), steps=(1, 5, 20, 60)):
    original = frozen_instances()[f'SCL126_flip{base_bit}']
    n = len(original)
    labels, _, dimension = xor_labels(original)
    assert dimension == 15
    evidence = {'source':f'SCL126_flip{base_bit}',
                'n':n,'GF2_kernel_dimension':dimension,'cases':[]}
    for seed in seeds:
        rng = random.Random(seed)
        current = list(map(tuple, original))
        history = []
        for step in range(1, max(steps) + 1):
            choices = moves(current, labels, dimension)
            if not choices:
                break
            # Avoid an immediate reversal and mostly move away from the source.
            choice = rng.choice(choices)
            i, j, first, second = choice
            current[i],current[j] = first,second
            history.append([i,j,list(first),list(second)])
            if step in steps:
                _, kernel = gf2_kernel(validate(current,n),n)
                assert len(kernel)==dimension
                sat, _, states = kernel_search(kernel, 2*n//3, True)
                assert sat == 0 and states == (1 << dimension)
                serial = json.dumps(current,separators=(',',':'))
                case = {'seed':seed,'steps':step,
                        'rows':list(current),
                        'SHA256_rows_canonical':hashlib.sha256(
                            serial.encode()).hexdigest(),
                        'move_history':list(history),
                        'source_kernel_exactly_preserved':True,
                        'legal_connected':True,'exact_SAT_count':sat,
                        'enumerated_GF2_states':states}
                evidence['cases'].append(case)
                print(json.dumps({k:v for k,v in case.items()
                                  if k not in ('rows','move_history')},
                                 sort_keys=True),flush=True)
    return evidence


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--flip',type=int,default=94)
    p.add_argument('--seeds',nargs='+',type=int,default=[0,1,2])
    p.add_argument('--steps',nargs='+',type=int,default=[1,5,20,60])
    p.add_argument('--output',type=Path,
                   default=Path('babel11_RANK_PRESERVING_TRADES.json'))
    args=p.parse_args()
    report=mutate(args.flip,args.seeds,args.steps)
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')


if __name__=='__main__':main()
