#!/usr/bin/env python3
"""BABEL-14: expand a compact transfer circuit to one explicit integer identity.

The output uses a common positive integer normalization D.  Each multiplier
is a degree<=2 character; coefficient division by D makes the identity equal
to 1 over Q.  The all-frequency identity is checked over Python big integers.
"""

import argparse
import gzip
import hashlib
import json
from collections import defaultdict, deque
from pathlib import Path

from janus_babel14_antisector_augmented import prepare
from janus_babel14_exact_transfer import edge_data
from janus_babel6_transfer import xor_labels, make_projection, signed_graph
from janus_babel8_krylov_verify import input_data, normal


def add(dct, key, coefficient):
    new=dct[key]+coefficient
    if new:
        dct[key]=new
    else:
        dct.pop(key,None)


def fourier(terms, lift, labels):
    frequencies=defaultdict(int)
    for (r,u),c in terms.items():
        add(frequencies,u,c)
        for col in lift[r]:
            add(frequencies,u^labels[col],c)
    return frequencies


def build(proof_path, output_path):
    compact=json.loads(Path(proof_path).read_text())
    source,lift,labels,Q,e,canonical,touched,active,missing=prepare(2)
    src_rows,src_labels,src_basis,eq,origins=input_data(68)
    assert src_rows==source
    assert src_labels==xor_labels(source)[0]
    poly_path=Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    assert hashlib.sha256(poly_path.read_bytes()).hexdigest()==compact['source_krylov_polynomial_sha256']
    poly=json.loads(poly_path.read_text())['polynomial_coefficients_low_to_high']
    P0=poly[0]
    v=[0]*32768
    for step,c in enumerate(reversed(poly[1:])):
        v=normal(v,eq)
        v[0]+=c
        if (step+1)%100==0:
            print(f'source exact Krylov Horner {step+1}/{len(poly)-1}',flush=True)
    check=normal(v,eq)
    assert check[0]==-P0 and not any(check[1:])
    n=len(source)
    pi,_=make_projection(src_labels,labels,15,16)
    representatives={}
    for u in sorted(Q):
        representatives.setdefault(pi(u),u)
    assert set(representatives)==set(src_basis)

    # Multiply all source integer coefficients by four.  The 4-factor makes
    # every degree-2 correction coefficient integral (tree and odd cycles).
    D=4*abs(P0)
    sign=-1 if P0>0 else 1
    terms=defaultdict(int)
    for a,b,c,d in eq:
        r,u=origins[(a,b,c,d)]
        coeff=4*sign*(v[a]+v[b]+v[c]+v[d])
        if coeff:
            add(terms,(r,representatives[u]),coeff)
    print(f'lifted {len(terms)} base source terms at integer scale 4',flush=True)
    H=fourier(terms,lift,labels)
    rest={entry['frequency'] for entry in compact['automatic_base_frequency_zero_constraints']}
    for q in rest:
        assert H.get(q,0)-H.get(q^e,0)==0
    assert len(rest)==19

    for entry in compact['singleton_generator_witnesses']:
        q,r,u,s=(entry[k] for k in ('frequency','row','multiplier','integer_amplitude'))
        defect=-(H.get(q,0)-H.get(q^e,0))
        assert defect%(2*s)==0
        k=defect//(2*s)
        if k:
            add(terms,(r,u),k)
            add(terms,(r,u^e),-k)
            for zz in (u,*(u^labels[col] for col in lift[r])):
                add(H,zz,k)
                add(H,zz^e,-k)
        assert H.get(q,0)-H.get(q^e,0)==0
    assert all(H.get(q,0)-H.get(q^e,0)==0 for q in missing)
    print('all 444 off-graph frequencies corrected exactly',flush=True)

    _,_,row_edges=signed_graph(source,lift,labels,e)
    adjacency=defaultdict(list)
    for r,u in compact['graph_spanning_forest_edges']:
        a,b,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
        adjacency[a].append((b,alpha,beta,r,u))
        adjacency[b].append((a,beta,alpha,r,u))
    signs={}
    parent={}
    order=[]
    component={}
    for root in compact['graph_roots']:
        assert root not in signs
        signs[root]=1
        parent[root]=None
        component[root]=root
        todo=deque([root])
        while todo:
            q=todo.popleft()
            order.append(q)
            for next_q,alpha,beta,r,u in adjacency[q]:
                if next_q in signs:
                    continue
                signs[next_q]=-signs[q]*alpha*beta
                parent[next_q]=(q,alpha,beta,r,u)
                component[next_q]=root
                todo.append(next_q)
    assert set(signs)==touched
    b={}
    for q in touched:
        difference=(D if q==0 else 0)-(H.get(q,0)-H.get(q^e,0))
        assert difference%2==0
        b[q]=difference//2

    def add_rowdiff(r,u,k):
        if k:
            add(terms,(r,u),k)
            add(terms,(r+n,u),-k)

    for r,u in compact['graph_frustrating_chords']:
        a,z,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
        root=component[a]
        assert root==component[z]
        denom=signs[a]*alpha+signs[z]*beta
        assert abs(denom)==2
        total=sum(signs[q]*b[q] for q in order if component[q]==root)
        assert total%denom==0
        k=total//denom
        b[a]-=k*alpha
        b[z]-=k*beta
        add_rowdiff(r,u,k)

    for q in reversed(order):
        entry=parent[q]
        if entry is None:
            assert b[q]==0, ('unfixed root',q)
            continue
        p,alpha_parent,beta_child,r,u=entry
        k=b[q]*beta_child
        b[p]-=k*alpha_parent
        b[q]=0
        add_rowdiff(r,u,k)

    final=fourier(terms,lift,labels)
    assert final=={0:D}, ('unexpected final support',len(final),
                          [(q,len(str(abs(c)))) for q,c in list(final.items())[:3]])
    print(f'EXACT FINAL IDENTITY VERIFIED: {len(terms)} nonzero terms, normalization D has {len(str(D))} digits',flush=True)
    sha=hashlib.sha256()
    with gzip.open(output_path,'wt',encoding='utf-8',compresslevel=6) as out:
        out.write(json.dumps({'format':'JANUS_BABEL14_SEED2_EXPLICIT_INTEGER_IDENTITY_V1',
                              'degree2':True,'n':252,'terms_count':len(terms),
                              'positive_integer_normalization_D':str(D),
                              'seed':2,'terms':[[r,u,str(c)] for (r,u),c in sorted(terms.items())]},
                             sort_keys=True,separators=(',',':')))
    with open(output_path,'rb') as fd:
        for piece in iter(lambda:fd.read(1<<20),b''):
            sha.update(piece)
    return {'format':'JANUS_BABEL14_SEED2_EXACT_INTEGER_FOURIER_IDENTITY_V1',
            'status':'BABEL14_EXACT_RATIONAL_SOS4_PASS',
            'seed':2,'lift_rows':252,'GF2_nullity':16,
            'nonzero_degree2_multipliers':len(terms),
            'normalization_digits':len(str(D)),
            'normalization_positive':D>0,
            'final_nonzero_Fourier_frequencies':len(final),
            'final_constant_equals_normalization':final[0]==D,
            'expanded_gzip_file':str(output_path),
            'expanded_gzip_sha256':sha.hexdigest(),
            'exact_source_krylov_replay':'PASS',
            'exact_fourier_replay':'PASS'}


def independent_verify(expanded):
    source,lift,labels,Q,e,canonical,touched,active,missing=prepare(2)
    with gzip.open(expanded,'rt',encoding='utf-8') as infile:
        cert=json.load(infile)
    assert cert['format']=='JANUS_BABEL14_SEED2_EXPLICIT_INTEGER_IDENTITY_V1'
    D=int(cert['positive_integer_normalization_D'])
    assert D>0 and len(cert['terms'])==cert['terms_count']
    sums=defaultdict(int)
    for r,u,v in cert['terms']:
        assert 0<=r<252 and u in Q
        coef=int(v)
        add(sums,u,coef)
        for j in lift[r]:
            add(sums,u^labels[j],coef)
    assert sums=={0:D}, ('independent Fourier replay fails',len(sums))
    return {'status':'BABEL14_INDEPENDENT_EXACT_ALL_FREQUENCY_REPLAY_PASS',
            'nonzero_integer_multipliers':cert['terms_count'],
            'degree2_fourier_basis_size':len(Q),'normalization_digits':len(str(D))}


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--circuit',type=Path,default=Path(__file__).with_name('babel14_SEED2_EXACT_RATIONAL_TRANSFER_CIRCUIT.json'))
    ap.add_argument('--output',type=Path,default=Path(__file__).with_name('babel14_SEED2_EXPLICIT_INTEGER_IDENTITY.json.gz'))
    ap.add_argument('--report',type=Path)
    ap.add_argument('--verify-only',action='store_true')
    args=ap.parse_args()
    if args.verify_only:
        result=independent_verify(args.output)
    else:
        result=build(args.circuit,args.output)
    if args.report:
        args.report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True),flush=True)
