#!/usr/bin/env python3
"""Exploratory exact XOR-sector splitting of BABEL-5 zero-defect products.

The 15D kernel of UNSAT126 has a 14D diagonal base sector. The extra
frequency e yields two idempotent sectors chi_e=+1 and chi_e=-1.
This probe maps the 4-character equations into the base 14D algebra
and measures their modular Krylov complexity. Its output alone is NOT
a global degree-four SOS certificate.
"""

import argparse
import json
from pathlib import Path

from janus_babel5_projection import linear_projection
from janus_babel5_kernel import source_data,equations_and_origins
from janus_babel5_krylov import berlekamp_massey


def reduced_equations(equations,sector):
    apply,extra,_=linear_projection()
    bit=extra & -extra
    result=set()
    for support in equations:
        pairs=[]
        for q in support:
            sign=(-1 if sector==-1 and q&bit else 1)
            pairs.append((apply(q),sign))
        pairs=tuple(sorted(pairs))
        assert len({q for q,_ in pairs})==4
        if pairs[0][1]<0:
            pairs=tuple((q,-s) for q,s in pairs)
        result.add(pairs)
    return sorted(result)


def modular_profile(reduced,prime=1000000007,steps=300):
    import numpy as np
    from scipy.sparse import csr_matrix
    m=len(reduced)
    indices=np.fromiter((q for row in reduced for q,_ in row),
                        dtype=np.int32,count=4*m)
    data=np.fromiter((s for row in reduced for _,s in row),
                     dtype=np.int64,count=4*m)
    ptr=np.arange(0,4*(m+1),4,dtype=np.int64)
    a=csr_matrix((data,indices,ptr),shape=(m,16384))
    at=a.transpose().tocsr()
    v=np.zeros(16384,dtype=np.int64)
    v[0]=1
    sequence=[]
    for _ in range(steps):
        sequence.append(int(v[0]))
        v=(at@(a@v))%prime
    polynomial=berlekamp_massey(sequence,prime)
    return {'rows':m,'moment_sequence_length':steps,
       'krylov_degree_mod_prime':len(polynomial)-1,
       'last_coefficient_nonzero_mod_prime':bool(polynomial[-1]),
       'prime':prime}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--steps',type=int,default=400)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    _,_,defects,basis=source_data()
    equations=equations_and_origins(defects,basis)
    report={'status':'SECTOR_MODULAR_EXPLORATION_ONLY',
       'global_equations':len(equations),'idempotent_sector_dimension':16384}
    for sector in (1,-1):
        reduced=reduced_equations(equations,sector)
        report['sector_plus' if sector==1 else 'sector_minus']=modular_profile(
            reduced,steps=args.steps)
    if args.output:
        args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
