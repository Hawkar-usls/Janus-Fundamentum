#!/usr/bin/env python3
"""Exact overlapping-XOR rank-three packet lower bounds.

Each five-term packet consists of two XOR triples sharing one frequency.
Their five characters live in a rank-three binary subspace, and all eight
consistent sign assignments are evaluated *together*. Disjoint packets
can safely be added, giving a global lower bound for the score.
"""

from collections import defaultdict
from itertools import combinations


def packet_min(coeff, frequencies):
    """Exact minimum of a rank<=3 character packet by local enumeration."""
    span = {0: 0}
    independent = []
    for q in frequencies:
        if q in span:
            continue
        old = list(span.items())
        k = len(independent)
        independent.append(q)
        span.update({v ^ q: m | (1 << k) for v, m in old})
    assert len(independent) <= 3
    return min(sum(coeff[q] * (-1 if (span[q] & selector).bit_count() & 1 else 1)
                   for q in frequencies)
               for selector in range(1 << len(independent)))


def rank3_group_bound(coeff):
    """Certified lower bound, plus explicit disjoint 3/5 frequency packets."""
    baseline = coeff.get(0, 0) - sum(abs(v) for q, v in coeff.items() if q)
    present = {q for q, v in coeff.items() if q and v}
    triples = set()
    by_frequency = defaultdict(list)
    for p, q in combinations(sorted(present), 2):
        t = p ^ q
        if t in present:
            tri = tuple(sorted((p, q, t)))
            triples.add(tri)
    for tri in sorted(triples):
        for q in tri:
            by_frequency[q].append(tri)

    candidates = []
    for tri in sorted(triples):
        improvement = packet_min(coeff, tri) + sum(abs(coeff[q]) for q in tri)
        if improvement > 0:
            candidates.append((-improvement, -len(tri), tri))
    overlap_pairs = set()
    for tri_list in by_frequency.values():
        for tri1, tri2 in combinations(tri_list, 2):
            merged = tuple(sorted(set(tri1) | set(tri2)))
            if len(merged) == 5:
                overlap_pairs.add(merged)
    for group in sorted(overlap_pairs):
        improvement = packet_min(coeff, group) + sum(abs(coeff[q]) for q in group)
        if improvement > 0:
            candidates.append((-improvement, -len(group), group))

    candidates.sort()
    occupied = set()
    chosen = []
    total_improvement = 0
    for neg_gain, _, group in candidates:
        if occupied.isdisjoint(group):
            occupied.update(group)
            chosen.append(list(group))
            total_improvement -= neg_gain
    return baseline + total_improvement, chosen

