#!/usr/bin/env python3
"""Independent exact checker for BABEL-2 mixed XOR-triple/block proofs."""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate


FORMAT='JANUS_BABEL2_hybrid_XOR3_BLOCK_v1'


def verify(cert):
    if not __debug__:
        raise RuntimeError('exact verifier requires Python assertions enabled')
    if cert.get('format')!=FORMAT:
        raise ValueError('not a BABEL-2 proof')
    n=cert['n']
    rows=validate(cert['row_triples'],n)
    independent,basis=gf2_kernel(rows,n)
    d=len(basis)
    assert (cert['rank_GF2'],cert['nullity_GF2'])==(len(independent),d)
    order=cert['basis_bit_order']
    assert sorted(order)==list(range(d))
    width=cert['block_width']
    assert type(width) is int and 0<=width<=d
    witness_selector=int(cert['witness_selector_hex'],16)
    assert 0<=witness_selector<(1<<d)
    word=0
    for k,v in enumerate(basis):
        if witness_selector & (1<<k):
            word ^= v
    assert hex(word)==cert['witness_kernel_word_hex']
    assert all((r&word).bit_count()%2==0 for r in rows)
    exact_min=n-2*word.bit_count()
    assert exact_min==cert['minimum_F']
    x=((1<<n)-1)^word
    sat=all((r&x).bit_count()==1 for r in rows)
    assert sat==(n%3==0 and exact_min==-(n//3))
    assert cert['exact_one_status']==('SAT' if sat else 'UNSAT')
    if sat:
        assert cert['witness_true_variables']==[j for j in range(n) if (x>>j)&1]
    else:
        assert 'witness_true_variables' not in cert
    columns=[sum(((v>>j)&1)<<k for k,v in enumerate(basis)) for j in range(n)]
    assert exact_min==sum(-1 if (q&witness_selector).bit_count()&1 else 1
                          for q in columns)

    trie={}
    covered=0
    triple_count=0
    block_checked=0
    hist=Counter()
    assert len(cert['proof_leaves'])==cert['proof_leaf_count']>=1
    for path,mode,claimed_bound,packets in cert['proof_leaves']:
        assert isinstance(path,str) and len(path)<=d and set(path)<=set('01')
        node=trie
        for c in path:
            assert '#' not in node
            node=node.setdefault(c,{})
        assert not node
        node['#']=True
        covered+=1<<(d-len(path))
        hist[mode]+=1
        fixedmask=0
        fixedones=0
        for level,c in enumerate(path):
            bit=1<<order[level]
            fixedmask|=bit
            if c=='1':
                fixedones|=bit
        coeff=defaultdict(int)
        for q in columns:
            rem=q&~fixedmask
            coeff[rem]+= -1 if (q&fixedones).bit_count()&1 else 1

        if mode=='xor3':
            baseline=coeff[0]-sum(abs(a) for q,a in coeff.items() if q)
            gained=0
            used=set()
            for packet in packets:
                assert isinstance(packet,list) and len(packet)==3
                p,q,t=packet
                assert all(type(v) is int and v>0 for v in packet)
                assert len({p,q,t})==3 and p^q==t
                assert all(coeff[v] for v in packet)
                assert not any(v in used for v in packet)
                used.update(packet)
                ap,aq,at=coeff[p],coeff[q],coeff[t]
                minimum=min(ap*sgnp+aq*sgnq+at*sgnp*sgnq
                            for sgnp in (-1,1) for sgnq in (-1,1))
                gained+=minimum+abs(ap)+abs(aq)+abs(at)
                triple_count+=1
            bound=baseline+gained
        elif mode=='block':
            assert not packets
            rem=d-len(path)
            assert rem<=width
            values=[]
            for sub in range(1<<rem):
                c=sum(((sub>>j)&1)<<order[len(path)+j] for j in range(rem))
                score=sum(a*(-1 if (q&c).bit_count()&1 else 1)
                          for q,a in coeff.items())
                values.append(score)
                block_checked+=1
            bound=min(values)
        else:
            raise ValueError(f'unknown proof leaf method {mode}')
        assert bound==claimed_bound
        assert bound>=exact_min,(path,bound,exact_min)

    assert covered==1<<d==cert['symbolically_covered_selectors']
    return {'status':'PROVED_EXACT_MINIMUM',
            'n':n,'rank':len(independent),'nullity':d,
            'exact_one_status':'SAT' if sat else 'UNSAT',
            'minimum_F':exact_min,
            'minimum_defect':n-3*word.bit_count()//2,
            'proof_leaves':len(cert['proof_leaves']),
            'leaf_methods':dict(sorted(hist.items())),
            'xor3_packets_checked':triple_count,
            'local_block_scores_checked':block_checked,
            'selectors_covered':covered}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate',type=Path)
    args=p.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),
                     indent=2,sort_keys=True))


if __name__=='__main__':
    main()
