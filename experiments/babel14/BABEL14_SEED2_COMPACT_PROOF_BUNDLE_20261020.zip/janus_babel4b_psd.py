#!/usr/bin/env python3
"""Exact witnesses for violated *global* degree-4 SOS moment PSD cuts.

The basis comprises distinct Fourier characters representable by XOR sums
of at most two observed variables. Their Gram matrix has entries s_(q xor r).
A negative integer Rayleigh numerator gives a *rational square* separator
L((sum_j v_j chi_qj)^2)<0, independently verifiable without floating point.
NumPy/SciPy are discovery tools only.
"""

import argparse
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

from janus_babel4_rational_certificate import instance_rows
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def moment_basis(instance):
    rows=validate(instance_rows(instance),len(instance_rows(instance)))
    _,kernel=gf2_kernel(rows,len(rows))
    observed=sorted(set(columns_of_kernel(kernel,len(rows))))
    return sorted({0,*observed,*(a^b for a,b in combinations(observed,2))})


def exact_rayleigh(record,q,coefficient):
    """Integer numerator den * L((sum_j coeff_j * chi_qj)^2)."""
    den=record['denominator']
    m=dict(zip(record['frequencies'],record['integer_numerators']))
    assert len(q)==len(coefficient) and len(set(q))==len(q)
    assert all(type(x) is int for x in q+coefficient)
    v=sum(c*c*den for c in coefficient)
    for i in range(len(q)):
        for j in range(i):
            v+=2*coefficient[i]*coefficient[j]*m.get(q[i]^q[j],0)
    return v


def moment_matrix(record,basis):
    import numpy as np
    den=record['denominator']
    m=dict(zip(record['frequencies'],record['integer_numerators']))
    size=len(basis)
    mat=np.empty((size,size),dtype=np.float64)
    for i,q in enumerate(basis):
        mat[i,i]=1.
        for j in range(i):
            val=m.get(q^basis[j],0)/den
            mat[i,j]=mat[j,i]=val
    return mat


def seek_psd_witness(record,*,sparsities=(4,8,16,32,64,128,256),
                     scale=10000):
    import numpy as np
    from scipy.sparse.linalg import eigsh
    basis=moment_basis(record['instance'])
    mat=moment_matrix(record,basis)
    eigenvalue,vectors=eigsh(mat,k=1,which='SA',tol=1e-8,maxiter=10000)
    vector=vectors[:,0]
    order=np.argsort(np.abs(vector))[::-1]
    candidates=[]
    for k in sparsities:
        index=sorted(int(t) for t in order[:min(k,len(basis))])
        raw=[int(round(vector[t]*scale)) for t in index]
        selected=[(basis[i],v) for i,v in zip(index,raw) if v]
        if not selected:
            continue
        queries=[q for q,_ in selected]
        integer_coeff=[x for _,x in selected]
        numerator=exact_rayleigh(record,queries,integer_coeff)
        candidates.append((numerator,queries,integer_coeff))
        if numerator<0:
            return {'status':'EXACT_GLOBAL_DEGREE4_SOS_VIOLATION',
                'instance':record['instance'], 'moment_basis_dimension':len(basis),
                'smallest_eigenvalue_NUMERIC_ONLY':float(eigenvalue[0]),
                'square_terms':len(queries),'queries':queries,
                'integer_coefficients':integer_coeff,
                'integer_numerator':numerator,
                'denominator':record['denominator'],
                'exact_L_square':f'{numerator}/{record["denominator"]}'}
    return {'status':'NO_SHORT_NEGATIVE_RAYLEIGH_FOUND',
            'moment_basis_dimension':len(basis),
            'smallest_eigenvalue_NUMERIC_ONLY':float(eigenvalue[0]),
            'minimum_sparse_integer_numerator':min(c[0] for c in candidates)}


def verify_witness(record,witness):
    assert witness['status']=='EXACT_GLOBAL_DEGREE4_SOS_VIOLATION'
    q=witness['queries']
    basis=set(moment_basis(record['instance']))
    assert set(q)<=basis
    coeff=witness['integer_coefficients']
    assert len(q)==len(coeff)==witness['square_terms']
    num=exact_rayleigh(record,q,coeff)
    assert num==witness['integer_numerator'] and num<0
    assert record['denominator']==witness['denominator']
    return {'status':'EXACT_SOS_SQUARE_COUNTERCUT_VERIFIED',
        'instance':record['instance'],'square_terms':len(q),
        'integer_numerator':num,'denominator':record['denominator']}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('certificate',type=Path)
    ap.add_argument('--output',type=Path)
    ap.add_argument('--verify-witness',type=Path)
    args=ap.parse_args()
    record=json.loads(args.certificate.read_text())
    if args.verify_witness:
        witness=json.loads(args.verify_witness.read_text())
        outcome=verify_witness(record,witness)
    else:
        outcome=seek_psd_witness(record)
        if args.output:
            args.output.write_text(json.dumps(outcome,indent=2,sort_keys=True)+'\n')
    print(json.dumps(outcome,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
