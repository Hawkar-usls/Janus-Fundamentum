#!/usr/bin/env python3
"""Independent exact checker: BABEL-4c rational degree-4 SOS dual.

Only the source geometry/GF(2) nullspace is reused from the established
JANUS frozen-input parser. This verifier does not import the Krylov/discovery
scripts or the moment-map construction used to find the certificate.

The explicit certificate is a list of integer coefficients in lexicographic
order of distinct 4-character product supports.  Fourier coefficient checks
prove an *identity*, not just approximate SDP objective estimates.
"""

import argparse
import hashlib
import json
from fractions import Fraction
from itertools import combinations
from pathlib import Path

from janus_occam_replay import EXPECTED_SHA, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def independently_verify(path):
    root=Path(__file__).resolve().parent
    assert hashlib.sha256((root/'tutte12.am.csv').read_bytes()).hexdigest()==EXPECTED_SHA
    triples=source_triples(root/'tutte12.am.csv')
    n=len(triples)
    assert n==63
    masks=validate(triples,n)
    _,nullbasis=gf2_kernel(masks,n)
    assert len(nullbasis)==14
    columns=columns_of_kernel(nullbasis,n)
    characters={0}
    characters.update(columns)
    characters.update(a^b for a,b in combinations(columns,2))
    low_monomials=sorted(characters)
    assert len(low_monomials)==1450
    products={}
    for r,(i,j,k) in enumerate(triples):
        a,b,c=columns[i],columns[j],columns[k]
        assert a^b^c==0 and len({a,b,c,0})==4
        # In the Boolean group algebra: (1+A+B+C)^2=4(1+A+B+C)
        counts={x:0 for x in [0,a,b,c]}
        for x in [0,a,b,c]:
            for y in [0,a,b,c]:
                assert (x^y) in counts
                counts[x^y]+=1
        assert all(x==4 for x in counts.values())
        for u in low_monomials:
            support=tuple(sorted((u,u^a,u^b,u^c)))
            if support not in products:
                products[support]=(r,u)
    orders=sorted(products)
    assert len(orders)==60354
    cert=json.loads(Path(path).read_text())
    assert cert['format']=='BABEL4C_INTEGER_GROUP_ALGEBRA_DUAL_V1'
    assert cert['instance']=='SCL63'
    den=cert['normalization_D']
    assert isinstance(den,int) and den>0
    coefficients=cert['multipliers']
    assert len(coefficients)==len(orders)
    assert all(type(c) is int for c in coefficients)
    # Entire Boolean Fourier algebra: 16384 exact integer coefficients.
    identity=[0]*(1<<14)
    row_norm=[0]*n
    for support,multiplier in zip(orders,coefficients):
        row,u=products[support]
        assert u in characters
        row_norm[row]+=abs(multiplier)
        for q in support:
            identity[q]+=multiplier
    assert identity==[den]+[0]*((1<<14)-1)
    bound=sum(w*w for w in row_norm)
    assert cert['dual_norm_upper_bound_C']==bound
    gap=Fraction(den*den,12*bound)
    assert gap==Fraction(cert['strict_F_gap_numerator'],
                         cert['strict_F_gap_denominator'])
    assert gap>0
    # For M>=0, |L(chi_q chi_r)|<=1. Thus L(h_r^2)<=row_norm[r]^2.
    # The exact SOS identity plus PSD yields
    #  4*(bound/den)^2 * (63+3*F) >= bound.
    # Equivalently F >= -21+den^2/(12*bound).
    return {'status':'INDEPENDENT_EXACT_RATIONAL_PSD_DUAL_PASS',
       'source_sha256':EXPECTED_SHA,
       'n':n,'GF2_nullity':len(nullbasis),
       'global_degree4_PSD_dimension':len(low_monomials),
       'integer_identity_frequencies_checked':len(identity),
       'integer_identity_terms':len(coefficients),
       'nonzero_identity_terms':sum(bool(c) for c in coefficients),
       'positive_constant_D':den,
       'sum_row_l1_squared_C':str(bound),
       'rational_strict_gap':str(gap),
       'F_lower_bound_exact':f'-21+{gap}',
       'scope':'SOURCE63 global degree-4 moment PSD, not general P=NP'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=independently_verify(args.certificate)
    if args.output:
        args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
