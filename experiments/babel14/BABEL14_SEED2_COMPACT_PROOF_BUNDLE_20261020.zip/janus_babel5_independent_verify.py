#!/usr/bin/env python3
"""Independent exact rational verification of the frozen BABEL-5 SOS dual.

No BABEL-5 discovery/projection/sector/Krylov modules are imported. The
whole proof is checked from the source CSV and 80735 explicit multipliers:
an integer identity on every 15-bit Fourier coefficient and a rational
degree-four SOS lower bound. The previous SCL63 proof is not trusted.
"""

import argparse
import hashlib
import json
from collections import deque
from fractions import Fraction
from itertools import combinations
from pathlib import Path

from janus_occam_replay import EXPECTED_SHA,FIXTURES,cover,source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel


def independently_verify(path):
    sourcepath=Path(__file__).with_name('tutte12.am.csv')
    assert hashlib.sha256(sourcepath.read_bytes()).hexdigest()==EXPECTED_SHA
    source=source_triples(sourcepath)
    frozen_mask=FIXTURES[1][1]
    rows=cover(source,frozen_mask)
    assert len(rows)==126
    masks=validate(rows,126)
    adjacency=[[] for _ in range(252)]
    for i,row in enumerate(rows):
        for j in row:
            adjacency[i].append(126+j)
            adjacency[126+j].append(i)
    visited={0}
    todo=deque([0])
    while todo:
        for target in adjacency[todo.popleft()]:
            if target not in visited:
                visited.add(target)
                todo.append(target)
    assert len(visited)==252
    _,kernel=gf2_kernel(masks,126)
    assert len(kernel)==15
    q=columns_of_kernel(kernel,126)
    Q={0}
    Q.update(q)
    for i,j in combinations(range(126),2):
        Q.add(q[i]^q[j])
    assert len(Q)==2781
    record=json.loads(Path(path).read_text())
    assert record['format']=='BABEL5_UNSAT126_INTEGER_SOS_DUAL_V1'
    assert record['instance']=='UNSAT126'
    assert record['source_mask_hex']==frozen_mask
    assert record['degree2_matrix_dimension']==len(Q)
    assert record['integer_group_algebra_dimension']==1<<len(kernel)
    coeffs=[0]*(1<<len(kernel))
    H=[0]*126
    previous=None
    nonzero=0
    for triple in record['terms']:
        assert len(triple)==3
        r,u,y=triple
        assert all(type(t) is int for t in triple)
        assert 0<=r<126 and u in Q and y
        assert previous is None or (r,u)>previous
        previous=r,u
        H[r]+=abs(y)
        coeffs[u]+=y
        for col in rows[r]:
            coeffs[u^q[col]]+=y
        nonzero+=1
    D=record['normalization_D']
    assert type(D) is int and D>0
    assert coeffs[0]==D and all(c==0 for c in coeffs[1:])
    C=sum(h*h for h in H)
    assert C==record['dual_norm_upper_bound_C']
    gap=Fraction(D*D,12*C)
    assert gap>0
    assert gap==Fraction(record['strict_F_gap_numerator'],
                         record['strict_F_gap_denominator'])
    # All rows have q_a xor q_b xor q_c == 0, proving g_r^2=4g_r.
    for row in rows:
        a,b,c=(q[j] for j in row)
        assert a and b and c and a^b^c==0
        assert len({0,a,b,c})==4
    return {'status':'BABEL5_INDEPENDENT_EXACT_DUAL_PASS',
        'frozen_csv_sha256':EXPECTED_SHA,
        'source_mask_hex':frozen_mask,
        'nullity':len(kernel),
        'connected_incidence_vertices_checked':len(visited),
        'PSD_degree4_matrix_dimension':len(Q),
        'integer_fourier_coefficients_exactly_verified':len(coeffs),
        'integer_row_character_multipliers':nonzero,
        'max_multiplier_bits':max(abs(y).bit_length()
                                  for _,_,y in record['terms']),
        'positive_integer_D':str(D),
        'C_row_l1_norm_squared':str(C),
        'rational_SOS_gap':str(gap),
        'rational_F_bound':f'-42+{gap}',
        'github_CI':'NOT_RUN'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate',type=Path)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    report=independently_verify(args.certificate)
    if args.output:
        args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
