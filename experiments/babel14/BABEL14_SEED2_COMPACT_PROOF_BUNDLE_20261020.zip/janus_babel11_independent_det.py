#!/usr/bin/env python3
"""Independent exact modular Gaussian elimination on compressed SOS4 block.

Uses dense row elimination over GF(p) to verify det(B) != 0 mod p,
**not** Lanczos/Krylov characteristic recurrences. The equitable projection is
reconstructed over Z from the frozen cubic matrix before modular elimination.
No floating-point arithmetic is used.
"""

import argparse
import json
import time
from pathlib import Path

import numpy as np

from janus_babel11_exact_quotient import equitable_partition,quotient
from janus_babel8_krylov_exact import matrices


def modular_rank_dense(B,p=100003,progress=False):
    m=B.shape[0]
    A=np.zeros((m,m),dtype=np.int64)
    for i in range(m):
        start,end=B.indptr[i],B.indptr[i+1]
        A[i,B.indices[start:end]]=B.data[start:end]%p
    rank=0
    determinant=1
    start=time.monotonic()
    for col in range(m):
        candidates=np.flatnonzero(A[rank:,col])
        if not len(candidates):
            continue
        pivot=rank+int(candidates[0])
        if pivot!=rank:
            A[[rank,pivot],:]=A[[pivot,rank],:]
            determinant=(-determinant)%p
        v=int(A[rank,col])
        determinant=determinant*v%p
        scale=pow(v,-1,p)
        factors=(A[rank+1:,col]*scale)%p
        active=np.flatnonzero(factors)+rank+1
        if active.size:
            # Chunked updates avoid massive temporary arrays.
            for chunk in np.array_split(active,max(1,(len(active)+127)//128)):
                if not len(chunk):continue
                val=factors[chunk-rank-1]
                A[chunk,col+1:]=(A[chunk,col+1:] -
                                    val[:,None]*A[rank,col+1:])%p
                A[chunk,col]=0
        rank+=1
        if progress and rank%250==0:
            print(json.dumps({'rank':rank,'dimension':m,
                              'elapsed':round(time.monotonic()-start,2)}),flush=True)
        if rank==m:break
    return rank,determinant if rank==m else 0


def audit(bit=94,p=100003):
    _,M,MT,_,_=matrices(bit)
    C=(M@MT).tocsr()
    colors,history=equitable_partition(C)
    Q,sizes=quotient(C,colors)
    zero=[i for i in range(Q.shape[0]) if Q.indptr[i]==Q.indptr[i+1]]
    keep=[i for i in range(Q.shape[0]) if i not in zero]
    B=Q[keep,:][:,keep].tocsr()
    rank,det=modular_rank_dense(B,p,True)
    report={'bit':bit,'prime':p,'equitable_sizes':history,
            'deleted_zero_cells':zero,'remaining_dimension':B.shape[0],
            'exact_GF_p_rank':rank,'exact_GF_p_determinant_mod_p':det,
            'independent_modular_gaussian_full_rank':rank==B.shape[0],
            'rational_inverse_exists_proved':rank==B.shape[0],
            'method':'INDEPENDENT_DENSE_MODULAR_GAUSSIAN_ELIMINATION'}
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bit',type=int,default=94)
    p.add_argument('--prime',type=int,default=100003)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_BIT94_INDEPENDENT_DET.json'))
    args=p.parse_args()
    report=audit(args.bit,args.prime)
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,sort_keys=True),flush=True)


if __name__=='__main__':main()
