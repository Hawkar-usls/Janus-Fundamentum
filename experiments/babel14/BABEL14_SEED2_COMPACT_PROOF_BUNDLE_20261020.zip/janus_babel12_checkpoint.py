#!/usr/bin/env python3
"""Freeze exact BABEL-12 transcripts and content hashes, validating gates."""

import hashlib
import json
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import make_lift


ROOT=Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit():
    inputs=frozen_instances()
    records=[]
    exact_cells=[50692,30512,30673,20037,50769]
    exact_supports=[81313,40718,40909,40445,81342]
    for seed in range(5):
        quotient_path=ROOT/f'babel12_SCL252_SEED{seed}_ACTIVE_QUOTIENT.json'
        krylov_path=ROOT/f'babel12_SCL252_SEED{seed}_KRYLOV_LOWER.json'
        quotient=json.loads(quotient_path.read_text())
        krylov=json.loads(krylov_path.read_text())
        rows=(inputs['SCL252_seed0'] if seed==0 else
              make_lift(inputs['SCL126_flip68'],seed)[0])
        source_hash=hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()
        assert quotient['status']=='EXACT_EQUITABLE_QUOTIENT'
        assert quotient['current_partition_cells']==exact_cells[seed]
        assert quotient['active_frequencies']==exact_supports[seed]
        assert quotient['equitable_refinement_history'][-1]['stable']
        assert krylov['status']=='EXACT_KRYLOV_DIMENSION_LOWER_BOUND_ONLY'
        assert krylov['prime']==100003
        assert krylov['minimum_Krylov_dimension_over_Q']==(2048 if seed==0 else 1024)
        assert krylov['active_frequency_dimension']==quotient['active_frequencies']
        records.append({'seed':seed,'n':252,'row_list_sha256':source_hash,
                        'gf2_nullity':quotient['kernel_dimension'],
                        'frequency_active_count':quotient['active_frequencies'],
                        'affine_cosets_count':quotient['unique_affine_plane_cosets'],
                        'equitable_quotient_cells':quotient['current_partition_cells'],
                        'krylov_dimension_lower_bound_Q':
                            krylov['minimum_Krylov_dimension_over_Q'],
                        'modular_trace_sha256':krylov['trace_sha256'],
                        'quotient_evidence_sha256':digest(quotient_path),
                        'krylov_evidence_sha256':digest(krylov_path)})
    scripts=['janus_babel12_sparse_oracle.py',
             'janus_babel12_active_normal.py',
             'janus_babel12_krylov_lower.py',
             'janus_babel12_checkpoint.py',
             'test_janus_babel12.py']
    report='JANUS_BABEL12_SPARSE_FOURIER_AND_KRYLOV_GROWTH_20261020.md'
    return {'format':'JANUS_BABEL12_PROVENANCE_EXACT_SPARSE_ORACLE_V1',
        'date_local':'2026-10-20',
        'local_deep_tests':'PASS_4_OF_4',
        'github_actions':'NOT_RUN',
        'source_family':'frozen BABEL10 SCL126 flip68 double covers',
        'exact_SOS_degree4_for_SCL252':'OPEN',
        'all_SCL252_exact_unsat_status':'INHERITED_BABEL10_FULL_GF2_ENUMERATION',
        'all_quotient_integer_equivariance':'PASS_STABLE_REFINEMENT',
        'five_SCL252_cases':records,
        'program_sha256':{name:digest(ROOT/name) for name in scripts},
        'scientific_report_sha256':digest(ROOT/report),
        'bounded_degree_fixed_ell_polynomial_support_theorem':'PROVED',
        'universal_polynomial_solver':'NOT_CONSTRUCTED',
        'P_vs_NP':'OPEN'}


def main():
    obj=audit()
    path=ROOT/'babel12_GATE_CHECKPOINT.json'
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'EXACT_LOCAL_PASS',
                      'five_cases':len(obj['five_SCL252_cases']),
                      'report_sha256':obj['scientific_report_sha256'],
                      'checkpoint_sha256':digest(path)},sort_keys=True))


if __name__=='__main__':main()
