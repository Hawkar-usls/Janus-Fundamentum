#!/usr/bin/env python3
"""Exploratory connected Fano 2-lift tower for degree-growth controls.

The base n=7 is legal cubic-linear and necessarily UNSAT since 3 does
not divide 7. Every iterated double-lift remains UNSAT by divisibility.
Numerical SOS tests are only diagnostics until integer membership proofs.
"""

import json
from itertools import combinations
from pathlib import Path

from janus_babel10_degree_scan import scan
from janus_babel10_lift_family import connected_incidence, make_lift
from janus_occam_solver import gf2_kernel, validate


def fano():
    points = list(range(1, 8))
    rows = [tuple(x - 1 for x in triple)
            for triple in combinations(points, 3)
            if triple[0] ^ triple[1] ^ triple[2] == 0]
    validate(rows, 7)
    assert connected_incidence(rows)
    return rows


def main():
    rows = fano()
    output = []
    for level in range(5):
        n = len(rows)
        assert n % 3 != 0
        _, kernel = gf2_kernel(validate(rows, n), n)
        item = {'level': level, 'n': n, 'kernel_dimension': len(kernel),
                'legal_linear_cubic': True, 'connected': True,
                'UNSAT_certificate': '3 does not divide n',
                'degree_tests': [scan(rows, ell, 2500) for ell in (0, 1)]}
        output.append(item)
        print(json.dumps({k: v for k, v in item.items()
                          if k != 'degree_tests'} | {
                              'degree1_residual': item['degree_tests'][1][
                                  'floating_relative_residual']},
                         sort_keys=True), flush=True)
        if level == 4:
            break
        # First seed yielding a connected lift; record the seed explicitly.
        for seed in range(20):
            lifted, voltage = make_lift(rows, seed + 101 * level)
            if connected_incidence(lifted):
                item['next_lift_seed'] = seed + 101 * level
                rows = lifted
                break
        else:
            raise RuntimeError('no connected signing found among 20')
    Path('babel10_FANO_TOWER_DIAGNOSTICS.json').write_text(
        json.dumps(output, sort_keys=True, indent=2) + '\n')


if __name__ == '__main__':
    main()
