#!/usr/bin/env python3
"""Find a small exact kernel of the 1420-cell Fourier quotient if possible.

Combines exact Z-equitable partition verification with a modular Lanczos
nullvector and attempts to lift its normalized residues to a *verified*
integer vector. A modular nullvector alone is explicitly not a proof.
"""

import argparse
import hashlib
import json
import random
from collections import Counter
from pathlib import Path

import numpy as np

from janus_babel11_exact_quotient import (equitable_partition,quotient,
                                          weighted_lanczos)
from janus_babel8_krylov_exact import matrices


def modular_null(Q,sizes,p=100003,seed=0):
    record=weighted_lanczos(Q,sizes,p,seed,Q.shape[0]+1,True)
    poly=record.pop('polynomial_coefficients_mod_prime')
    assert record['degree']==Q.shape[0] and poly[0]==0
    rng=random.Random(seed)
    start=np.array([rng.randrange(1,p) for _ in range(Q.shape[0])],
                   dtype=np.int64)
    vec=np.zeros(Q.shape[0],dtype=np.int64)
    for c in reversed(poly[1:]):
        vec=(Q.dot(vec)+c*start)%p
    assert np.any(vec)
    assert not np.any(Q.dot(vec)%p)
    return vec,record


def signed_lift(vector,p):
    return [int(x if x<=p//2 else x-p) for x in vector]


def try_integer_kernel(Q,v,p):
    counts=Counter(int(x) for x in v)
    nonzero=[x for x,c in counts.most_common() if x]
    candidates=[]
    for scale in nonzero[:min(len(nonzero),100)]:
        normalized=v*pow(scale,-1,p)%p
        h=signed_lift(normalized,p)
        maxabs=max(abs(x) for x in h)
        candidates.append({'scale':scale,'maxabs':maxabs,
                           'unique_coefficients':len(set(h))})
        if maxabs<=10000:
            exact=Q.dot(np.array(h,dtype=np.int64))
            if not np.any(exact):
                return h,candidates
    return None,candidates


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bit',type=int,default=94)
    p.add_argument('--prime',type=int,default=100003)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_BIT94_QUOTIENT_NULLVECTOR.json'))
    args=p.parse_args()
    _,M,MT,_,_=matrices(args.bit)
    normal=(M@MT).tocsr()
    colors,history=equitable_partition(normal)
    Q,sizes=quotient(normal,colors)
    v,lanczos=modular_null(Q,sizes,args.prime)
    lift,candidates=try_integer_kernel(Q,v,args.prime)
    result={'bit':args.bit,'prime':args.prime,
            'frequency_dimension':normal.shape[0],
            'quotient_dim':Q.shape[0],
            'equitable_history':history,
            'modular_null_at_cell0':int(v[colors[0]]),
            'modular_null_unique_values':len(set(int(x) for x in v)),
            'scale_trials':sorted(candidates,key=lambda c:c['maxabs'])[:12],
            'exact_integer_kernel_found':lift is not None,
            'scientific_status':('EXACT_INTEGER_QUOTIENT_KERNEL_PASS' if
                                 lift is not None else 'MODULAR_ONLY')}
    if lift is not None:
        result['integer_kernel_values_by_cell']=lift
        result['exact_h0_is_zero']=lift[colors[0]]==0
        assert result['exact_h0_is_zero']
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items()
                      if k!='integer_kernel_values_by_cell'},
                     sort_keys=True),flush=True)


if __name__=='__main__':main()
