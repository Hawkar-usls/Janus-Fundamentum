#!/usr/bin/env python3
"""OCCAM-2: exact sparse Walsh subcube certificates, no full Walsh table.

Generates a LOWER bound on the Walsh minimum, and supplies an equality
witness. The proof can be short, but worst-case tree size is exponential.
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate


def columns_of_kernel(basis, n):
    result = [0] * n
    for k, word in enumerate(basis):
        while word:
            bit = word & -word
            result[bit.bit_length() - 1] |= 1 << k
            word -= bit
    return result


def selector_for_word(basis, word):
    """Coordinates in the RREF-style free-variable basis from gf2_kernel."""
    selected = 0
    residual = word
    # The first nonpivot / free bit of each basis vector is not shared by
    # any other basis vector. The lowest set bit need not be the free bit;
    # instead solve a small GF(2) system against the given independent basis.
    pivot = {}
    for k, v in enumerate(basis):
        comb = 1 << k
        while v:
            p = v.bit_length() - 1
            if p in pivot:
                w, m = pivot[p]
                v ^= w
                comb ^= m
            else:
                pivot[p] = (v, comb)
                break
    while residual:
        p = residual.bit_length() - 1
        if p not in pivot:
            raise ValueError('word is not in the computed GF(2) kernel span')
        vector, selector = pivot[p]
        residual ^= vector
        selected ^= selector
    return selected


def walsh_value(columns, selector):
    return sum(-1 if (q & selector).bit_count() & 1 else 1 for q in columns)


def l1_lower_bound(coeff):
    return coeff.get(0, 0) - sum(abs(v) for q, v in coeff.items() if q)


def make_certificate(triples, selector, order=None, metadata=None):
    n = len(triples)
    rows = validate(triples, n)
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5 * n + 100))
    row_basis, kernel = gf2_kernel(rows, n)
    d = len(kernel)
    if not (0 <= selector < (1 << d)):
        raise ValueError('invalid Walsh selector')
    if order is None:
        order = list(range(d))
    if sorted(order) != list(range(d)):
        raise ValueError('order must permute the GF(2) basis coordinates')
    columns = columns_of_kernel(kernel, n)
    target = walsh_value(columns, selector)
    witness_word = 0
    for k, vector in enumerate(kernel):
        if selector & (1 << k):
            witness_word ^= vector
    assert target == n - 2 * witness_word.bit_count()

    leaves = []
    expanded = 0
    def walk(coeff, depth, path):
        nonlocal expanded
        lower = l1_lower_bound(coeff)
        if lower >= target:
            leaves.append([path, lower])
            return
        if depth == d:
            raise ValueError(f'proposed witness is not optimal; better selector {path}')
        expanded += 1
        bit = 1 << order[depth]
        a0, a1 = defaultdict(int), defaultdict(int)
        for q, value in coeff.items():
            remaining = q & ~bit
            a0[remaining] += value
            a1[remaining] += -value if (q & bit) else value
        walk(a0, depth + 1, path + '0')
        walk(a1, depth + 1, path + '1')

    walk(Counter(columns), 0, '')
    covered = sum(1 << (d - len(path)) for path, _ in leaves)
    assert covered == (1 << d)
    data = {
        'format': 'JANUS_OCCAM2_Walsh_subcube_L1_v1',
        'n': n,
        'row_triples': [list(triple) for triple in triples],
        'GF2_rank': len(row_basis),
        'GF2_nullity': d,
        'basis_bit_order': list(order),
        'minimum_walsh_score': target,
        'witness_selector_hex': hex(selector),
        'witness_kernel_word_hex': hex(witness_word),
        'proof_leaves': leaves,
        'leaf_count': len(leaves),
        'internal_node_count': expanded,
        'states_covered_symbolically': covered,
        'enumerated_scores': 1,  # only the equality witness is evaluated
    }
    if metadata:
        data['input_metadata'] = metadata
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('instance', type=Path, help='JSON SCL input with rows')
    parser.add_argument('--selector', required=True, help='Walsh selector integer')
    parser.add_argument('--order', help='Comma-delimited permutation of basis coordinates')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    inp = json.loads(args.instance.read_text())
    selector = int(args.selector, 0)
    order = list(map(int, args.order.split(','))) if args.order else None
    cert = make_certificate(inp['rows'], selector, order)
    args.output.write_text(json.dumps(cert, ensure_ascii=False, indent=1) + '\n')
    print(json.dumps({key: cert[key] for key in (
        'n','GF2_nullity','minimum_walsh_score','leaf_count',
        'states_covered_symbolically','enumerated_scores')}, indent=2))


if __name__ == '__main__':
    main()
