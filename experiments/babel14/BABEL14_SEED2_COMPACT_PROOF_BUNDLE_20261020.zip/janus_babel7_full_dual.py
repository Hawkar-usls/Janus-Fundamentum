#!/usr/bin/env python3
"""BABEL-7 exact rational degree-eight SOS dual for a balanced UNSAT SCL126.

The 20-term local certificate J=4(1-t) handles the new t=-1 sector.
Sparse Fourier corrections have multipliers of character degree <=4.
The original base SOS remains degree 4; the resulting SOS is degree <=8.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from janus_babel7_degree_audit import audit
from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels
from janus_occam_replay import FIXTURES,cover


ROOT=Path(__file__).resolve().parent
LOCAL=ROOT/'babel7_BALANCED_UNSAT126_LOCAL_SECTOR_DUAL.json'


def construct():
    source,base_terms,D=load_base()
    mask=format(int(FIXTURES[1][1],16)^(1<<16),'x')
    lifted=cover(source,mask)
    labels,Q,dim=xor_labels(lifted)
    info,difference,H,reps,witness=audit(16,LOCAL)
    local=json.loads(LOCAL.read_text())
    assert local['normalization_D']==4
    terms=defaultdict(int)
    for (r,u),c in base_terms.items():
        terms[r,reps[u]]+=8*c
    for q,c in difference.items():
        maxdeg,cost,qshift,sign=info['per_remainder_choice'][q]
        assert maxdeg<=4
        for r,u,v in local['terms']:
            target=u^qshift
            assert len(witness[target])<=4
            terms[r,target]+=c*sign*v
    terms={key:val for key,val in terms.items() if val}
    # Exact verification, using only sparse additions (no Fourier FFT).
    freq=defaultdict(int)
    l1=[0]*len(lifted)
    for (r,u),y in terms.items():
        assert len(witness[u])<=4
        l1[r]+=abs(y)
        freq[u]+=y
        for col in lifted[r]:
            freq[u^labels[col]]+=y
    Dfull=8*D
    assert {q:c for q,c in freq.items() if c}=={0:Dfull}
    C=sum(t*t for t in l1)
    gap=Fraction(Dfull*Dfull,12*C)
    record={'format':'JANUS_BABEL7_BALANCED_UNSAT126_DEGREE8_SOS_DUAL_V1',
            'source_csv_sha256':
            '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899',
            'cover_mask_hex':mask,
            'degree_limit_for_multiplier_characters':4,
            'degree_limit_for_SOS':8,
            'local_sector_normalization_D':local['normalization_D'],
            'source_base_normalization_D':D,
            'normalization_D':Dfull,
            'dual_norm_upper_bound_C':C,
            'rational_strict_gap_numerator':gap.numerator,
            'rational_strict_gap_denominator':gap.denominator,
            'terms':[[r,u,y] for (r,u),y in sorted(terms.items())]}
    summary={'status':'BABEL7_BALANCED_UNSAT126_EXACT_DEGREE8_SOS_PASS',
             'source_mask_hex':mask,
             'source_terms':len(base_terms),
             'local_sector_terms':len(local['terms']),
             'minus_sector_corrections':len(difference),
             'full_dual_terms':len(terms),
             'D':str(Dfull),'C':str(C),
             'strict_gap':str(gap),
             'bound_F':f'-42+{gap}',
             'multiplier_degree_max':4,'SOS_degree_max':8,
             'exact_sparse_fourier_support_nonzero':1}
    return record,summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    p.add_argument('--summary',type=Path)
    args=p.parse_args()
    record,summary=construct()
    if args.output:
        args.output.write_text(json.dumps(record,sort_keys=True,
                        separators=(',',':'))+'\n')
        summary['proof_sha256']=hashlib.sha256(args.output.read_bytes()).hexdigest()
    if args.summary:
        args.summary.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps(summary,indent=2,sort_keys=True))


if __name__=='__main__':main()
