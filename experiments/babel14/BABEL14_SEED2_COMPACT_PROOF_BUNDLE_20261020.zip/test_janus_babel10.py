#!/usr/bin/env python3
"""Offline reproducibility checks for exact BABEL-10 lower bounds.

The large degree-4 integer replays were independently executed in this
checkpoint; this fast suite validates their frozen verification artifacts.
Use janus_babel8_krylov_verify.py to re-run each large recurrence.
"""

import hashlib
import json
import unittest
from pathlib import Path

from janus_babel10_cyclic_controls import audit as cyclic_audit
from janus_babel10_exact_lower import verify_document
from janus_babel10_lift_family import audit as lift_audit
from janus_babel10_transfer_lower import (
    exact_base_lower_functional, verify_lift)


ROOT = Path(__file__).parent


class TestBabel10(unittest.TestCase):
    def test_degree1_exact_obstructions_all_frozen(self):
        for name in ('SCL63', *(f'SCL126_flip{bit}'
                                for bit in (16, 59, 68, 81, 94, 132, 168, 169))):
            with self.subTest(instance=name):
                path = ROOT / f'babel10_{name}_EXACT_DEGREE1_OBSTRUCTION.json'
                result = verify_document(json.loads(path.read_text()))
                self.assertEqual(result['independent_integer_frequency_replay'],
                                 'PASS')
                self.assertEqual(result['degree2_SOS_ideal_certificate'],
                                 'IMPOSSIBLE')

    def test_five_connected_unsat_252_covers_and_exact_transfer(self):
        source, labels, dim, h = exact_base_lower_functional()
        summaries = json.loads((ROOT / 'babel10_CONNECTED_SCL252_AUDIT.json')
                               .read_text())
        self.assertEqual(len(summaries), 5)
        for seed in range(5):
            report, rows = lift_audit('SCL126_flip68', source, seed)
            self.assertEqual(report, summaries[seed])
            self.assertEqual(report['exact_SAT_count'], 0)
            self.assertEqual(verify_lift(source, labels, dim, h, rows)[
                'exact_integer_dual_annihilation'], 'PASS')

    def test_cyclic_infinite_family_exact_controls(self):
        records = cyclic_audit()
        self.assertTrue(records is None)  # audit writes a frozen record.
        data = json.loads((ROOT / 'babel10_CYCLIC_FAMILY_EXACT_CONTROLS.json')
                          .read_text())
        self.assertEqual(len(data), 13)
        self.assertTrue(all(x['exact_UNSAT'] for x in data))
        self.assertTrue(all(x['minimal_SOS_degree'] in (0, 2)
                            for x in data))

    def test_exact_degree4_reuse_receipts(self):
        for bit in (59, 81, 132):
            with self.subTest(bit=bit):
                path = ROOT / f'babel10_SCL126_BIT{bit}_DEGREE4_REUSED_POLYNOMIAL.json'
                result = json.loads((ROOT / f'babel10_SCL126_BIT{bit}_DEGREE4_VERIFICATION.json').read_text())
                self.assertEqual(result['rational_SOS_degree'], 4)
                self.assertEqual(result['exact_integer_frequency_replay'], 'PASS')
                self.assertEqual(result['certificate_sha256'],
                                 hashlib.sha256(path.read_bytes()).hexdigest())


if __name__ == '__main__':
    unittest.main()
