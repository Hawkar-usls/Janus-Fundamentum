#!/usr/bin/env python3
"""Exact integer test of the simplest local-tree SOS4 pseudomoment ansatz.

This is an *ansatz check*, not a proof of rational nonmembership unless
every column vanishes exactly. For d(q)=minimal number of coordinate labels
XORing to q, put h(q)=(-1/3)^d(q), on active frequencies D3. Then h(0)=1.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from janus_babel13_common_multiplier import frozen_rows
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


def exact_probe(rows):
    labels,_,d=xor_labels(rows)
    low=degree_witnesses(labels,2)
    high=degree_witnesses(labels,3)
    assert all(len(v)<=3 for v in high.values())
    moments={q:(-1 if len(w)%2 else 1)*3**(3-len(w))
             for q,w in high.items()}
    violations=Counter()
    cols=0
    for triple in rows:
        p=[labels[i] for i in triple]
        for q in low:
            result=moments[q]+sum(moments[q^x] for x in p)
            violations[result]+=1
            cols+=1
    return {'nullity':d,'active_degree3':len(high),
            'raw_generator_count':cols,
            'exact_violating_raw_columns':cols-violations[0],
            'exact_violation_integer_histogram':dict(sorted(violations.items())),
            'moment_at_zero_numerator_over_27':moments[0],
            'status':('EXACT_RATIONAL_LEFT_KERNEL_CERTIFICATE' if
                      len(violations)==1 and 0 in violations else
                      'LOCAL_TREE_ANSATZ_INVALID_NOT_A_DEGREE_LOWER_BOUND')}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    ans=exact_probe(frozen_rows(args.seed))
    ans['seed']=args.seed
    if args.output:
        args.output.write_text(json.dumps(ans,sort_keys=True,indent=2)+'\n')
    print(json.dumps(ans,sort_keys=True),flush=True)
