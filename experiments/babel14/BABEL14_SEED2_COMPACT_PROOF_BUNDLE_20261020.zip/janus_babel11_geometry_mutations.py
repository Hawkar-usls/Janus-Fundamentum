#!/usr/bin/env python3
"""Generate connected legal UNSAT SCL after non-kernel-preserving edge swaps.

This changes parity codes and escapes frozen cover equivalences. Every saved
candidate is revalidated and SAT/UNSAT counted by exhaustive GF(2) enumeration.
"""

import argparse
import hashlib
import json
import random
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import connected_incidence
from janus_occam_solver import gf2_kernel, kernel_search, validate


def edge_swap(rows, random_source, tries=1000):
    n=len(rows)
    for _ in range(tries):
        i,j=random_source.sample(range(n),2)
        a,b=random_source.choice(rows[i]),random_source.choice(rows[j])
        if a==b or a in rows[j] or b in rows[i]:continue
        modified=list(rows)
        modified[i]=tuple(sorted(set(rows[i])-{a}|{b}))
        modified[j]=tuple(sorted(set(rows[j])-{b}|{a}))
        try: validate(modified,n)
        except ValueError: continue
        if not connected_incidence(modified):continue
        return modified,(i,j,a,b)
    return None,None


def generate(source_name='SCL63',seeds=range(10),steps=(1,3,8),
             min_d=9,max_d=18):
    source=frozen_instances()[source_name]
    n=len(source)
    results=[]
    for seed in seeds:
        rng=random.Random(seed)
        rows=list(map(tuple,source))
        history=[]
        for step in range(1,max(steps)+1):
            rows,change=edge_swap(rows,rng)
            if rows is None:break
            history.append(change)
            if step not in steps:continue
            parity,kernel=gf2_kernel(validate(rows,n),n)
            d=len(kernel)
            if not min_d<=d<=max_d:continue
            sat,_,checked=kernel_search(kernel,2*n//3,True)
            if sat!=0:continue
            serial=json.dumps(rows,separators=(',',':'))
            result={'source':source_name,'seed':seed,'steps':step,
                    'rows':rows,'n':n,'rank':n-d,'nullity':d,
                    'connected':True,'linear_cubic':True,'SAT_count':0,
                    'parity_states_checked':checked,
                    'SHA256_rows':hashlib.sha256(serial.encode()).hexdigest(),
                    'edge_swap_history':[list(v) for v in history]}
            results.append(result)
            print(json.dumps({k:v for k,v in result.items()
                              if k not in ('rows','edge_swap_history')},
                             sort_keys=True),flush=True)
    return results


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',choices=['SCL63','SCL126_flip94'],default='SCL63')
    p.add_argument('--seeds',type=int,default=10)
    p.add_argument('--steps',nargs='+',type=int,default=[1,3,8])
    p.add_argument('--min-d',type=int,default=9)
    p.add_argument('--max-d',type=int,default=18)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_GEOMETRY_MUTATIONS.json'))
    args=p.parse_args()
    result=generate(args.source,range(args.seeds),args.steps,args.min_d,
                    args.max_d)
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'retained_UNSAT':len(result)},sort_keys=True),flush=True)


if __name__=='__main__':main()
