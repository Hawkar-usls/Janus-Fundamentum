#!/usr/bin/env python3
"""BABEL-7: modular degree-two group-algebra span on a local UNSAT strip.

Exploratory modular ranks are diagnostics, NOT rational SOS certificates.
The local negative-sector contradiction is a separate exact Boolean fact.
"""

import argparse
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel6_transfer import xor_labels, make_projection


DEFAULT_ROWS = [17,9,29,34,35,47,40]


def span_closure(labels):
    space={0}
    for q in sorted(set(labels)):
        space |= {q^a for a in space}
    return space


def local_equations(rows, source, cover_rows, labels, Q):
    n=len(source)
    local_columns={col for r in rows for sheet in (0,1)
                   for col in cover_rows[r+sheet*n]}
    space=span_closure(labels[j] for j in local_columns)
    admissible=sorted(Q & space)
    origin={}
    for r in rows:
        for sheet in (0,1):
            triple=tuple(labels[j] for j in cover_rows[r+sheet*n])
            for u in admissible:
                support=tuple(sorted([u,*(u^a for a in triple)]))
                origin.setdefault(support,(r+n*sheet,u))
    return sorted(space), sorted(origin), origin, len(admissible)


def modular_probe(supports, target, prime):
    pivots={}
    for support in supports:
        vec={p:1 for p in support}
        while vec:
            q=min(vec)
            if q not in pivots:
                inv=pow(vec[q],-1,prime)
                pivots[q]={p:(v*inv)%prime for p,v in vec.items()}
                break
            multiplier=vec[q]
            for p,v in pivots[q].items():
                new=(vec.get(p,0)-multiplier*v)%prime
                if new:vec[p]=new
                elif p in vec:del vec[p]
    residual={q:c%prime for q,c in target.items() if c%prime}
    while residual:
        q=min(residual)
        if q not in pivots:break
        factor=residual[q]
        for p,v in pivots[q].items():
            new=(residual.get(p,0)-factor*v)%prime
            if new:residual[p]=new
            elif p in residual:del residual[p]
    return {'prime':prime,'rank':len(pivots),
            'target_in_modular_span':not bool(residual),
            'target_residual_terms':len(residual)}


def probe(flips=(16,), rows=DEFAULT_ROWS):
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    base_labels,_,d=xor_labels(source)
    report=[]
    for bit in flips:
        mask=format(int(FIXTURES[1][1],16)^(1<<bit),'x')
        cov=cover(source,mask)
        labels,Q,dim=xor_labels(cov)
        assert dim==d+1
        _,e=make_projection(base_labels,labels,d,dim)
        space,supports,origins,qcount=local_equations(rows,source,cov,labels,Q)
        target={0:1,e:-1}
        assert e in space
        evidence={'flipped_edge_index':bit,'local_rows':rows,
                  'local_fourier_dimension':len(space),
                  'degree2_allowed_multipliers_in_local_span':qcount,
                  'distinct_four_term_equations':len(supports),
                  'extra_character':e,
                  'modular_diagnostics':[
                      modular_probe(supports,target,prime)
                      for prime in (1000000007,1000000009)]}
        report.append(evidence)
    return {'status':'MODULAR_DIAGNOSTIC_ONLY','cases':report}


def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('--flips',type=int,nargs='+',default=[16])
    arg.add_argument('--rows',type=int,nargs='+',default=DEFAULT_ROWS)
    arg.add_argument('--output',type=Path)
    args=arg.parse_args()
    result=probe(args.flips,args.rows)
    if args.output:args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':main()
