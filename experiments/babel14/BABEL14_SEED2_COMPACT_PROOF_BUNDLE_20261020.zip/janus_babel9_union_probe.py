#!/usr/bin/env python3
"""BABEL-9: local-strip union profile for balanced flip 68.

The floating-point LSMR screen here is DIAGNOSTIC ONLY. It does not certify
rational image membership. Actual exact degree-4 evidence is established
separately by the integer Krylov replay.
"""

import argparse
import json
from collections import defaultdict

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsmr

from janus_babel7_degree_audit import degree_witnesses
from janus_babel8_coset_audit import case_data


DEFAULT_UNION = [6, 59, 25, 57, 1, 23, 53, 33, 0, 13]


def audit(bit=68, rows=DEFAULT_UNION, max_iterations=800):
    (source, covered, labels, extra, remainder, reps, quotient,
     defects, targets, rank) = case_data(bit, rows)
    witness = degree_witnesses(labels, 3)
    by_coset = defaultdict(list)
    for q in witness:
        by_coset[quotient(q)].append(q)
    cases = []
    for coset, target in sorted(targets.items()):
        symbols = sorted({q for u in by_coset[coset] for columns in defects.values()
                          for q in (u, *(u ^ a for a in columns))}
                         | set(target))
        index_of = {v: i for i, v in enumerate(symbols)}
        columns = sorted({tuple(sorted((u, *(u ^ a for a in columns))))
                          for columns in defects.values()
                          for u in by_coset[coset]})
        a = coo_matrix((np.ones(4 * len(columns)),
                        ([index_of[q] for support in columns for q in support],
                         np.repeat(np.arange(len(columns)), 4))),
                       shape=(len(symbols), len(columns))).tocsr()
        b = np.zeros(len(symbols))
        for u, value in target.items():
            b[index_of[u]] = float(value)
        norm = float(np.linalg.norm(b))
        solution = lsmr(a, b / norm, atol=1e-12, btol=1e-12,
                        maxiter=max_iterations)
        case = {'coset': coset, 'ambient_rows': len(symbols),
                'distinct_degree3_products': len(columns),
                'target_nonzero_coefficients': len(target),
                'numeric_lsmr_iterations': int(solution[2]),
                'numeric_normalized_residual': float(solution[3]),
                'numeric_stop_code': int(solution[1])}
        cases.append(case)
        print(json.dumps(case, sort_keys=True), flush=True)
    return {'format': 'BABEL9_UNION_NUMERICAL_SCREEN_V1',
            'flip': bit, 'source_rows': list(rows),
            'local_subgroup_rank': rank,
            'ambient_cosets': 1 << (15 - rank),
            'active_cosets': len(targets), 'cosets': cases,
            'scientific_status': 'NUMERICAL_ONLY_NO_RATIONAL_CERTIFICATE'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bit', type=int, default=68)
    parser.add_argument('--rows', type=int, nargs='+', default=DEFAULT_UNION)
    parser.add_argument('--max-iterations', type=int, default=800)
    parser.add_argument('--output', default='babel9_BIT68_UNION_FLOAT_SCREEN.json')
    args = parser.parse_args()
    result = audit(args.bit, args.rows, args.max_iterations)
    with open(args.output, 'w', encoding='utf-8') as stream:
        json.dump(result, stream, sort_keys=True, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
