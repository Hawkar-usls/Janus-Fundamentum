#!/usr/bin/env python3
"""BABEL-7: optimize degree of sector-certificate shifts over lifted dual.

Uses complete 2**15 labels only to compute bounded-degree REPRESENTABILITY,
not for construction of the prior source certificate. Diagnostic only until
the final integer identity is built and checked.
"""

import argparse
import json
from collections import Counter,defaultdict
from pathlib import Path

from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels,make_projection
from janus_occam_replay import FIXTURES,cover


def degree_witnesses(labels,max_degree=5):
    previous={0:()}
    output={0:()}
    for deg in range(1,max_degree+1):
        current={}
        for q,tuple_indices in previous.items():
            for index,v in enumerate(labels):
                target=q^v
                if target not in output and target not in current:
                    current[target]=tuple_indices+(index,)
        output.update(current)
        previous=current
        if len(output)==1<<max(x.bit_length() for x in labels):
            break
    return output


def lifted_source_remainder(source,base_terms,D,cover_rows,labels,Q,pi,e):
    reps={}
    for q in sorted(Q):
        reps.setdefault(pi(q),q)
    H=defaultdict(int)
    for (r,u),c in base_terms.items():
        lifted=reps[u]
        H[lifted]+=c
        for col in cover_rows[r]:
            H[lifted^labels[col]]+=c
    projected=defaultdict(int)
    for q,c in H.items():
        projected[pi(q)]+=c
    assert {q:c for q,c in projected.items() if c}=={0:D}
    bit=e&-e
    canonical=lambda q:(q^e if q&bit else q)
    support={canonical(q) for q,c in H.items() if c}|{0}
    difference={q:(D if q==0 else 0)-(H[q]-H[q^e])
                for q in support}
    return {q:c for q,c in difference.items() if c}, H, reps


def audit(flip=16, local_dual_path=None):
    source,base_terms,D=load_base()
    rows=cover(source,format(int(FIXTURES[1][1],16)^(1<<flip),'x'))
    base_labels,_,d=xor_labels(source)
    labels,Q,dd=xor_labels(rows)
    pi,e=make_projection(base_labels,labels,d,dd)
    difference,H,reps=lifted_source_remainder(
        source,base_terms,D,rows,labels,Q,pi,e)
    if local_dual_path is None:
        local_dual_path=Path(__file__).with_name(
            'babel7_BALANCED_UNSAT126_LOCAL_SECTOR_DUAL.json')
    local=json.loads(Path(local_dual_path).read_text())
    assert local['extra_character']==e
    local_labels=[u for _,u,_ in local['terms']]
    witness=degree_witnesses(labels,max_degree=5)
    assert len(witness)==32768
    base_degree_counts=Counter(len(v) for v in witness.values())
    qdegree_hist=Counter()
    selection={}
    for q,c in difference.items():
        candidates=[]
        for sign,q0 in ((1,q),(-1,q^e)):
            maxdeg=max(len(witness[q0^u]) for u in local_labels)
            cost=sum(len(witness[q0^u]) for u in local_labels)
            candidates.append((maxdeg,cost,q0,sign))
        chosen=min(candidates)
        qdegree_hist[chosen[0]]+=1
        selection[q]=chosen
    return {'flipped_edge_index':flip,'remainder_terms':len(difference),
            'cover_degree_distribution':dict(sorted(base_degree_counts.items())),
            'local_sector_terms':len(local_labels),
            'optimal_shift_max_degree_histogram':dict(sorted(qdegree_hist.items())),
            'max_multiplier_degree':max(qdegree_hist),
            'group_dim':1<<dd,
            'per_remainder_choice':selection},difference,H,reps,witness


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--flip',type=int,default=16)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    record,*_=audit(args.flip)
    concise={key:value for key,value in record.items()
             if key!='per_remainder_choice'}
    if args.output:args.output.write_text(json.dumps(concise,indent=2,
                                                     sort_keys=True)+'\n')
    print(json.dumps(concise,indent=2,sort_keys=True))


if __name__=='__main__':main()
