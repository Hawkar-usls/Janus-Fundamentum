#!/usr/bin/env python3
"""Infinite connected legal UNSAT cyclic SCL control family.

Rows i:{i,i+1,i+3} mod n for n>=7 are 3-regular, connected, linear.
The GF(2) recurrence t^3+t+1 is primitive of order 7; d=3 iff 7|n,
otherwise d=0. No parity word has weight 2n/3 for n divisible by 3.
For d=3 an eight-term exact SOS-degree-2 certificate exists uniformly.
"""

import json
from collections import defaultdict
from pathlib import Path

from janus_babel10_degree_scan import character_products
from janus_babel10_lift_family import connected_incidence
from janus_babel10_small_exact import exact_membership
from janus_occam_solver import gf2_kernel, validate


def cyclic(n):
    assert n >= 7
    rows = [tuple((i + offset) % n for offset in (0, 1, 3))
            for i in range(n)]
    validate(rows, n)
    assert connected_incidence(rows)
    return rows


def verify_universal_eight_term_identity(rows):
    """4 = sum_{r=0}^6 g_r - 3*g_0*(1+chi_2), for 7|n."""
    labels, dimension, _, _ = character_products(rows, 1)
    assert dimension == 3 and len(rows) % 7 == 0
    row0 = rows[0]
    row0_span = {0, *(labels[j] for j in row0)}
    assert labels[2] not in row0_span
    frequencies = defaultdict(int)
    for r in range(7):
        for q in (0, *(labels[j] for j in rows[r])):
            frequencies[q] += 1
    for shift in (0, labels[2]):
        for q in (0, *(labels[j] for j in row0)):
            frequencies[q ^ shift] -= 3
    assert {q: value for q, value in frequencies.items() if value} == {0: 4}
    return True


def audit():
    results = []
    for n in (7, 9, 12, 14, 21, 27, 28, 42, 63, 84, 105, 126, 147):
        rows = cyclic(n)
        _, kernel = gf2_kernel(validate(rows, n), n)
        dimension = len(kernel)
        assert dimension == (3 if n % 7 == 0 else 0)
        for v in kernel:
            assert v.bit_count() == 4 * n // 7 if n % 7 == 0 else 0
        report = {'n': n, 'GF2_nullity': dimension,
                  'legal_linear_cubic': True, 'connected': True,
                  'exact_UNSAT': n % 3 != 0 or all(
                      v.bit_count() != 2 * n // 3
                      for v in kernel)}
        assert report['exact_UNSAT']
        if dimension == 0:
            report['minimal_character_multiplier_degree'] = 0
            report['minimal_SOS_degree'] = 0
            report['identity'] = 'g_r=4 on the zero-dimensional kernel'
        else:
            # Exact rational row-combination, verified coefficientwise.
            lower = character_products(rows, 0)
            assert 0 not in lower[0]
            positive = exact_membership(rows, 1)
            assert positive['membership']
            assert verify_universal_eight_term_identity(rows)
            report['minimal_character_multiplier_degree'] = 1
            report['minimal_SOS_degree'] = 2
            report['exact_positive_certificate_terms'] = (
                positive['nonzero_exact_multiplier_terms'])
            report['exact_positive_certificate_D'] = (
                positive['integer_normalization_D'])
            report['universal_eight_term_formula'] = 'PASS'
        results.append(report)
        print(json.dumps(report, sort_keys=True), flush=True)
    Path('babel10_CYCLIC_FAMILY_EXACT_CONTROLS.json').write_text(
        json.dumps(results, sort_keys=True, indent=2) + '\n')


if __name__ == '__main__':
    audit()
