#!/usr/bin/env python3
"""Exact seven-row negative-sector certificates for all eight balanced lifts.

The strip is found combinatorially: mixed rows force z_u=-1; an unmixed row
with two such u forces z_v=+1; any unmixed row containing two such v is
inconsistent with zero defect. Actual certificate membership and every
Fourier coefficient are checked over Q, not accepted by propagation alone.
"""

import argparse
import json
from collections import defaultdict
from pathlib import Path

from janus_babel6_transfer import xor_labels,make_projection,signed_graph
from janus_babel7_local_dual import construct as sector_dual
from janus_occam_replay import FIXTURES,cover,source_triples


BALANCED_EDGE_FLIPS=(16,59,68,81,94,132,168,169)


def candidate_strips(source,lift,split):
    mixed={}
    for r,row in enumerate(source):
        active=set(row)&split
        if len(active)==2:
            unsplit=next(iter(set(row)-active))
            mixed.setdefault(unsplit,r)
        else:
            assert not active
    forced=set(mixed)
    positive=defaultdict(list)
    for r,row in enumerate(source):
        if set(row)&split:continue
        pairs=set(row)&forced
        if len(pairs)==2:
            variable=next(iter(set(row)-pairs))
            positive[variable].append((r,tuple(sorted(pairs))))
    for r,row in enumerate(source):
        if set(row)&split:continue
        both=sorted(set(row)&positive.keys())
        if len(both)<2:continue
        for aidx in range(len(both)):
            for bidx in range(aidx+1,len(both)):
                a,b=both[aidx],both[bidx]
                for r1,forced1 in positive[a]:
                    for r2,forced2 in positive[b]:
                        strip=[r,r1,r2]+[mixed[u] for u in (*forced1,*forced2)]
                        result=list(dict.fromkeys(strip))
                        assert len(result)<=7
                        yield result,{'final_row':r,'forced_positive':[a,b],
                                      'intermediate_rows':[r1,r2],
                                      'mixed_rows':[mixed[u] for u in
                                                    (*forced1,*forced2)]}


def scan():
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    base_labels,_,d=xor_labels(source)
    cases=[]
    for bit in BALANCED_EDGE_FLIPS:
        mask=format(int(FIXTURES[1][1],16)^(1<<bit),'x')
        lift=cover(source,mask)
        labels,Q,dd=xor_labels(lift)
        assert dd==d+1
        pi,e=make_projection(base_labels,labels,d,dd)
        split,graph,edges=signed_graph(source,lift,labels,e)
        successes=[]
        failure_errors=[]
        for strip,combinatorial in candidate_strips(source,lift,split):
            try:
                certificate,summary=sector_dual(bit,strip)
                successes.append((len(certificate['terms']),certificate,
                                  summary,combinatorial))
                break
            except (ValueError,AssertionError) as error:
                failure_errors.append(str(error)[:120])
        if not successes:
            raise AssertionError(f'no degree2 local strip for bit {bit}: '
                                 f'{failure_errors[:3]}')
        _,proof,summary,combinatorial=min(successes)
        cases.append({'bit':bit,'split_variables':len(split),
                      'signed_edges':len(edges),
                      'local_strip':combinatorial,
                      'certificate':proof,'summary':summary})
    return {'status':'BABEL7_EIGHT_BALANCED_UNSAT_LOCAL_SECTOR_CERTIFICATES_PASS',
            'cases':cases}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    result=scan()
    if args.output:
        args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    summary={'status':result['status'],
             'cases':[{'bit':c['bit'],'strip_size':len(c['certificate']['source_rows_used']),
                'dual_terms':len(c['certificate']['terms']),
                'D':c['certificate']['normalization_D']}
                for c in result['cases']]}
    print(json.dumps(summary,indent=2,sort_keys=True))


if __name__=='__main__':main()
