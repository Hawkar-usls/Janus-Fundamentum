#!/usr/bin/env python3
"""Independent frozen-input rebound of BABEL-3 packet and rational proofs."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel3_rational_verify import verify
from janus_babel3_exact_cuts import overlap_cut
from janus_babel3_exact_pseudomodel import exact_sparse_pseudo,exact_dense5_pseudo
from janus_babel2_factor import components
from janus_babel3_replay import SOURCE_SHA


def main():
    root=Path(__file__).resolve().parent
    csv=root/'tutte12.am.csv'
    assert hashlib.sha256(csv.read_bytes()).hexdigest()==SOURCE_SHA
    source=source_triples(csv)
    fixtures=[('SOURCE63_UNSAT',source,-17,'UNSAT')]
    for name,mask,sat,rank in FIXTURES[:2]:
        fixtures.append((name,cover(source,mask),-42 if sat else -34,
                         'SAT' if sat else 'UNSAT'))
    out={}
    for name,rows,minimum,status in fixtures:
        filename=f'JANUS_BABEL3_{name}_OVERLAP_20261018.json'
        cert=json.loads((root/filename).read_text())
        assert cert['row_triples']==[list(row) for row in rows]
        assert len(components(rows))==1
        result=verify(cert)
        assert (result['minimum_F'],result['exact_one_status'])==(minimum,status)
        out[name]=result
        assert overlap_cut(rows)['status']=='PROVED_RANK3_CUT_VIOLATES_FULL_UNIFORM_POINT'
    pseudo=exact_sparse_pseudo(source)
    assert pseudo['status']=='EXACT_RANK3_PSEUDOMODEL_FEASIBLE'
    assert pseudo['rank3_local_probabilities_checked']==258216
    out['SOURCE63_PSEUDOMODEL']={k:pseudo[k] for k in (
        'status','rank3_local_probabilities_checked',
        'all_rank2_facets_on_nonzero_pseudo_support_checked',
        'minimum_24_times_probability','root_objective')}
    filedata=json.loads((root/'JANUS_BABEL3_EXACT_ROOT_AUDIT_20261018.json').read_text())
    # JSON object keys are strings (root-plane occupancy buckets).
    assert filedata['SOURCE63_FULL_LOCAL_PSEUDOMODEL']==json.loads(json.dumps(pseudo))
    assert filedata['source63']==overlap_cut(source)
    assert filedata['SOURCE63_DENSE5_PSEUDOMODEL']==exact_dense5_pseudo(source)
    for name,mask,_,_ in FIXTURES[:2]:
        assert filedata[name]==overlap_cut(cover(source,mask))
        assert filedata[name+'_DENSE5_PSEUDOMODEL']==exact_dense5_pseudo(cover(source,mask))
    print(json.dumps(out,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
