#!/usr/bin/env python3
"""Exact cyclic-symmetry quotient for Fourier ideal certificates.

The cyclic group acts on source rows and parity characters. Averaging any
certificate of multiplier degree <=ell gives an invariant certificate.
Conversely averaged generators belong to the original span. Thus membership
of e0 in the full Fourier ideal equals membership in the orbit-averaged span.
All quotient elimination is done with Python fractions, not finite fields.
"""

import argparse
import json
from collections import defaultdict
from fractions import Fraction
from math import lcm
from pathlib import Path

from janus_babel11_cyclic_scout import cyclic
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


def coordinate_shift(labels):
    n = len(labels)
    pivots = {}
    for i, label in enumerate(labels):
        a, b = label, labels[(i + 1) % n]
        while a:
            p = a.bit_length() - 1
            if p in pivots:
                x, y = pivots[p]
                a ^= x
                b ^= y
            else:
                pivots[p] = (a, b)
                break
        else:
            assert b == 0, 'coordinate shift not well-defined on character quotient'

    def shift(q):
        out = 0
        while q:
            a, b = pivots[q.bit_length() - 1]
            q ^= a
            out ^= b
        return out

    assert all(shift(v) == labels[(i + 1) % n]
               for i, v in enumerate(labels))
    return shift


def frequency_orbits(labels, d):
    shift = coordinate_shift(labels)
    orbit_of = [-1] * (1 << d)
    orbits = []
    for q in range(1 << d):
        if orbit_of[q] >= 0:
            continue
        trail = []
        value = q
        while orbit_of[value] == -1 and value not in trail:
            trail.append(value)
            value = shift(value)
        assert value == q, 'shift must permute all character frequencies'
        index = len(orbits)
        for v in trail:
            orbit_of[v] = index
        assert len(labels) % len(trail) == 0
        orbits.append(trail)
    assert len(orbits[0]) == 1 and orbits[0][0] == 0
    return orbit_of, orbits


def add_scaled(vector, other, factor):
    for j, value in other.items():
        a = vector.get(j, Fraction(0)) + factor * value
        if a:
            vector[j] = a
        else:
            vector.pop(j, None)


def quotient_membership(rows, ell, full_proof=False):
    labels, _, d = xor_labels(rows)
    n = len(rows)
    orbit_of, orbits = frequency_orbits(labels, d)
    supports = [0, *(labels[j] for j in rows[0])]
    multiplier_basis = degree_witnesses(labels, ell)
    columns = {}
    for u in multiplier_basis:
        counts = defaultdict(int)
        for a in supports:
            counts[orbit_of[a ^ u]] += 1
        col = tuple(sorted((j, int(t * n // len(orbits[j])))
                           for j, t in counts.items()))
        columns.setdefault(col, u)

    pivots = {}
    for col, u in columns.items():
        vec = {j: Fraction(value) for j, value in col}
        combination = {u: Fraction(1)}
        while vec:
            p = min(vec)
            if p not in pivots:
                inv = Fraction(1, 1) / vec[p]
                pivots[p] = ({j: v * inv for j, v in vec.items()},
                             {j: v * inv for j, v in combination.items()})
                break
            row, rep = pivots[p]
            f = vec[p]
            add_scaled(vec, row, -f)
            add_scaled(combination, rep, -f)
    remaining = {0: Fraction(1)}
    answer = {}
    while remaining:
        pivot = min(remaining)
        if pivot not in pivots:
            # The missing-pivot functional is an exact dual obstruction,
            # but a full left-witness is reconstructed separately if needed.
            return {'member': False, 'n': n, 'ell': ell, 'dim': d,
                    'orbit_count': len(orbits),
                    'quotient_rank': len(pivots),
                    'basis_count': len(multiplier_basis),
                    'averaged_column_count': len(columns),
                    'missing_pivot': pivot}
        row, rep = pivots[pivot]
        f = remaining[pivot]
        add_scaled(remaining, row, -f)
        add_scaled(answer, rep, f)

    checked = defaultdict(Fraction)
    for u, scalar in answer.items():
        counts = defaultdict(int)
        for a in supports:
            counts[orbit_of[a ^ u]] += 1
        for j, t in counts.items():
            checked[j] += scalar * n * t / len(orbits[j])
    assert {j: v for j, v in checked.items() if v} == {0: 1}
    denominator = lcm(*(v.denominator for v in answer.values())) if answer else 1
    result = {'member': True, 'n': n, 'ell': ell, 'dim': d,
              'orbit_count': len(orbits), 'quotient_rank': len(pivots),
              'basis_count': len(multiplier_basis),
              'averaged_column_count': len(columns),
              'nonzero_averaged_generators': len(answer),
              'integer_denominator': str(denominator)}
    if full_proof:
        result['multiplier_terms'] = [
            [int(u), int(scalar * denominator)]
            for u, scalar in sorted(answer.items())]
        # Re-verify entire rational Fourier identity from orbit invariance.
        coefficient = defaultdict(int)
        shift = coordinate_shift(labels)
        for u, scalar in answer.items():
            integer_scalar = int(scalar * denominator)
            for first in supports:
                current = u ^ first
                for _ in range(n):
                    coefficient[current] += integer_scalar
                    current = shift(current)
        assert {q: value for q, value in coefficient.items() if value} == {
            0: denominator}
        result['exact_full_frequency_replay'] = 'PASS'
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--n', type=int, default=105)
    p.add_argument('--a', type=int, default=1)
    p.add_argument('--b', type=int, default=12)
    p.add_argument('--ell', type=int, default=1)
    p.add_argument('--proof', action='store_true')
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    record = quotient_membership(cyclic(args.n, args.a, args.b),
                                 args.ell, args.proof)
    if args.output:
        args.output.write_text(json.dumps(record, indent=2,
                                          sort_keys=True) + '\n')
    print(json.dumps(record, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
