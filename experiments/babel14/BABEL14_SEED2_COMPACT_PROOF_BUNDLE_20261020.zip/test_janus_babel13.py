"""Exact local regressions for BABEL-13 (no numerical acceptance)."""

import json
import unittest
from pathlib import Path

from janus_babel13_common_multiplier import (exact_shared_multiplier,
                                              frozen_rows, fwht,
                                              kernel_weights)
from janus_babel13_transfer_reachability import check
from janus_babel13_sector_graph import audit
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


HERE=Path(__file__).resolve().parent


class ExactSharedMultiplierTests(unittest.TestCase):
    def test_walsh_transform_is_involutory_up_to_size(self):
        for values in ([7], [1, 3], [1, -2, 3, 7], [2, -1, 0, 3, 9, 8, -4, 1]):
            n=len(values)
            self.assertEqual(fwht(fwht(list(values))),[n*x for x in values])

    def test_toy_legal_unsat_cyclic_families(self):
        for n in (7, 14, 21, 28):
            rows=[[(i+j)%n for j in (0,1,3)] for i in range(n)]
            labels,_,d=xor_labels(rows)
            weights=kernel_weights(labels,d)
            self.assertTrue(all(w%2==0 for w in weights))
            record=exact_shared_multiplier(rows,max_degree=3)
            self.assertEqual(record['sat_count'],0)
            self.assertEqual(record['exact_inverse_Walsh_identity'],'PASS')
            self.assertLessEqual(record['minimal_coordinate_degree_for_this_SHARED_multiplier'],3)

    def test_active_support_equals_coordinate_degree_plus_one(self):
        rows=frozen_rows(3)
        labels,_,_=xor_labels(rows)
        d2=set(degree_witnesses(labels,2))
        d3=set(degree_witnesses(labels,3))
        active={u^delta for u in d2 for row in rows
                for delta in (0,*(labels[j] for j in row))}
        self.assertEqual(active,d3)
        self.assertEqual(len(active),40445)

    def test_independent_row_defect_counts_for_sampled_parity_states(self):
        for seed in range(5):
            rows=frozen_rows(seed)
            labels,_,d=xor_labels(rows)
            for z in (0,1,2,3,5,7,17,143,(1<<d)-1):
                v=[(q&z).bit_count()%2 for q in labels]
                direct=sum(not any(v[i] for i in triple) for triple in rows)
                self.assertEqual(direct,len(rows)-3*sum(v)//2)

    def test_all_five_archived_integer_replays(self):
        for seed in range(5):
            with self.subTest(seed=seed):
                expect=json.loads((HERE/f'babel13_SCL252_SEED{seed}_SHARED_EXACT.json').read_text())
                actual=exact_shared_multiplier(frozen_rows(seed))
                actual['frozen_seed']=seed
                self.assertEqual(json.loads(json.dumps(actual)),expect)
                self.assertEqual(actual['status'],'EXACT_SHARED_INTEGER_FOURIER_IDENTITY_PASS')

    def test_transfer_sufficient_condition_not_confused_with_obstruction(self):
        for seed in (1,2,3):
            recorded=json.loads((HERE/f'babel13_SCL252_SEED{seed}_TRANSFER_REACHABILITY.json').read_text())
            self.assertEqual(check(seed),recorded)
            self.assertEqual(recorded['status'],'SUPPORT_ONLY_SUFFICIENT_CONDITION_FAIL')
            self.assertGreater(recorded['unreachable_lift_D3'],0)

    def test_exact_antisector_signed_graph(self):
        for seed in (1,2,3):
            with self.subTest(seed=seed):
                expected=json.loads((HERE/f'babel13_SCL252_SEED{seed}_SECTOR_GRAPH.json').read_text())
                self.assertEqual(audit(seed),expected)
                self.assertEqual(expected['independent_row_difference_fourier_checks'],96)
                self.assertEqual(expected['active_D3_nodes_in_balanced_components'],0)
                self.assertGreater(expected['active_D3_nodes_missing_from_graph'],0)


if __name__=='__main__':
    unittest.main()
