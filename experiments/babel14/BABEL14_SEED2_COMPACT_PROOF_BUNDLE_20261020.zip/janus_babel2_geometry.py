#!/usr/bin/env python3
"""Count exact XOR-triple and rank-three frequency planes at BABEL roots."""

import json
from collections import Counter
from itertools import combinations
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def root_geometry(triples):
    n = len(triples)
    rows = validate(triples,n)
    _, basis = gf2_kernel(rows,n)
    m = Counter(columns_of_kernel(basis,n))
    support = sorted(q for q in m if q)
    present = set(support)
    triangles = set()
    for a,b in combinations(support,2):
        c = a ^ b
        if c in present:
            triangles.add(tuple(sorted((a,b,c))))
    planes = set()
    plane_occupancy = {}
    for a,b,c in combinations(support,3):
        # The independent triple spans a rank-3 binary subspace.
        if a ^ b == c:
            continue
        points = tuple(sorted((a,b,c,a^b,a^c,b^c,a^b^c)))
        if len(set(points)) != 7:
            continue
        if points not in plane_occupancy:
            inside = sum(p in present for p in points)
            plane_occupancy[points] = inside
            if inside == 7:
                planes.add(points)
    hist = Counter(plane_occupancy.values())
    return {'n':n,'nullity':len(basis),'B1':m.get(0,0),
            'distinct_nonzero_frequencies':len(support),
            'total_nonzero_multiplicity':sum(m[x] for x in support),
            'xor_triangle_count':len(triangles),
            'complete_rank3_planes':len(planes),
            'rank3_planes_with_at_least_5_terms':sum(v for k,v in hist.items() if k>=5),
            'rank3_plane_occupancy_histogram':dict(sorted(hist.items()))}


def main():
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    out={}
    for name,mask,_,_ in FIXTURES[:2]:
        out[name]=root_geometry(cover(source,mask))
    out['SCL63']=root_geometry(source)
    print(json.dumps(out,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
