#!/usr/bin/env python3
"""Exact rank-three Fourier cut from TWO overlapping XOR triangles.

This excludes the *fully* uniform extended pseudo-character assignment -1/3
on seven frequencies, not necessarily its projected assignment on observed
frequencies. That distinction is crucial when testing an LP relaxation.
"""

import json
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def overlap_cut(triples):
    rows = validate(triples, len(triples))
    _, kernel = gf2_kernel(rows, len(rows))
    support = sorted(set(columns_of_kernel(kernel, len(rows))) - {0})
    observed = set(support)
    lines = set()
    for a,b in combinations(support, 2):
        t = a ^ b
        if t in observed:
            lines.add(tuple(sorted((a,b,t))))
    by_point = defaultdict(list)
    for line in sorted(lines):
        for q in line:
            by_point[q].append(line)
    group = None
    chosen_lines = None
    for point in sorted(by_point):
        for l1,l2 in combinations(by_point[point],2):
            candidate = tuple(sorted(set(l1)|set(l2)))
            if len(candidate)==5:
                group,chosen_lines = candidate,(l1,l2)
                break
        if group:
            break
    assert group is not None
    span={0:0}
    generators=[]
    for q in group:
        if q not in span:
            k=len(generators)
            generators.append(q)
            span.update({v^q:m|(1<<k) for v,m in list(span.items())})
    assert len(generators)==3 and len(span)==8
    plane=sorted(set(span)-{0})
    assert sum(p in observed for p in plane)==5
    extras=[p for p in plane if p not in observed]
    assert len(extras)==2
    # 1 + sum(nontrivial 7 characters) is eight times the indicator of
    # the common +++ state, i.e. takes values exactly 8 or 0.
    possible=[]
    for selector in range(8):
        score=sum(-1 if (span[q]&selector).bit_count()&1 else 1 for q in plane)
        possible.append(score)
    assert sorted(possible)==[-1]*7+[7]
    pseudo=Fraction(-1,3)
    lhs=7*pseudo
    assert lhs == Fraction(-7,3) < -1
    return {'status':'PROVED_RANK3_CUT_VIOLATES_FULL_UNIFORM_POINT',
            'n':len(rows),'kernel_nullity':len(kernel),
            'overlapping_XOR_lines':[list(l) for l in chosen_lines],
            'observed_frequencies':list(group),
            'auxiliary_frequencies':extras,
            'independent_generators':generators,
            'full_rank3_seven_point_plane':plane,
            'cut': 'sum_(q in plane) s_q >= -1',
            'rational_identity':'1 + sum_(q in plane) chi_q = (1+chi_a)(1+chi_b)(1+chi_c) >= 0',
            'full_uniform_value':'-7/3','rational_violation_magnitude':'4/3',
            'cut_value_with_observed_-1/3_auxiliary_+1/3':'-1',
            'note':'Auxiliary moments are free in the projection; this single cut is not an UNSAT gap certificate.'}


def main():
    root=Path(__file__).resolve().parent
    base=source_triples(root/'tutte12.am.csv')
    result={'SCL63':overlap_cut(base)}
    for name,mask,_,_ in FIXTURES[:2]:
        result[name]=overlap_cut(cover(base,mask))
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
