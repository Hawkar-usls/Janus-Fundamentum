#!/usr/bin/env python3
"""Exact integer SOS2 obstruction for an UNSAT, non-cover SCL63 mutation.

CRT only discovers the integer recurrence. The proof verifier independently
constructs the Fourier rows, performs arbitrary-precision normal multiplications
and verifies a nonzero left-null witness over Z.
"""

import argparse
import hashlib
import json
from math import gcd
from pathlib import Path

from janus_babel10_exact_lower import (build_operator, exact_normal,
                                      reconstruct)
from janus_occam_solver import gf2_kernel, kernel_search, validate


def mutation_case(seed=0, steps=1,
                  cases_path=Path('babel11_SCL63_GEOMETRY_MUTATIONS.json')):
    raw = json.loads(cases_path.read_text())
    matches=[record for record in raw
             if record['seed']==seed and record['steps']==steps]
    assert len(matches)==1
    return matches[0]


def verify(proof,source=Path('babel11_SCL63_GEOMETRY_MUTATIONS.json')):
    original=mutation_case(proof['seed'],proof['steps'],source)
    rows=original['rows']
    assert original['SHA256_rows']==proof['SHA256_rows']
    n=len(rows)
    _,ker=gf2_kernel(validate(rows,n),n)
    assert len(ker)==proof['nullity']
    sat,_,count=kernel_search(ker,2*n//3,True)
    assert sat==0 and count==(1<<len(ker))
    generators,_,dim,basis,bound=build_operator(rows,1)
    poly=proof['polynomial_coefficients_low_to_high']
    assert dim==proof['nullity']
    assert len(generators)==proof['Fourier_generator_count']
    assert basis==proof['multiplier_basis_size']
    assert bound==proof['normal_row_sum_bound']
    assert poly[0]==0 and poly[-1]==1
    current=[0]*(1<<dim)
    for c in reversed(poly[1:]):
        current=exact_normal(current,generators)
        current[0]+=c
    assert current[0]!=0
    assert all(sum(current[q] for q in line)==0 for line in generators)
    assert not any(exact_normal(current,generators))
    divisor=0
    for coeff in current:
        divisor=gcd(divisor,abs(coeff))
    return {'status':'EXACT_INTEGER_SOS2_OBSTRUCTION_PASS',
            'source_SCL63_mutation_seed':proof['seed'],
            'steps':proof['steps'],'n':n,'nullity':dim,
            'SAT_count_exact':0,'parity_states_checked':count,
            'recurrence_degree':len(poly)-1,
            'dual_h0':str(current[0]),
            'dual_gcd':str(divisor),
            'rational_SOS_minimum_lower_bound':4,
            'integer_pairing_Mt_h_equals_zero':'PASS'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--steps',type=int,default=1)
    p.add_argument('--max-primes',type=int,default=160)
    p.add_argument('--verify-only',type=Path)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_MUTATION_SEED0_SOS2_EXACT_OBSTRUCTION.json'))
    args=p.parse_args()
    if args.verify_only:
        doc=json.loads(args.verify_only.read_text())
    else:
        case=mutation_case(args.seed,args.steps)
        supports,normal,d,basis,bound=build_operator(case['rows'],1)
        poly,crt=reconstruct(supports,normal,args.max_primes)
        assert poly[0]==0, 'not an SOS2 lower obstruction'
        doc={'format':'BABEL11_NONCOVER_INTEGER_LOWER_SOS2_V1',
             'seed':args.seed,'steps':args.steps,'n':len(case['rows']),
             'nullity':d,'SHA256_rows':case['SHA256_rows'],
             'Fourier_generator_count':len(supports),
             'multiplier_basis_size':basis,
             'normal_row_sum_bound':bound,
             'polynomial_coefficients_low_to_high':poly,**crt}
        args.output.write_text(json.dumps(doc,sort_keys=True,
                                          separators=(',',':'))+'\n')
    result=verify(doc)
    if not args.verify_only:
        result['proof_sha256']=hashlib.sha256(args.output.read_bytes()).hexdigest()
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=='__main__':main()
