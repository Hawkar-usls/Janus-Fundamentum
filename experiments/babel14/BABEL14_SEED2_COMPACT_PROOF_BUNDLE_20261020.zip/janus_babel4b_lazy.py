#!/usr/bin/env python3
"""BABEL-4b polynomial separation oracles + lazy LP, discovery-only.

Every generated rank4 cut and every generated SOS square is symbolically
valid for an actual distribution. A numerical LP objective alone is never
regarded as a proof: a separate exact primal or dual verifier is required.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from janus_babel4_lp import make_model,solve_lp
from janus_babel4_scan import selected_rank4_planes,basis_patterns,moment_three
from janus_babel4_all_observed import first_violation
from janus_babel4b_sos_cliques import find_negative_five_squares,verify_square
from janus_babel4_rational_certificate import instance_rows,verify
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel


def rationalize_solution(instance,model,result,grid_denominator):
    # Fixed rational grid. This point is used only to FIND exact violated
    # cuts; it is not silently accepted as an LP-feasible proof.
    den=grid_denominator
    vals=[int(round(float(x)*den)) for x in result.x]
    return {'format':'BABEL4_PSEUDOMOMENTS_V1','instance':instance,
        'rank4_limit':0,'denominator':den,
        'frequencies':model['freqs'],
        'integer_numerators':vals,
        'numeric_objective_is_not_proof':float(result.fun)}


def initial_selected_rank4(observed,n):
    rank4,dense=selected_rank4_planes(observed)
    positive={q for p in dense for q in p if q not in observed}
    scored=[]
    for space in rank4:
        _,pattern=basis_patterns(space[1:])
        margin=min(3+sum(moment_three(q,observed,positive)*(
               -1 if (pat&z).bit_count()&1 else 1)
               for q,pat in pattern.items() if q)
               for z in range(16))
        scored.append((margin,space))
    scored.sort()
    return [space for _,space in scored[:n]]


def run(args):
    triples=instance_rows(args.instance)
    _,kernel=gf2_kernel(validate(triples,len(triples)),len(triples))
    observed=set(columns_of_kernel(kernel,len(triples)))
    selected=set(initial_selected_rank4(observed,args.initial))
    squares=[]
    present_squares=set()
    history=[]
    for step in range(args.iterations):
        model=make_model(triples,selected_rank4=selected,sos_squares=squares)
        numeric=solve_lp(model,time_limit=args.time_limit,method='highs-ipm')
        if not numeric.success:
            state={'iteration':step,'status':'NUMERIC_LP_STOP',
                  'message':numeric.message,'selected_rank4':len(selected),
                  'sos_cuts':len(squares)}
            print(json.dumps(state,sort_keys=True),flush=True)
            history.append(state)
            break
        record=rationalize_solution(args.instance,model,numeric,args.grid_denominator)
        cut_report=first_violation(args.instance,record,collect=args.oracle_collect)
        cut_list=[tuple(p) for p in cut_report.get('most_violated_rank4_planes',[])
                  if tuple(p) not in selected]
        found_squares=find_negative_five_squares(record,maximum=args.add_sos,
                                                exclude=present_squares)
        for cut in found_squares:
            assert verify_square(record,cut)<0
        added_rank4=cut_list[:args.add_rank4]
        selected.update(added_rank4)
        for cut in found_squares:
            q=tuple(cut['queries'])
            squares.append((q,tuple(cut['integer_coefficients'])))
            present_squares.add(q)
        state={'iteration':step,'status':'NUMERIC_LP_OPTIMAL_NO_PROOF',
               'objective_float':float(numeric.fun),
               'selected_rank4':len(selected),
               'added_rank4':len(added_rank4),
               'sos_cuts':len(squares),'added_sos':len(found_squares),
               'observed_fourtuples_tested_exact':cut_report['observed_fourtuples_checked'],
               'observed_fourtuples_violating_exact':cut_report.get('violating_fourtuples',0),
               'variable_count':len(model['freqs']),
               'denominator_digits':len(str(record['denominator']))}
        history.append(state)
        print(json.dumps(state,sort_keys=True),flush=True)
        if not added_rank4 and not found_squares:
            try:
                # First prove feasibility of the original selected family.
                passed=verify(record)
            except AssertionError as exc:
                state['status']='ORACLE_STALL_NONEXACT_PRIMAL'
                state['verification_error']=repr(exc)
                break
            # Even if no five-term cut is found, arbitrary PSD squares may
            # still be violated. Do not claim global PSD feasibility here.
            state['status']='NO_FURTHER_RANK4_OR_FIVE_SQUARE_CUTS'
            state['exact_selected_family_feasibility']=passed['status']
            if args.output_primal:
                args.output_primal.write_text(json.dumps(record,separators=(',',':'))+'\n')
            break
    if args.output_history:
        args.output_history.write_text(json.dumps(history,indent=2,sort_keys=True)+'\n')
    return history


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--instance',choices=['SCL63','UNSAT126'],default='SCL63')
    a.add_argument('--initial',type=int,default=500)
    a.add_argument('--add-rank4',type=int,default=200)
    a.add_argument('--add-sos',type=int,default=100)
    a.add_argument('--oracle-collect',type=int,default=1000)
    a.add_argument('--iterations',type=int,default=12)
    a.add_argument('--time-limit',type=float,default=100)
    a.add_argument('--grid-denominator',type=int,default=300000)
    a.add_argument('--output-history',type=Path)
    a.add_argument('--output-primal',type=Path)
    args=a.parse_args()
    run(args)


if __name__=='__main__':
    main()
