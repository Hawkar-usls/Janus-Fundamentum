#!/usr/bin/env python3
"""Exact POLYNOMIAL 1-in-3 solver for arbitrary cyclic three-shift instances.

Let the n constraints be x_i+x_{i+a}+x_{i+b}=1 in ordinary integers,
with column and row subscripts interpreted modulo n. Put
g=gcd(n,a,b), m=n/g, A=a/g, B=b/g. The g connected components are
copies of Z_m with shifts (0,A,B). By necessity of (T1) in the
Coven--Meyerowitz integer-tiling theorem, each connected component is
SAT iff 3|m and {A mod 3,B mod 3}={1,2}. A period-3 assignment suffices.

The theorem is external number theory; the algorithm and SAT witness
verification are elementary. No assertion about arbitrary noncyclic SCL.
"""

import argparse
import json
from collections import Counter
from math import gcd
from pathlib import Path

from janus_babel11_cyclic_scout import valid_offsets


def decide(n, a, b, construct_witness=True):
    if not (n >= 3 and 0 < a < b < n):
        raise ValueError('expected n>=3 and 0<a<b<n')
    g = gcd(n, gcd(a, b))
    size = n // g
    normalized = (a // g, b // g)
    sat = size % 3 == 0 and {normalized[0] % 3,
                             normalized[1] % 3} == {1, 2}
    result = {'n':n, 'offsets':[a,b], 'component_count':g,
              'component_size':size, 'normalized_offsets':list(normalized),
              'status':'SAT' if sat else 'UNSAT',
              'runtime_class':'O(n)_including_input_or_witness',
              'proof_source': 'Coven--Meyerowitz necessity T1 for integer tiles'}
    if sat:
        result['proof_type']='PERIOD3_CONSTRUCTIVE'
        if construct_witness:
            # Every component r (mod g) selects the period-3 residue zero.
            chosen=[j for j in range(n) if (j//g)%3 == 0]
            selection=set(chosen)
            assert len(chosen)==n//3
            assert all(sum(((i+shift)%n in selection)
                           for shift in (0,a,b))==1 for i in range(n))
            result['ones']=chosen
            result['independently_verified_all_rows']=True
    elif size%3:
        result['proof_type']='COMPONENT_DIVISIBILITY'
    else:
        result['proof_type']='PRIME3_CYCLOTOMIC_OBSTRUCTION'
        result['logical_certificate']={
            'component_connected_by_gcd':True,
            'T1_forces_Phi_3power_factor':True,
            'higher_3power_implies_3_divides_both_offsets':True,
            'contradiction_to_component_gcd_one':True,
            'no_Phi3_factor_since_residues_not_0_1_2':True}
    return result


def regression(scout_path=Path('babel11_CYCLIC_ALL_NONZERO126_SCOUT.json')):
    data=json.loads(scout_path.read_text())
    cases=data['cases']
    outcomes=Counter()
    for case in cases:
        prediction=decide(case['n'],case['a'],case['b'],False)
        assert prediction['status']==case['status'],case
        assert prediction['component_count']==1
        outcomes[case['status']]+=1
    # Cases with trivial parity kernel are all UNSAT and degree0.
    nullity_zero=data['nullity_histogram']['0']
    result={'checked_nonzero_GF2_cases':len(cases),
            'independently_counted_zero_GF2_cases':nullity_zero,
            'total_connected_linear_cyclic_cases':len(cases)+nullity_zero,
            'SAT':outcomes['SAT'],
            'UNSAT':outcomes['UNSAT']+nullity_zero,
            'theorem_vs_exact_exhaustive_GF2_replay':'PASS',
            'complexity':'O(n) with explicit rows/witness',
            'scientific_scope':'CYCLIC_SCL_ONLY'}
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--n',type=int,default=105)
    p.add_argument('--a',type=int,default=1)
    p.add_argument('--b',type=int,default=12)
    p.add_argument('--regression',action='store_true')
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    result=regression() if args.regression else decide(args.n,args.a,args.b)
    if args.output:args.output.write_text(json.dumps(result,sort_keys=True,
                                                     indent=2)+'\n')
    print(json.dumps(result,sort_keys=True),flush=True)


if __name__=='__main__':main()
