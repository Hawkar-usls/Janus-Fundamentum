#!/usr/bin/env python3
"""Independently tie BABEL-2 proofs to frozen CSV, masks and 3x source."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES,cover,source_triples
from janus_babel2_verify import verify
from janus_babel2_factor_verify import verify as factor_verify


def main():
    root=Path(__file__).resolve().parent
    source_path=root/'tutte12.am.csv'
    sha=hashlib.sha256(source_path.read_bytes()).hexdigest()
    source=source_triples(source_path)
    report={}
    for name,mask,sat,rank in FIXTURES[:2]:
        cert=json.loads((root/('JANUS_BABEL2_'+name+'_BLOCK6_20261018.json')).read_text())
        assert cert['input_metadata']=={'frozen_fixture':name,
                                        'tutte12_sha256':sha,'mask_hex':mask}
        assert cert['row_triples']==cover(source,mask)
        result=verify(cert)
        assert result['rank']==rank
        assert (result['exact_one_status']=='SAT')==bool(sat)
        report[name]=result
    factor=json.loads((root/'JANUS_BABEL2_3xSCL63_FACTOR_20261018.json').read_text())
    assert factor['row_triples']==[[j+63*k for j in row]
                                    for k in range(3) for row in source]
    assert factor['input_metadata']=={'source_sha256':sha,
                                      'operation':'three disjoint SCL63 copies',
                                      'connected':False}
    report['3xSCL63']=factor_verify(factor)
    print(json.dumps(report,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
