#!/usr/bin/env python3
"""Exact-rational degree-6 transfer for balanced BABEL-8 cover candidates.

Modular CRT only discovers coefficients. Every active coset is verified over Q
and every completed 126-row identity verified coefficientwise over Z.
"""

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from fractions import Fraction
from math import lcm
from pathlib import Path

from janus_babel6_gate import load_base
from janus_babel7_degree6_dual import (PRIMES, crt_values, recover,
                                       sparse_fourier_check)
from janus_babel7_degree_audit import degree_witnesses
from janus_babel7_local_dual import modular_certificate
from janus_babel8_coset_audit import case_data


def construct(bit, rows, max_cosets=None):
    source, base_terms, D = load_base()
    (source, lifted, labels, extra, remainder, reps, quotient, defects,
     targets, rank) = case_data(bit, rows)
    degree3 = degree_witnesses(labels, 3)
    by_coset = defaultdict(list)
    for u in degree3:
        by_coset[quotient(u)].append(u)

    correction = defaultdict(Fraction)
    denominators = Counter()
    term_counts = {}
    for index, (coset, target) in enumerate(sorted(targets.items())):
        if max_cosets is not None and index >= max_cosets:
            break
        origin = {}
        for row, columns in defects.items():
            for u in by_coset[coset]:
                four = tuple(sorted((u, *(u ^ a for a in columns))))
                origin.setdefault(four, (row, u))
        supports = sorted(origin)
        solutions = []
        ranks = []
        for prime in PRIMES:
            try:
                solution, rank_mod = modular_certificate(
                    supports, target, prime)
            except ValueError as error:
                raise ValueError(f'flip {bit}, coset {coset}: '
                                 'degree-3 local correction NOT in modular '
                                 f'span modulo {prime}') from error
            solutions.append(solution)
            ranks.append(rank_mod)
        if len(set(ranks)) != 1:
            raise ValueError(f'modular rank drift for flip {bit} coset {coset}')
        combined_indices = set().union(*(set(sol) for sol in solutions))
        local = defaultdict(Fraction)
        for equation in combined_indices:
            residues = [sol.get(equation, 0) for sol in solutions]
            val, mod = crt_values(residues, PRIMES)
            rational = recover(val, mod)
            if rational:
                local[origin[supports[equation]]] += rational
                denominators[rational.denominator] += 1
        # Exact identity for each coset: no field or floating point remains.
        got = defaultdict(Fraction)
        for (row, u), y in local.items():
            got[u] += y
            for a in defects[row]:
                got[u ^ a] += y
        if {q: z for q, z in got.items() if z} != target:
            raise AssertionError(f'flip {bit}, coset {coset}: '
                                 'rational exact verification failed')
        for key, val in local.items():
            correction[key] += val
        term_counts[coset] = sum(bool(x) for x in local.values())

    if max_cosets is not None:
        return None, {'bit': bit, 'cosets_checked_exactly': len(term_counts),
                      'rational_pass': True,
                      'denominator_histogram': dict(denominators)}

    combined = defaultdict(Fraction)
    for (r, u), y in base_terms.items():
        combined[r, reps[u]] += 4 * y
    for key, val in correction.items():
        combined[key] += val
    denominator = 1
    for y in combined.values():
        denominator = lcm(denominator, y.denominator)
    integer_terms = {key: int(y * denominator)
                     for key, y in combined.items() if y}
    assert all(u in degree3 for _, u in integer_terms)
    Dfull = 4 * D * denominator
    C = sparse_fourier_check(lifted, labels, integer_terms, Dfull)
    gap = Fraction(Dfull ** 2, 12 * C)
    assert gap > 0
    record = {'format': 'JANUS_BABEL8_BALANCED_UNSAT126_DEGREE6_SOS_DUAL_V1',
              'flipped_base_edge_index': bit,
              'source_csv_sha256':
              '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899',
              'cover_mask_hex':
              format(int('f3f8bcef56c536a5d5a2a6967e9947a803340bba408e0c5', 16)
                     ^ (1 << bit), 'x'),
              'local_strip': rows,
              'fourier_cosets': len(targets),
              'multiplier_character_degree': 3,
              'SOS_degree': 6,
              'normalization_D': Dfull,
              'dual_norm_upper_bound_C': C,
              'strict_gap_numerator': gap.numerator,
              'strict_gap_denominator': gap.denominator,
              'terms': [[r, u, y] for (r, u), y in sorted(integer_terms.items())]}
    summary = {'status': 'BABEL8_EXACT_RATIONAL_DEGREE6_SOS_TRANSFER_PASS',
               'bit': bit, 'local_subgroup_rank': rank,
               'active_cosets': len(targets),
               'cosets_independently_verified_over_Q': len(term_counts),
               'basis_degree3_size': len(degree3),
               'exact_terms': len(integer_terms),
               'integral_multiplier_scaling': denominator,
               'max_character_degree':
               max(len(degree3[u]) for _, u in integer_terms),
               'D': str(Dfull), 'C': str(C),
               'strict_F_lower_bound': f'-42+{gap}',
               'denominator_histogram': dict(denominators)}
    return record, summary


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bits', type=int, nargs='+', default=[59, 81, 132])
    ap.add_argument('--rows', type=int, nargs='+',
                    help='override the seven source rows (only with one --bits value)')
    ap.add_argument('--first-cosets', type=int)
    args = ap.parse_args()
    archive = json.loads(Path(__file__).with_name(
        'babel7_EIGHT_BALANCED_LOCAL_SECTOR_CERTIFICATES.json').read_text())
    strips = {c['bit']: c['certificate']['source_rows_used']
              for c in archive['cases']}
    reports = []
    for bit in args.bits:
        if args.rows is not None and len(args.bits) != 1:
            ap.error('--rows requires a single --bits value')
        proof, report = construct(bit, args.rows or strips[bit], args.first_cosets)
        if proof:
            path = Path(__file__).with_name(
                f'babel8_BALANCED_BIT{bit}_DEGREE6_EXACT_DUAL.json')
            path.write_text(json.dumps(proof, sort_keys=True,
                                       separators=(',', ':')) + '\n')
            report['proof_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
            Path(__file__).with_name(
                f'babel8_DEGREE6_EXACT_TRANSFER_REPORT_BIT{bit}.json').write_text(
                json.dumps(report, indent=2, sort_keys=True) + '\n')
        reports.append(report)
        print(json.dumps({k: v for k, v in report.items()
                          if k != 'denominator_histogram'},
                         sort_keys=True), flush=True)
    Path(__file__).with_name('babel8_DEGREE6_EXACT_TRANSFER_REPORT.json').write_text(
        json.dumps(reports, indent=2, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
