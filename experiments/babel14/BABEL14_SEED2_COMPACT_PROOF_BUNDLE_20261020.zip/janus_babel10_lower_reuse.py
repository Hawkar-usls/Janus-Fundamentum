#!/usr/bin/env python3
"""Exact verification of recycled SOS-2 LOWER Krylov polynomials.

Never infer equality from modular residues. Rebuild M, replay P(C)e0 over Z,
and test the explicit nonzero left-null functional for each target cover.
"""

import hashlib
import json
from pathlib import Path

from janus_babel10_exact_lower import verify_document


def main():
    for source, targets in ((16, (59, 81, 132)), (94, (168, 169))):
        base = json.loads(Path(
            f'babel10_SCL126_flip{source}_EXACT_DEGREE1_OBSTRUCTION.json'
        ).read_text())
        for target in targets:
            copy = dict(base)
            copy['instance'] = f'SCL126_flip{target}'
            path = Path(
                f'babel10_SCL126_flip{target}_EXACT_DEGREE1_OBSTRUCTION.json')
            path.write_text(json.dumps(copy, separators=(',', ':'),
                                       sort_keys=True) + '\n')
            result = verify_document(copy)
            result['proof_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
            print(json.dumps({k: v for k, v in result.items()
                              if 'witness_h0' not in k and
                              'witness_gcd' not in k}, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
