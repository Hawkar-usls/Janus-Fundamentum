#!/usr/bin/env python3
"""BABEL-9: sparse-support Gram compression, with exact small tests.

If every generator has four integer Fourier coefficients, no 2**d-sized
matrix is required to compute fixed-degree SOS ideal membership. This file
demonstrates the Gram identity with exact integer/rational arithmetic.
"""

import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from janus_babel6_transfer import xor_labels
from janus_occam_replay import FIXTURES, cover, source_triples


def incidence_gram(supports):
    """Return G=M^T M and b=M^T delta_0 without constructing all rows."""
    number = len(supports)
    inverted = defaultdict(list)
    for j, support in enumerate(supports):
        assert len(support) == 4
        for q in support:
            inverted[q].append(j)
    gram = [defaultdict(int) for _ in supports]
    for columns in inverted.values():
        for i in columns:
            for j in columns:
                gram[i][j] += 1
    b = [support.count(0) for support in supports]
    assert all(4 <= gram[i][i] <= 16 for i in range(number))
    return gram, b, len(inverted)


def fourier_multiply(supports, coefficients):
    result = defaultdict(int)
    for support, scalar in zip(supports, coefficients):
        for q in support:
            result[q] += scalar
    return {q: c for q, c in result.items() if c}


def tiny_exact_solve(matrix, rhs):
    """Fraction Gaussian elimination for a tiny independent Gram example."""
    n = len(rhs)
    extended = [[Fraction(matrix[i].get(j, 0)) for j in range(n)] +
                [Fraction(rhs[i])] for i in range(n)]
    for col in range(n):
        at = next(i for i in range(col, n) if extended[i][col])
        extended[col], extended[at] = extended[at], extended[col]
        inv = 1 / extended[col][col]
        extended[col] = [v * inv for v in extended[col]]
        for row in range(n):
            if row != col:
                factor = extended[row][col]
                extended[row] = [a - factor * b for a, b in
                                 zip(extended[row], extended[col])]
    return [extended[i][-1] for i in range(n)]


def checks():
    # Each of five columns has exactly four distinct nonzero entries.
    # This small incidence is algebraic test data, not a legal SCL instance.
    toy = [tuple(j for j in range(5) if j != omitted)
           for omitted in range(5)]
    g, b, t = incidence_gram(toy)
    y = tiny_exact_solve(g, b)
    assert fourier_multiply(toy, y) == {0: Fraction(1)}
    assert sum(Fraction(b[i]) * y[i] for i in range(5)) == 1

    # An arbitrary legal SCL may collapse characteristic labels; the
    # general theorem must support Fourier multiplicities exactly.
    degenerate = [(0, 0, 1, 1), (0, 0, 0, 0)]
    deg_gram, deg_b, _ = incidence_gram(degenerate)
    assert [deg_gram[0][0], deg_gram[0][1], deg_gram[1][1]] == [8, 8, 16]
    assert deg_b == [2, 4]
    assert fourier_multiply(degenerate, [3, 5]) == {0: 26, 1: 6}

    # On the real frozen bit-68 graph, directly check Gx=M^T(Mx) over Z.
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    mask = format(int(FIXTURES[1][1], 16) ^ (1 << 68), 'x')
    covered = cover(source, mask)
    labels, _, dimension = xor_labels(covered)
    supports = sorted({tuple(sorted((0, *(labels[i] for i in row))))
                       for row in covered})
    gram, b, support_size = incidence_gram(supports)
    x = [((j * 17 + 23) % 11) - 5 for j in range(len(supports))]
    direct = fourier_multiply(supports, x)
    lhs = [sum(gram[i][j] * x[j] for j in gram[i])
           for i in range(len(supports))]
    rhs = [sum(direct.get(q, 0) for q in support)
           for support in supports]
    assert lhs == rhs
    assert sum(x[i] * b[i] for i in range(len(x))) == direct.get(0, 0)
    return {'format': 'BABEL9_SPARSE_GRAM_EXACT_UNIT_TEST_V1',
            'toy_exact_rational_delta_identity': 'PASS',
            'degenerate_fourier_multiplicity_identity': 'PASS',
            'frozen_SCL126_flip': 68,
            'frozen_kernel_dimension': dimension,
            'degree0_generator_count': len(supports),
            'degree0_distinct_fourier_support': support_size,
            'gram_vs_fourier_integer_identity': 'PASS',
            'support_bound': 4 * len(supports),
            'all_checks': 'PASS'}


if __name__ == '__main__':
    report = checks()
    print(json.dumps(report, sort_keys=True, indent=2))
