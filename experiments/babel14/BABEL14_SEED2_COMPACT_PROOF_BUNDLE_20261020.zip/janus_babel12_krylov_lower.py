#!/usr/bin/env python3
"""Exact modular lower bound for the cyclic Krylov space at frequency zero.

For symmetric integer C and prime p, a Lanczos sequence of non-isotropic
mutually orthogonal vectors through step t has linearly independent vectors
e0,C e0,...,C^(t-1)e0 over GF(p). The same independence therefore holds
over Q. This is NOT a rational SOS existence or nonexistence certificate.
"""

import argparse
import hashlib
import json
import struct
import time
from pathlib import Path

import numpy as np

from janus_babel12_active_normal import active_normal


def prove_krylov_lower(normal, max_steps, prime=100003):
    assert prime in (100003,100019,100043)
    assert all(prime % q for q in range(2,int(prime**.5)+1))
    n=normal.shape[0]
    old=np.zeros(n,dtype=np.int64)
    current=old.copy()
    current[0]=1
    oldnorm=0
    transcript=hashlib.sha256()
    for k in range(max_steps):
        norm=int(np.dot(current,current)%prime)
        if norm==0:
            return {'status':'NO_PROOF_ISOTROPIC_BREAKDOWN',
                    'independent_krylov_vectors_proved':k,
                    'prime':prime,'breakdown_step':k}
        mult=normal.dot(current)%prime
        alpha=int(np.dot(current,mult)%prime)*pow(norm,-1,prime)%prime
        beta=norm*pow(oldnorm,-1,prime)%prime if k else 0
        transcript.update(struct.pack('<III',norm,alpha,beta))
        following=(mult-alpha*current-beta*old)%prime
        if not np.any(following):
            return {'status':'EXACT_COMPLETE_KRYLOV_SPAN_MOD_P',
                    'independent_krylov_vectors_proved':k+1,
                    'prime':prime,'termination_step':k+1,
                    'trace_sha256':transcript.hexdigest()}
        old,current=current,following
        oldnorm=norm
        if (k+1)%128==0:
            print(json.dumps({'prime':prime,'verified_nonisotropic_steps':k+1},
                             sort_keys=True),flush=True)
    return {'status':'EXACT_KRYLOV_DIMENSION_LOWER_BOUND_ONLY',
            'independent_krylov_vectors_proved':max_steps,
            'prime':prime,'minimum_Krylov_dimension_over_Q':max_steps,
            'trace_sha256':transcript.hexdigest()}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--instance',default='SCL252_seed0')
    p.add_argument('--steps',type=int,default=512)
    p.add_argument('--prime',type=int,default=100003)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    from janus_babel10_degree_scan import frozen_instances
    from janus_babel10_lift_family import make_lift
    cases=frozen_instances()
    rows=(cases[args.instance] if args.instance in cases else
          make_lift(cases['SCL126_flip68'],
                    int(args.instance.removeprefix('SCL252_seed')))[0])
    start=time.monotonic()
    _,C,meta=active_normal(rows,2)
    res=prove_krylov_lower(C,args.steps,args.prime)
    res.update({'instance':args.instance,'n':len(rows),
                'active_frequency_dimension':C.shape[0],
                'normal_nnz':C.nnz,'max_requested_steps':args.steps,
                'elapsed_seconds_diagnostic':round(time.monotonic()-start,3)})
    if args.output:
        args.output.write_text(json.dumps(res,sort_keys=True,indent=2)+'\n')
    print(json.dumps(res,sort_keys=True),flush=True)


if __name__=='__main__':main()
