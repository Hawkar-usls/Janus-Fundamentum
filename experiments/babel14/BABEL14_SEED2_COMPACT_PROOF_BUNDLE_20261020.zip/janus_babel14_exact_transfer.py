#!/usr/bin/env python3
"""Construct and check a compact *rational* SOS4 transfer for SCL252 seed 2.

This is an exact symbolic certificate rather than 660k expanded coefficients:
base Krylov normal-operator polynomial + 425 singleton integer generators +
a 20018-edge signed spanning forest with two frustrating chords.

The polynomial source identity itself is verified by the independent BABEL-9
integer replay. All *new* seed-2 identities are checked here with integers,
not with floating point, approximate SDP, or modular rank inference.
"""

import argparse
import hashlib
import json
from collections import Counter, defaultdict, deque
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators
from janus_babel6_transfer import xor_labels, make_projection, signed_graph


def edge_data(r, u, row_edges, labels, canonical):
    a, b, sa, sb = row_edges[r]
    qa, oa = canonical(u ^ labels[a])
    qb, ob = canonical(u ^ labels[b])
    return qa, qb, sa*oa, sb*ob


class Union:
    def __init__(self):
        self.parent={}
        self.sz={}

    def find(self, x):
        if x not in self.parent:
            self.parent[x]=x
            self.sz[x]=1
        if self.parent[x]!=x:
            self.parent[x]=self.find(self.parent[x])
        return self.parent[x]

    def add(self, x, y):
        a, b = self.find(x), self.find(y)
        if a==b:
            return False
        if self.sz[a]<self.sz[b]:
            a,b=b,a
        self.parent[b]=a
        self.sz[a]+=self.sz[b]
        return True


def signed_forest(row_edges, Q, labels, canonical, touched):
    uf=Union()
    forest=[]
    adjacency=defaultdict(list)
    for r in sorted(row_edges):
        for u in sorted(Q):
            qa,qb,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
            if uf.add(qa,qb):
                forest.append([r,u])
                adjacency[qa].append((qb, alpha, beta))
                adjacency[qb].append((qa, beta, alpha))
    assert set(uf.parent)==touched

    # Tree potential s satisfies s_a*alpha + s_b*beta = 0.
    potential={}
    roots={}
    for start in sorted(touched):
        if start in potential:
            continue
        root=uf.find(start)
        roots[root]=start
        potential[start]=1
        todo=deque([start])
        while todo:
            x=todo.popleft()
            for y,a,b in adjacency[x]:
                next_s=-potential[x]*a*b
                if y not in potential:
                    potential[y]=next_s
                    todo.append(y)
                else:
                    assert potential[y]==next_s
    assert len(potential)==len(touched)
    chords={}
    for r in sorted(row_edges):
        if len(chords)==len(roots):
            break
        for u in sorted(Q):
            qa,qb,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
            root=uf.find(qa)
            if root not in chords and potential[qa]*alpha+potential[qb]*beta:
                assert abs(potential[qa]*alpha+potential[qb]*beta)==2
                chords[root]=[r,u]
    assert set(chords)==set(roots), 'balanced component cannot be eliminated'
    return forest, [chords[root] for root in sorted(chords)], sorted(roots.values())


def base_redundancy_19(source, lift, labels, Q, canonical, missing, singleton_idx):
    source_labels, base_Q, dim=xor_labels(source)
    pi,_=make_projection(source_labels,labels,dim,dim+1)
    reps={}
    for u in sorted(Q):
        reps.setdefault(pi(u),u)
    assert set(reps)==base_Q
    excluded=[q for i,q in enumerate(missing) if i not in singleton_idx]
    tracked=set(excluded)
    signs={q:Counter() for q in excluded}
    for r, row in enumerate(lift[:len(source)]):
        for bu,u in reps.items():
            for q in (u,*(u^labels[j] for j in row)):
                c,sign=canonical(q)
                if c in tracked:
                    signs[c][sign]+=1
    result=[]
    for q in excluded:
        assert pi(q) != 0
        assert sum(signs[q].values())>0
        assert len(signs[q])==1, (q,signs[q])
        s=next(iter(signs[q]))
        result.append({'frequency':q,'base_frequency':pi(q),
                       'forced_orientation':s,'independently_checked_occurrences':signs[q][s]})
    return result


def construct(seed=2):
    assert seed==2, 'only frozen seed 2 is certified in this experiment'
    source,lift,labels,Q,e,canonical,touched,active,missing=prepare(seed)
    signatures,supports,singletons,processed=extra_generators(
        source,lift,labels,Q,e,canonical,missing)
    print(f'Found {len(singletons)} strict singleton correction generators',flush=True)
    assert len(missing)==444 and len(singletons)==425
    rest=base_redundancy_19(source,lift,labels,Q,canonical,missing,singletons)
    assert len(rest)==19
    single_witnesses=[]
    missing_set=set(missing)
    for j,(r,u,s) in sorted(singletons.items()):
        coeff=defaultdict(int)
        for z in (u,*(u^labels[k] for k in lift[r])):
            c,orient=canonical(z)
            if c in missing_set:
                coeff[c]+=orient
        nz={k:v for k,v in coeff.items() if v}
        assert nz=={missing[j]:s}
        assert u^e in Q
        single_witnesses.append({'frequency':missing[j],
                                 'row':r,'multiplier':u,'integer_amplitude':s})
    _,_,row_edges=signed_graph(source,lift,labels,e)
    forest,chords,roots=signed_forest(row_edges,Q,labels,canonical,touched)
    print(f'Built {len(forest)} forest edges; {len(chords)} negative-cycle chords',flush=True)
    assert len(forest)+len(chords)==len(touched)
    base_poly=Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    proof=json.loads(base_poly.read_text())
    assert proof['degree_of_recurrence']==556
    assert proof['polynomial_coefficients_low_to_high'][0]!=0
    assert proof['flipped_base_edge_index']==68
    report={
        'format':'JANUS_BABEL14_SEED2_EXACT_RATIONAL_TRANSFER_CIRCUIT_V1',
        'seed':seed,'n':len(lift),'source':'SCL126_flip68',
        'source_krylov_polynomial_sha256':hashlib.sha256(base_poly.read_bytes()).hexdigest(),
        'source_integer_normal_dimension':32768,
        'source_Krylov_degree':556,
        'source_polynomial_nonzero_constant':True,
        'source_proof_required':'independent exact replay of source P(C)e0=0',
        'extra_character':e,
        'row_multiplier_degree_bound':2,
        'canonical_active_degree3_frequencies':len(active),
        'touched_graph_full_rank_frequencies':len(touched),
        'missed_graph_frequencies':len(missing),
        'all_missing_graph_frequencies_exhaustively_dispatched':True,
        'singleton_generator_witnesses':single_witnesses,
        'automatic_base_frequency_zero_constraints':rest,
        'graph_spanning_forest_edges':forest,
        'graph_frustrating_chords':chords,
        'graph_roots':roots,
        'symbolic_identity':'Lift source e0=Mbase(-Mbase.T*Q(C)*e0/P(0)) via unique source column representatives; repair 425 missing signed pair frequencies by singleton paired multiplier differences; remaining touched frequencies by signed tree forest plus one frustrated chord per component.',
        'status':'CONSTRUCTIVE_RATIONAL_DEGREE2_MULTIPLIER_IDENTITY_FROM_BASE_KRYLOV'
    }
    return report


def verify(record):
    source,lift,labels,Q,e,canonical,touched,active,missing=prepare(record['seed'])
    assert record['extra_character']==e
    poly_path=Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    assert hashlib.sha256(poly_path.read_bytes()).hexdigest()==record['source_krylov_polynomial_sha256']
    assert record['source_Krylov_degree']==556
    assert len(missing)==record['missed_graph_frequencies']
    missing_set=set(missing)
    witnesses={w['frequency']:w for w in record['singleton_generator_witnesses']}
    assert len(witnesses)==425
    assert set(witnesses).issubset(missing_set)
    for q,entry in witnesses.items():
        r,u,s=entry['row'],entry['multiplier'],entry['integer_amplitude']
        assert u in Q and (u^e) in Q
        coeff=defaultdict(int)
        for z in (u,*(u^labels[j] for j in lift[r])):
            x,sgn=canonical(z)
            if x in missing_set:
                coeff[x]+=sgn
        assert {x:v for x,v in coeff.items() if v}=={q:s}
    rest=base_redundancy_19(source,lift,labels,Q,canonical,missing,
                            {missing.index(q) for q in witnesses})
    assert record['automatic_base_frequency_zero_constraints']==rest
    rest_set={item['frequency'] for item in rest}
    for u in Q:
        if u^e not in Q or u>u^e:
            continue
        for r,row in enumerate(lift[:len(source)]):
            difference=defaultdict(int)
            for v in (u,*(u^labels[j] for j in row)):
                q,sgn=canonical(v)
                if q in rest_set:
                    difference[q]+=sgn
            assert not any(difference.values()), 'paired generator changes a forced-zero frequency'

    _,_,row_edges=signed_graph(source,lift,labels,e)
    uf=Union()
    adjacency=defaultdict(list)
    for r,u in record['graph_spanning_forest_edges']:
        assert r in row_edges and u in Q
        a,b,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
        # Exact raw coefficient identity, not just an asserted graph edge.
        raw=defaultdict(int)
        for rr,sign in ((r,1),(r+len(source),-1)):
            for q in (u,*(u^labels[j] for j in lift[rr])):
                raw[q]+=sign
        expected=defaultdict(int)
        expected[a]+=alpha
        expected[a^e]-=alpha
        expected[b]+=beta
        expected[b^e]-=beta
        assert {q:c for q,c in raw.items() if c}=={q:c for q,c in expected.items() if c}
        assert uf.add(a,b)
        adjacency[a].append((b,alpha,beta))
        adjacency[b].append((a,beta,alpha))
    assert set(uf.parent)==touched
    signs={}
    for start in sorted(touched):
        if start in signs:
            continue
        signs[start]=1
        todo=deque([start])
        while todo:
            a=todo.popleft()
            for b,alpha,beta in adjacency[a]:
                wanted=-signs[a]*alpha*beta
                if b not in signs:
                    signs[b]=wanted
                    todo.append(b)
                else:
                    assert signs[b]==wanted
    root_chords=set()
    for r,u in record['graph_frustrating_chords']:
        a,b,alpha,beta=edge_data(r,u,row_edges,labels,canonical)
        assert uf.find(a)==uf.find(b)
        root_chords.add(uf.find(a))
        assert abs(signs[a]*alpha+signs[b]*beta)==2
    assert len(root_chords)==len(record['graph_frustrating_chords'])
    assert len(root_chords)==len({uf.find(q) for q in touched})
    assert len(record['graph_spanning_forest_edges'])+len(root_chords)==len(touched)
    assert 0 in touched
    return {'status':'EXACT_SEED2_TRANSFER_Q_CERTIFICATE_REPLAY_PASS',
            'witnessed_singletons':len(witnesses),
            'forced_base_zero_frequencies':len(rest),
            'integer_signed_forest_edges':len(record['graph_spanning_forest_edges']),
            'frustrated_chords':len(root_chords),
            'completely_eliminable_antisector_dimension':len(active),
            'frozen_base_polynomial_identity':'REQUIRES_INDEPENDENT_BABEL9_REPLAY'}


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path)
    ap.add_argument('--verify',type=Path)
    args=ap.parse_args()
    if args.verify:
        record=json.loads(args.verify.read_text())
        print(json.dumps(verify(record),indent=2,sort_keys=True))
    else:
        record=construct()
        if args.output:
            args.output.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
        print(json.dumps(verify(record),indent=2,sort_keys=True))
