#!/usr/bin/env python3
"""Modular-only global degree-four ideal-membership Krylov diagnostic.

This is intentionally NOT an SOS PASS/FAIL.  An exact rational SOS identity,
or an exact PSD primal moment matrix, would be needed for a definitive gate.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import lsmr

from janus_babel6_transfer import xor_labels
from janus_occam_replay import FIXTURES, cover, source_triples


def all_equations(flip=16):
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    mask = format(int(FIXTURES[1][1], 16) ^ (1 << flip), 'x')
    cov = cover(source, mask)
    labels, Q, dim = xor_labels(cov)
    assert dim == 15
    equations = sorted({tuple(sorted((u, *(u ^ labels[i] for i in row))))
                        for row in cov for u in Q})
    return np.array(equations, dtype=np.int32), len(Q)


def probe(prime, max_power=100, flip=16):
    eq, q_size = all_equations(flip)
    dimension = 32768
    n_eq = len(eq)
    aa = coo_matrix((np.ones(4 * n_eq, dtype=np.int64),
                     (eq.ravel(), np.repeat(np.arange(n_eq), 4))),
                    shape=(dimension, n_eq)).tocsr()
    aat = aa.T.tocsr()

    def normal(v):
        return aa.dot(aat.dot(v)) % prime

    pivots = {}
    cur = np.zeros(dimension, dtype=np.int64)
    cur[0] = 1
    first_nonzero_constant = None
    recorded = []
    for power in range(max_power + 1):
        residue = cur.copy()
        for pivot, prior in pivots.items():
            coef = residue[pivot]
            if coef:
                residue = (residue - coef * prior) % prime
        indices = np.flatnonzero(residue)
        if len(indices) == 0:
            recorded.append({'power': power, 'dependent': True,
                             'rank': len(pivots)})
            break
        at = int(indices[0])
        inv = pow(int(residue[at]), -1, prime)
        normalized = residue * inv % prime
        # Reduce previous basis columns too: ascending pivots preserve the
        # coordinate scheme needed for deterministic forward elimination.
        pivots[at] = normalized
        recorded.append({'power': power, 'pivot': at})
        cur = normal(cur)
    return {'status': 'MODULAR_KRYLOV_DIAGNOSTIC_ONLY',
            'prime': prime, 'moment_dimension': q_size,
            'frequency_dimension': dimension,
            'distinct_equations': n_eq,
            'independent_powers': len(pivots),
            'terminated': bool(recorded and 'dependent' in recorded[-1]),
            'powers': recorded}


def numeric_lsqr(limit=2000, flip=16):
    eq, q_size = all_equations(flip)
    n_eq = len(eq)
    aa = coo_matrix((np.ones(4 * n_eq, dtype=np.float64),
                     (eq.ravel(), np.repeat(np.arange(n_eq), 4))),
                    shape=(32768, n_eq)).tocsr()
    e0 = np.zeros(32768, dtype=np.float64)
    e0[0] = 1.0
    solution = lsmr(aa, e0, atol=1e-12, btol=1e-12,
                    maxiter=limit, show=False)
    return {'status': 'FLOATING_POINT_LEAST_SQUARES_DIAGNOSTIC_ONLY',
            'frequency_dimension': 32768,
            'number_of_equations': n_eq,
            'moment_basis_size': q_size,
            'iterations': solution[2],
            'stop_code': solution[1],
            'reported_residual_norm': repr(solution[3]),
            'solution_norm': repr(solution[7]),
            'note': 'cannot establish rational membership nor PSD feasibility'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--prime', type=int, default=1000000007)
    p.add_argument('--max-power', type=int, default=30)
    p.add_argument('--numeric-lsmr', action='store_true')
    p.add_argument('--bit', type=int, default=16)
    p.add_argument('--output', type=Path)
    args = p.parse_args()
    result = numeric_lsqr(args.max_power, args.bit) if args.numeric_lsmr else probe(
        args.prime, args.max_power, args.bit)
    if args.output:
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'powers'},
                     sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
