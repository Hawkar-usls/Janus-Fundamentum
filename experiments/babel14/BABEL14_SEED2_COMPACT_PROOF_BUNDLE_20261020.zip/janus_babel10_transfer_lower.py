#!/usr/bin/env python3
"""BABEL-10 exact pullback of SOS-degree lower bounds through 2-lifts.

For K_source diagonally included in K_lift, restriction of characters pi
sends either sheet's column label to its source column label. Pulling back
a rational left-null Fourier functional gives a left-null functional for
every same-degree multiplier in the lift; no Krylov search on the lift.
"""

import hashlib
import json
from pathlib import Path

from janus_babel10_degree_scan import character_products, frozen_instances
from janus_babel10_exact_lower import exact_normal
from janus_babel10_lift_family import audit, make_lift
from janus_babel6_transfer import xor_labels


def restriction_projection(source_labels, lift_labels, source_d, lift_d):
    n = len(source_labels)
    assert len(lift_labels) == 2 * n and lift_d >= source_d
    pivots = {}
    for j, value in enumerate(lift_labels):
        x = value
        y = source_labels[j % n]
        while x:
            at = x.bit_length() - 1
            if at not in pivots:
                pivots[at] = (x, y)
                break
            v, w = pivots[at]
            x ^= v
            y ^= w
        else:
            assert not y, 'diagonal restriction is inconsistent'
    assert len(pivots) == lift_d

    def pi(q):
        result = 0
        while q:
            pivot, target = pivots[q.bit_length() - 1]
            q ^= pivot
            result ^= target
        return result

    assert all(pi(v) == source_labels[j % n]
               for j, v in enumerate(lift_labels))
    return pi


def exact_base_lower_functional():
    source = frozen_instances()['SCL126_flip68']
    doc = json.loads(Path(__file__).with_name(
        'babel10_SCL126_flip68_EXACT_DEGREE1_OBSTRUCTION.json').read_text())
    labels, d, qsize, eq = character_products(source, 1)
    vector = [0] * (1 << d)
    for coefficient in reversed(doc['polynomial_coefficients_low_to_high'][1:]):
        vector = exact_normal(vector, eq)
        vector[0] += coefficient
    assert vector[0] != 0 and not any(exact_normal(vector, eq))
    return source, labels, d, vector


def verify_lift(source, source_labels, source_d, base_h, lifted):
    lift_labels, lift_d, qsize, products = character_products(lifted, 1)
    pi = restriction_projection(source_labels, lift_labels,
                                source_d, lift_d)
    # Check the projection of every generator and the exact integer
    # annihilation; no numerical calculations or rational reconstruction.
    for quadruple in products:
        assert sum(base_h[pi(q)] for q in quadruple) == 0
    assert base_h[pi(0)] == base_h[0] != 0
    return {'source_n': len(source), 'lift_n': len(lifted),
            'base_kernel_dim': source_d, 'cover_kernel_dim': lift_d,
            'degree1_row_generators_checked': len(products),
            'pullback_constant_component_nonzero': True,
            'exact_integer_dual_annihilation': 'PASS',
            'SOS_degree_less_than_4': 'EXCLUDED'}


def main():
    source, labels, d, h = exact_base_lower_functional()
    results = []
    for seed in range(5):
        report, lift = audit('SCL126_flip68', source, seed)
        assert report['connected'] and report['status'] == 'UNSAT'
        result = verify_lift(source, labels, d, h, lift)
        result['instance'] = report['instance']
        result['source_signing_seed'] = seed
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    out = Path('babel10_SCL252_EXACT_LOWER_TRANSFER.json')
    out.write_text(json.dumps(results, sort_keys=True, indent=2) + '\n')
    return results


if __name__ == '__main__':
    main()
