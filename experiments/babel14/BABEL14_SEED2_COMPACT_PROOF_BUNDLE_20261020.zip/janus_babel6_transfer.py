#!/usr/bin/env python3
"""BABEL-6 conditional polynomial-over-certificate-size SOS transfer.

All group-algebra operations are sparse dictionaries; no loop over 2**d.
An ordinary connected 2-lift is assumed, with parity-kernel nullity d+1.
The transfer is conditional on a base low-degree dual and explicit reachability
of the minus-sector remainder by unbalanced signed-graph anchors.

The returned integer identity is independently checkable using only additions.
"""

from collections import defaultdict, deque
from fractions import Fraction
from itertools import combinations

from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


class TransferObstruction(ValueError):
    """A stated sufficient condition of the two-sector theorem has failed."""


def xor_labels(rows):
    n = len(rows)
    _, kernel = gf2_kernel(validate(rows, n), n)
    labels = columns_of_kernel(kernel, n)
    basis = {0, *labels, *(x ^ y for x, y in combinations(labels, 2))}
    return labels, basis, len(kernel)


def make_projection(base_labels, lift_labels, base_dim, lift_dim):
    """Character restriction pi: dual(K_lift) -> dual(K_base)."""
    n = len(base_labels)
    if lift_dim != base_dim + 1:
        raise TransferObstruction(
            f'extra-parity-dimension={lift_dim-base_dim}; expected exactly 1')
    pivot = {}
    for j, x0 in enumerate(lift_labels):
        x, y = x0, base_labels[j % n]
        while x:
            p = x.bit_length() - 1
            if p not in pivot:
                pivot[p] = (x, y)
                break
            a, b = pivot[p]
            x ^= a
            y ^= b
        else:
            if y:
                raise TransferObstruction('diagonal parity subspace inconsistent')
    if len(pivot) != lift_dim:
        raise AssertionError('character columns do not span cover dual')

    def pi(x):
        y = 0
        while x:
            a, b = pivot[x.bit_length() - 1]
            x ^= a
            y ^= b
        return y

    free = [bit for bit in range(lift_dim) if pi(1 << bit) == 0]
    if len(free) != 1:
        # The generator of ker(pi) may be a non-unit vector.
        kernel = []
        reduced = {}
        for bit in range(lift_dim):
            x, y = 1 << bit, pi(1 << bit)
            while y:
                p = y.bit_length() - 1
                if p not in reduced:
                    reduced[p] = (y, x)
                    break
                ay, ax = reduced[p]
                y ^= ay
                x ^= ax
            else:
                kernel.append(x)
        if len(kernel) != 1:
            raise AssertionError('expected one-dimensional restriction kernel')
        e = kernel[0]
    else:
        e = 1 << free[0]
    if pi(e) != 0 or e == 0:
        raise AssertionError('bad additional character')
    if any(pi(x) != base_labels[i % n] for i, x in enumerate(lift_labels)):
        raise AssertionError('bad diagonal character restriction')
    return pi, e


def assert_valid_double_cover(source, lift):
    n = len(source)
    validate(source, n)
    validate(lift, 2 * n)
    for r, row in enumerate(lift):
        if sorted(c % n for c in row) != sorted(source[r % n]):
            raise TransferObstruction('rows do not form a 2-lift of this source')
    for r in range(n):
        if sorted((c + n) % (2 * n) for c in lift[r]) != sorted(lift[r + n]):
            raise TransferObstruction('two sheets do not have complementary incidences')


def signed_graph(source, lift, labels, e):
    """Return signed graph on sheet-split column labels."""
    n = len(source)
    split = {i for i in range(n) if labels[i] ^ labels[i + n] == e}
    if any(labels[i] ^ labels[i + n] not in (0, e) for i in range(n)):
        raise AssertionError('not a one-dimensional extra parity sector')
    edges, graph = {}, defaultdict(list)
    for r, triple in enumerate(source):
        active = sorted(set(triple) & split)
        if len(active) not in (0, 2):
            raise AssertionError('row parity violated among split variables')
        if not active:
            continue
        a, b = active
        signs = {}
        for i in active:
            picked = next(j for j in lift[r] if j % n == i)
            signs[i] = 1 if labels[picked] == labels[i] else -1
        ratio = -signs[a] * signs[b]
        edges[r] = (a, b, signs[a], signs[b])
        graph[a].append((b, r, ratio))
        graph[b].append((a, r, ratio))
    for node in graph:
        graph[node].sort()
    return split, graph, edges


def negative_cycle_in_component(graph, root):
    assigned = {root: 1}
    parent = {root: (None, None)}
    depth = {root: 0}
    todo = deque([root])
    conflict = None
    while todo:
        u = todo.popleft()
        for v, row, ratio in graph[u]:
            predicted = assigned[u] * ratio
            if v not in assigned:
                assigned[v] = predicted
                parent[v] = (u, row)
                depth[v] = depth[u] + 1
                todo.append(v)
            elif assigned[v] != predicted:
                if conflict is None:
                    conflict = u, v, row
    if conflict is None:
        return set(assigned), None
    u, v, row = conflict
    up, down = [], []
    a, b = u, v
    while depth[a] > depth[b]:
        p, r = parent[a]
        up.append((a, r, p))
        a = p
    while depth[b] > depth[a]:
        p, r = parent[b]
        down.append((p, r, b))
        b = p
    while a != b:
        pa, ra = parent[a]
        pb, rb = parent[b]
        up.append((a, ra, pa))
        down.append((pb, rb, b))
        a, b = pa, pb
    cycle = up + list(reversed(down)) + [(v, row, u)]
    assert all(cycle[k][2] == cycle[k + 1][0]
               for k in range(len(cycle) - 1))
    return set(assigned), cycle


def anchor_identities(source, lift, labels, extra):
    """Return 2(1-t)*chi_i = sum_r mu_ir*(g_r0-g_r1) anchors.

    Balanced components are explicitly excluded (not treated as success).
    """
    split, graph, edges = signed_graph(source, lift, labels, extra)
    visited, anchors = set(), {}
    balanced, unbalanced = [], []
    for root in sorted(split):
        if root in visited:
            continue
        if root not in graph:
            visited.add(root)
            balanced.append([root])
            continue
        component, cycle = negative_cycle_in_component(graph, root)
        visited.update(component)
        if cycle is None:
            balanced.append(sorted(component))
            continue
        unbalanced.append({'vertices': len(component), 'cycle': len(cycle)})
        start = cycle[0][0]
        coeffs = defaultdict(int)
        previous = None
        for k, (u, row, v) in enumerate(cycle):
            a, b, sa, sb = edges[row]
            su, sv = (sa, sb) if u == a else (sb, sa)
            lam = su if k == 0 else -previous * su
            previous = lam * sv
            coeffs[row] += lam
        assert previous == 1
        anchors[start] = {r: c for r, c in coeffs.items() if c}
        todo = deque([start])
        while todo:
            u = todo.popleft()
            for v, row, _ in graph[u]:
                if v in anchors:
                    continue
                a, b, sa, sb = edges[row]
                su, sv = (sa, sb) if u == a else (sb, sa)
                propagated = defaultdict(int)
                for r, c in anchors[u].items():
                    propagated[r] -= su * sv * c
                propagated[row] += 2 * sv
                anchors[v] = {r: c for r, c in propagated.items() if c}
                todo.append(v)
        assert component == set(anchors).intersection(component)
    return anchors, {'split_vertices': len(split),
                     'signed_edges': len(edges),
                     'balanced_component_sizes': [len(c) for c in balanced],
                     'unbalanced_components': unbalanced,
                     'anchored_split_vertices': len(anchors)}


def sparse_fourier_identity(lift, labels, terms, target):
    """Verify a rational/integer group-algebra certificate in O(4*terms)."""
    frequencies = defaultdict(int)
    row_l1 = [0] * len(lift)
    for (row, u), coefficient in terms.items():
        if coefficient == 0:
            continue
        row_l1[row] += abs(coefficient)
        frequencies[u] += coefficient
        for j in lift[row]:
            frequencies[u ^ labels[j]] += coefficient
    remaining = {q: a for q, a in frequencies.items() if a}
    if remaining != {0: target}:
        raise AssertionError(f'group algebra identity fails: '
                             f'{len(remaining)} nonzero frequencies')
    return row_l1, sum(x * x for x in row_l1)


def transfer(source, lift, base_terms, D):
    """Produce an exact cover SOS dual from an exact base group identity.

    Input base_terms: dictionary (row, degree<=2 char label) -> rational or
    integer coefficient, with sum coeff*g_row*chi_label = D>0.
    Construction and verification NEVER enumerate characters in GF(2)^d.
    """
    if D <= 0:
        raise ValueError('positive normalization required')
    assert_valid_double_cover(source, lift)
    n = len(source)
    base_labels, base_Q, base_dim = xor_labels(source)
    labels, Q, lift_dim = xor_labels(lift)
    pi, extra = make_projection(base_labels, labels, base_dim, lift_dim)
    base_l1, _ = sparse_fourier_identity(source, base_labels, base_terms, D)
    if not base_l1:
        raise AssertionError('empty source certificate')
    reps = {}
    for u in sorted(Q):
        reps.setdefault(pi(u), u)
    if not base_Q <= reps.keys():
        raise TransferObstruction('missing degree<=2 representatives in lift')
    anchors, graph_info = anchor_identities(source, lift, labels, extra)
    terms = defaultdict(int)
    H = defaultdict(int)
    def add_term(row, u, value):
        if u not in Q:
            raise AssertionError('attempted degree>2 multiplier')
        if value:
            terms[row, u] += value

    for (row, u), value in base_terms.items():
        if not value:
            continue
        cover_u = reps[u]
        add_term(row, cover_u, 4 * value)
        H[cover_u] += value
        for j in lift[row]:
            H[cover_u ^ labels[j]] += value
    projection = defaultdict(int)
    for q, value in H.items():
        projection[pi(q)] += value
    assert {q: a for q, a in projection.items() if a} == {0: D}

    low_bit = extra & -extra
    def canonical(q):
        return q ^ extra if q & low_bit else q
    section_support = {canonical(q) for q, value in H.items() if value}
    section_support.add(0)
    correction_count = 0
    for q in sorted(section_support):
        remaining = (D if q == 0 else 0) - (H[q] - H[q ^ extra])
        if not remaining:
            continue
        choices = []
        for current_q, sector_sign in ((q, 1), (q ^ extra, -1)):
            for i, anchor in anchors.items():
                multiplier = current_q ^ labels[i]
                if multiplier in Q:
                    score = sum(abs(a) for a in anchor.values())
                    choices.append((score, len(anchor), i, multiplier,
                                    sector_sign))
        if not choices:
            raise TransferObstruction(
                f'unreachable minus-sector character {q}; '
                f'anchored vertices {len(anchors)}')
        _, _, i, multiplier, sign = min(choices)
        for row, coefficient in anchors[i].items():
            add_term(row, multiplier, remaining * sign * coefficient)
            add_term(row + n, multiplier, -remaining * sign * coefficient)
        correction_count += 1
    terms = {key: value for key, value in terms.items() if value}
    normalization = 4 * D
    row_l1, C = sparse_fourier_identity(lift, labels, terms, normalization)
    return terms, {
        'base_rows': n,
        'cover_rows': 2 * n,
        'base_nullity': base_dim,
        'cover_nullity': lift_dim,
        'extra_frequency': extra,
        'base_degree2_types': len(base_Q),
        'cover_degree2_types': len(Q),
        'source_terms': len([c for c in base_terms.values() if c]),
        'cover_terms': len(terms),
        'sparse_support_of_lifted_source': len([v for v in H.values() if v]),
        'sector_remainders_corrected': correction_count,
        'no_enumeration_of_2_to_nullity': True,
        'signed_graph': graph_info,
        'D': normalization,
        'C': C,
        'strict_F_gap': str(Fraction(normalization * normalization, 12 * C)),
    }
