#!/usr/bin/env python3
"""BABEL-11: exact rational SOS4 existence from a small modular determinant.

Rigorous logic (no CRT needed):
  - the integer Fourier normal C=M M^T admits an exactly verified equitable
    1420-cell partition, containing {0} as a singleton;
  - some cells are zero rows, hence annihilated, with *no* intersection with 0;
  - restrict C to the remaining 1419-dim rational invariant subspace V;
  - certify invertibility of its integer matrix B by exhibiting a prime p
    for which a full-length non-isotropic weighted Lanczos sequence from e0
    has nonzero constant characteristic polynomial coefficient.

Then det B is an integer not divisible by p, and
  y=M^T E adj(B) e0 / det(B)
is an **exact rational degree-2 Fourier multiplier identity** over Q;
E embeds cell-constant vectors into all 32768 frequencies. This certificate
is symbolic/compressed (rational Cramer coefficients not expanded).
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from janus_babel11_exact_quotient import (equitable_partition,quotient,
                                          weighted_lanczos)
from janus_babel8_krylov_exact import matrices


def prove(bit=94, primes=(100003,100019,100043,10000079,10000103)):
    products,M,MT,basis,bound=matrices(bit)
    C=(M@MT).tocsr()
    colors,history=equitable_partition(C)
    Q,sizes=quotient(C,colors)
    zero_cells=[i for i in range(Q.shape[0])
                if Q.indptr[i]==Q.indptr[i+1]]
    assert zero_cells and colors[0] not in zero_cells
    for i in zero_cells:
        assert Q[:,i].nnz==0
    retained=[i for i in range(Q.shape[0]) if i not in zero_cells]
    B=Q[retained,:][:,retained].tocsr()
    weights=sizes[retained]
    e0=retained.index(colors[0])
    assert B.shape[0]+len(zero_cells)==Q.shape[0]
    pilots=[]
    proof=None
    for prime in primes:
        assert prime > 2 and all(prime%q for q in range(2,int(prime**.5)+1))
        try:
            report=weighted_lanczos(B,weights,prime,max_steps=B.shape[0]+1,
                                    start_index=e0)
        except ArithmeticError as err:
            report={'prime':prime,'error':str(err)}
        pilots.append(report)
        print(json.dumps({**report,'quotient_rank_target':B.shape[0]},
                         sort_keys=True),flush=True)
        if (report.get('degree')==B.shape[0] and
                report.get('constant_nonzero')):
            proof=report
            break
    assert proof, 'no rigorous rational existence proof found'
    det_modp = ((-1 if B.shape[0] % 2 else 1) *
                proof['constant']) % proof['prime']
    assert det_modp != 0
    conservative_gap = (f'1/(192*126*{len(products)}^2*'
                        f'({B.shape[0]}*{bound})^({2*(B.shape[0]-1)}))')
    result={'format':'BABEL11_INTEGER_QUOTIENT_MODP_DETERMINANT_SOS4_V1',
            'flipped_base_edge_index':bit,
            'full_character_dimension':C.shape[0],
            'base_multiplier_degree':2,
            'fourier_defect_product_count':len(products),
            'equitable_partition_cell_history':history,
            'equitable_cells':Q.shape[0],
            'excluded_zero_cells':zero_cells,
            'excluded_zero_frequency_count':int(sum(sizes[i] for i in zero_cells)),
            'rational_invariant_quotient_dimension':B.shape[0],
            'integer_normal_operator_row_sum_bound':bound,
            'zero_frequency_cell_is_singleton':True,
            'exact_all_rows_integer_equivariance':'PASS',
            'exact_integer_weighted_self_adjointness':'PASS',
            'modular_pilots':pilots,
            'full_rank_prime_witness':proof,
            'determinant_mod_prime':det_modp,
            'integer_determinant_nonzero_proven':bool(proof),
            'exact_rational_SOS4_certificate_exists':bool(proof),
            'certificate_representation':
              'M^T * E * adj(B) * e_zero_cell / det(B)',
            'symbolic_integer_frequency_identity':
              'det(B)*e0=M*M^T*E*adj(B)*e_zero_cell',
            'certified_positive_rational_F_gap':
              f'F >= -42 + {conservative_gap} > -42',
            'status':('EXACT_RATIONAL_SOS4_EXISTENCE_PASS' if proof
                      else 'OPEN_NO_DETERMINANT_CERTIFICATE')}
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bits',nargs='+',type=int,default=[94,168,169])
    args=p.parse_args()
    outcomes=[]
    for bit in args.bits:
        report=prove(bit)
        path=Path(f'babel11_BIT{bit}_SOS4_EXACT_QUOTIENT_DET.json')
        path.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        print(json.dumps({'bit':bit,'status':report['status'],
                          'quotient_size':report['rational_invariant_quotient_dimension'],
                          'prime':report['full_rank_prime_witness']['prime'],
                          'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest()},
                         sort_keys=True),flush=True)
        outcomes.append(report)
    return outcomes


if __name__=='__main__':main()
