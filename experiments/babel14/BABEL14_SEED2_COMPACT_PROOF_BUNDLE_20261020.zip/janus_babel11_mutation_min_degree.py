#!/usr/bin/env python3
"""Exact SOS4 minimum across independent SCL63 edge-swap controls.

Upper: project the archived integer SOS4 witness.
Lower: independently integer-replay the universal seed0 SOS2 obstruction;
when it fails on a distinct spectral type, reconstruct a new integer polynomial.
"""

import hashlib
import json
from collections import Counter
from pathlib import Path

from janus_babel10_exact_lower import build_operator, reconstruct
from janus_babel11_mutation_exact_lower import verify
from janus_babel11_mutation_transfer_upper import transfer


def audit():
    folder=Path(__file__).resolve().parent
    samples=json.loads((folder/'babel11_SCL63_GEOMETRY_MUTATIONS.json').read_text())
    base=json.loads((folder/'babel11_MUTATION_SEED0_SOS2_EXACT_OBSTRUCTION.json').read_text())
    results=[]
    for item in samples:
        if item['steps']!=1:continue
        trial=dict(base)
        trial['seed']=item['seed']
        trial['steps']=item['steps']
        trial['SHA256_rows']=item['SHA256_rows']
        supports,normal,d,basis,bound=build_operator(item['rows'],1)
        trial.update({'nullity':d,'Fourier_generator_count':len(supports),
                      'multiplier_basis_size':basis,
                      'normal_row_sum_bound':bound})
        try:
            low=verify(trial)
            lower_source='REUSED_SEED0_INTEGER_POLYNOMIAL'
        except AssertionError:
            polynomial,crt=reconstruct(supports,normal,160)
            assert polynomial[0]==0
            trial['polynomial_coefficients_low_to_high']=polynomial
            trial.update(crt)
            low=verify(trial)
            lower_source='FRESH_CRT_AND_INTEGER_REPLAY'
        proof_file=folder/f'babel11_MUTATION_SEED{item["seed"]}_LOWER_SOS2.json'
        proof_file.write_text(json.dumps(trial,sort_keys=True,
                                         separators=(',',':'))+'\n')
        up=transfer(item['seed'],1)
        case={'seed':item['seed'],'steps':1,
              'SHA256_rows':item['SHA256_rows'],
              'nullity':d,'SOS2_obstruction_exact':'PASS',
              'SOS4_positive_exact':'PASS',
              'minimal_character_multiplier_degree':2,
              'minimum_JANUS_SOS_degree':4,
              'lower_proof_method':lower_source,
              'lower_proof_sha256':hashlib.sha256(proof_file.read_bytes()).hexdigest(),
              'upper_source_proof_sha256':up['source_archived_proof_SHA256']}
        results.append(case)
        print(json.dumps(case,sort_keys=True),flush=True)
    report={'scope':'ONE_LEGAL_EDGE_SWAP_OF_FROZEN_UNSAT_SCL63',
            'new_noncover_instances':len(results),
            'minimum_SOS_degree_4_verified':len(results),
            'proof_source_counts':dict(Counter(x['lower_proof_method']
                                                for x in results)),
            'cases':results,'CI':'NOT_RUN'}
    (folder/'babel11_NONCOVER_SCL63_EXACT_MIN_DEGREES.json').write_text(
        json.dumps(report,sort_keys=True,indent=2)+'\n')
    return report


if __name__=='__main__':
    summary=audit()
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'},
                     sort_keys=True))
