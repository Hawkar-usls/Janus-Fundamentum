#!/usr/bin/env python3
"""Rebuild BABEL-1 SAT/UNSAT exact proof bundles from frozen JANUS masks."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel1_solver import certified_minimum
from janus_babel1_verify import verify


SOURCE_HASH = '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899'
ORDER = [9, 0, 1, 5, 8, 12, 11, 2, 14, 4, 3, 13, 6, 7, 10]


def main():
    directory = Path(__file__).resolve().parent
    input_csv = directory / 'tutte12.am.csv'
    assert hashlib.sha256(input_csv.read_bytes()).hexdigest() == SOURCE_HASH
    source = source_triples(input_csv)
    results = {}
    for name, mask, expected_sat, expected_rank in FIXTURES[:2]:
        instance = cover(source, mask)
        proof = certified_minimum(instance, order=ORDER,
                                  metadata={'frozen_fixture': name,
                                            'tutte12_am_csv_sha256': SOURCE_HASH,
                                            'voltage_mask_hex': mask})
        result = verify(proof)
        assert result['rank'] == expected_rank == 111
        assert result['minimum_violated_rows'] == (0 if expected_sat else 6)
        assert (result['maximum_kernel_weight'] == 84) == bool(expected_sat)
        path = directory / ('JANUS_BABEL1_' + name + '_certificate_20261018.json')
        path.write_text(json.dumps(proof, ensure_ascii=False, sort_keys=True,
                                   indent=1) + '\n')
        results[name] = {**result,
                         'individual_scores_evaluated_by_constructor':
                             proof['individual_score_evaluations_during_search'],
                         'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                         'bytes': path.stat().st_size}
    print(json.dumps(results, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
