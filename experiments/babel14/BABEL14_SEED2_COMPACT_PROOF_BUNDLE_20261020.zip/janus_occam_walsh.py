#!/usr/bin/env python3
"""Exact Walsh reformulation of Linear Cubic XSAT, for SMALL GF(2) nullity.

This independent research diagnostic still takes O(d*2**d) time/memory;
it is NOT a polynomial-time algorithm or a replacement for the solver.
"""

import argparse
import json
from collections import Counter

from janus_occam_solver import gf2_kernel, validate


def hadamard(values):
    """Unnormalised FWHT: output[c] = sum_q values[q]*(-1)**parity(c&q)."""
    result = list(values)
    n = len(result)
    step = 1
    while step < n:
        for offset in range(0, n, 2 * step):
            for j in range(offset, offset + step):
                a, b = result[j], result[j + step]
                result[j], result[j + step] = a + b, a - b
        step *= 2
    return result


def analyse_kernel(null_basis, n, max_nullity=22):
    d = len(null_basis)
    if d > max_nullity:
        raise ValueError(f"nullity {d} exceeds declared exact audit limit {max_nullity}")
    types = [0] * n
    for k, vector in enumerate(null_basis):
        w = vector
        while w:
            lo = w & -w
            j = lo.bit_length() - 1
            types[j] |= 1 << k
            w ^= lo
    multiplicity = [0] * (1 << d)
    for q in types:
        multiplicity[q] += 1

    score = hadamard(multiplicity)
    assert all((n - value) % 2 == 0 for value in score)
    weights = [(n - value) // 2 for value in score]
    assert score[0] == n
    optimal_selector = max(range(len(weights)), key=lambda c: weights[c])
    optimal_kernel_word = 0
    for k, vector in enumerate(null_basis):
        if (optimal_selector >> k) & 1:
            optimal_kernel_word ^= vector
    assert optimal_kernel_word.bit_count() == max(weights)

    b1 = multiplicity[0]
    b2 = sum(size * (size - 1) // 2 for size in multiplicity)
    # Fourier orthogonality yields these *exact integer* identities.
    assert sum(score) == (1 << d) * b1
    assert sum(v * v for v in score) == (1 << d) * (n + 2 * b2)

    return {"nullity": d, "n": n,
            "unique_column_syndromes": sum(bool(v) for v in multiplicity),
            "B1_rowspace": b1, "B2_rowspace": b2,
            "second_walsh_moment": n + 2 * b2,
            "target_walsh_score": -n // 3 if n % 3 == 0 else None,
            "target_weight": 2 * n // 3 if n % 3 == 0 else None,
            "SAT_count_exact": weights.count(2 * n // 3) if n % 3 == 0 else 0,
            "maximum_kernel_weight": max(weights),
            "minimum_walsh_score": min(score),
            "optimal_kernel_word_hex": hex(optimal_kernel_word),
            "nearest_weight_gap": min(abs(w - 2 * n // 3) for w in weights)
                                      if n % 3 == 0 else None,
            "weight_histogram": dict(sorted(Counter(weights).items())),
            "enumerated_fourier_modes": len(score)}


def analyse_triples(triples):
    n = len(triples)
    rows = validate(triples, n)
    _, null_basis = gf2_kernel(rows, n)
    return analyse_kernel(null_basis, n)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="SCL JSON with rows")
    args = parser.parse_args()
    triples = json.load(open(args.input))["rows"]
    print(json.dumps(analyse_triples(triples), indent=2, sort_keys=True))
