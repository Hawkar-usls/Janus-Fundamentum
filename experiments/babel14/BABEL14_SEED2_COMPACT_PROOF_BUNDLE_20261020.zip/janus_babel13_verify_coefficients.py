#!/usr/bin/env python3
"""Independent exact integer verifier for explicit BABEL-13 rational dual.

No Walsh transforms, no examination of parity states, no numerical methods.
Checks the character coefficients of the full identity directly:

    (n H_q + 3*sum_i H_{q xor q_i}) == D*[q==0].

This uses only the exact triple-per-column property of the frozen SCL.
"""

import argparse
import gzip
import hashlib
import json
from collections import Counter
from pathlib import Path

from janus_babel13_common_multiplier import frozen_rows
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses
from janus_occam_solver import validate


def verify(rows, coefficients_path, summary_path):
    validate(rows,len(rows))
    with gzip.open(coefficients_path,'rt',encoding='utf-8') as source:
        payload=json.load(source)
    summary=json.loads(Path(summary_path).read_text())
    digest=hashlib.sha256(json.dumps(rows,separators=(',',':')).encode()).hexdigest()
    assert payload['format']=='BABEL13_EXPLICIT_INTEGER_WALSH_COEFFICIENTS_V1'
    assert payload['SHA256_ordered_rows']==summary['SHA256_ordered_rows']==digest
    labels,_,d=xor_labels(rows)
    assert all(labels[a]^labels[b]^labels[c]==0 for a,b,c in rows)
    H=payload['coefficients_H_by_binary_character']
    assert len(H)==1<<d
    assert payload['nullity']==summary['nullity']==d
    hdigest=hashlib.sha256(json.dumps(H,separators=(',',':')).encode()).hexdigest()
    assert hdigest==payload['integer_Fourier_H_sha256']==summary['integer_Fourier_H_sha256']
    occurrences=Counter(labels)
    n=len(rows)
    D=int(summary['integer_normalization_D_equals_4_L_2powd'])
    assert sum(1 for v in H if v)==summary['unnormalized_integer_walsh_support_size']
    assert sum(abs(v) for v in H)==int(summary['integer_H_total_absolute_coefficient'])
    checked=0
    for q,hq in enumerate(H):
        got=n*hq+3*sum(mult*H[q^label] for label,mult in occurrences.items())
        if got != (D if q==0 else 0):
            raise ArithmeticError(f'Fourier certificate incorrect at q={q}: {got}')
        checked+=1
    available=degree_witnesses(labels,summary['minimal_coordinate_degree_for_this_SHARED_multiplier'])
    assert all(not coefficient or q in available for q,coefficient in enumerate(H))
    return {'status':'EXACT_INDEPENDENT_FOURIER_COEFFICIENT_IDENTITY_PASS',
            'SHA256_ordered_rows':digest,'integer_H_sha256':hdigest,
            'nonzero_Fourier_characters_checked':summary['unnormalized_integer_walsh_support_size'],
            'all_Fourier_characters_checked':checked,
            'arithmetic':'integers_only',
            'SOS_alias':'JANUS_Fourier_multiplier_degree_2ell_NOT_general_PSD_SOS'}


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--coefficients',type=Path,required=True)
    p.add_argument('--summary',type=Path,required=True)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    r=verify(frozen_rows(args.seed),args.coefficients,args.summary)
    r['seed']=args.seed
    if args.output:
        args.output.write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
    print(json.dumps(r,sort_keys=True),flush=True)
