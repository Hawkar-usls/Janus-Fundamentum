#!/usr/bin/env python3
"""Exploratory rank-4 LP constraint generation, with exact primal replay.

Uses a floating-point LP only to DISCOVER candidate pseudomoments. A claimed
feasible root bound is accepted exclusively by the separate rational checker.
"""

import argparse
import json
from collections import Counter
from fractions import Fraction
from functools import reduce
from math import lcm
from pathlib import Path

from janus_babel4_lp import make_model,solve_lp
from janus_babel4_scan import selected_rank4_planes,basis_patterns,moment_three
from janus_babel4_rational_certificate import instance_rows,verify
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel
from janus_babel3_exact_pseudomodel import all_root_planes


def score_planes(planes, moment):
    """Most negative of 16 rationalized-probability *numerators*."""
    violations=[]
    for space in planes:
        _,patterns=basis_patterns(space[1:])
        minmargin=min(1+sum(moment.get(q,0)*(-1 if (pat&z).bit_count()&1 else 1)
                            for q,pat in patterns.items() if q)
                      for z in range(16))
        if minmargin < -1e-7:
            violations.append((minmargin,space))
    return sorted(violations)


def try_fraction_record(instance,model,solution,maximum_denominator):
    fracs=[Fraction(float(x)).limit_denominator(maximum_denominator)
           for x in solution.x]
    den=reduce(lcm,(x.denominator for x in fracs),1)
    record={'format':'BABEL4_PSEUDOMOMENTS_V1','instance':instance,
            'rank4_limit':0,'denominator':den,
            'frequencies':model['freqs'],
            'integer_numerators':[int(x*den) for x in fracs],
            'numeric_objective_is_not_proof':float(solution.fun)}
    return record


def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--instance',choices=['SCL63','SAT126','UNSAT126'],default='SCL63')
    a.add_argument('--initial',type=int,default=500)
    a.add_argument('--add',type=int,default=250)
    a.add_argument('--iterations',type=int,default=15)
    a.add_argument('--time-limit',type=float,default=120)
    a.add_argument('--method',choices=['highs-ipm','highs-ds','highs'],default='highs-ipm')
    a.add_argument('--max-denominator',type=int,default=1000000)
    a.add_argument('--output',type=Path)
    args=a.parse_args()
    triples=instance_rows(args.instance)
    rows=validate(triples,len(triples))
    _,kernel=gf2_kernel(rows,len(rows))
    observed=set(columns_of_kernel(kernel,len(rows)))
    planes,dense=selected_rank4_planes(observed)
    positive={q for p in dense for q in p if q not in observed}
    rated=[]
    for p in planes:
        _,patterns=basis_patterns(p[1:])
        worst=min(3+sum(moment_three(q,observed,positive)
                            *(-1 if (pat&z).bit_count()&1 else 1)
                            for q,pat in patterns.items() if q)
                  for z in range(16))
        rated.append((worst,p))
    rated.sort()
    selected={p for _,p in rated[:args.initial]}
    for iteration in range(args.iterations):
        model=make_model(triples,selected_rank4=selected)
        result=solve_lp(model,time_limit=args.time_limit,method=args.method)
        if not result.success:
            print(json.dumps({'iteration':iteration,'status':'LP_STOP',
                'message':result.message,'selected_planes':len(selected)},sort_keys=True),flush=True)
            break
        moments=dict(zip(model['freqs'],result.x))
        scores=score_planes(planes,moments)
        distinct=[(v,p) for v,p in scores if p not in selected]
        print(json.dumps({'iteration':iteration,'objective_float':float(result.fun),
            'selected_planes':len(selected),'rank4_violating_planes_float':len(scores),
            'worst_margin_float':scores[0][0] if scores else None,
            'variables':len(model['freqs'])},sort_keys=True),flush=True)
        if not scores:
            record=try_fraction_record(args.instance,model,result,args.max_denominator)
            try:
                report=verify(record)
            except (AssertionError,KeyError) as exc:
                print(json.dumps({'status':'FLOAT_FEASIBLE_BUT_NOT_EXACT',
                                  'reason':repr(exc),'denominator_digits':len(str(record['denominator']))}),flush=True)
                break
            if args.output:
                args.output.write_text(json.dumps(record,separators=(',',':'),sort_keys=True)+'\n')
            print(json.dumps(report,sort_keys=True,indent=2),flush=True)
            break
        selected.update(p for _,p in distinct[:args.add])
    else:
        print(json.dumps({'status':'ITERATION_LIMIT','selected_planes':len(selected)}),flush=True)


if __name__=='__main__':
    main()
