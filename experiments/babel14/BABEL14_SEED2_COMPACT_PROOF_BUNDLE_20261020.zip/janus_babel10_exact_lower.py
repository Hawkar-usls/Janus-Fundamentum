#!/usr/bin/env python3
"""BABEL-10 exact integer lower bounds against degree-1 multipliers.

An exact integer polynomial with P(C)e0=0, P(0)=0 and nonzero
Q(C)e0 (Q=P/t) gives an exact left-null witness against every
degree-1 row-defect multiplier. Finite-field CRT is DISCOVERY ONLY.
"""

import argparse
import hashlib
import json
from math import gcd
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix

from janus_babel10_degree_scan import character_products, frozen_instances
from janus_babel8_krylov_exact import nextprime
from janus_babel9_krylov_68 import lanczos_for_normal


def build_operator(rows, ell=1):
    labels, d, qsize, supports = character_products(rows, ell)
    n_eq = len(supports)
    matrix = coo_matrix(
        (np.ones(4 * n_eq, dtype=np.int64),
         (np.array(supports, dtype=np.int32).ravel(),
          np.repeat(np.arange(n_eq), 4))),
        shape=(1 << d, n_eq)).tocsr()
    normal = (matrix @ matrix.T).tocsr()
    row_sum_bound = int(np.max(np.asarray(normal.sum(axis=1))))
    return supports, normal, d, qsize, row_sum_bound


def reconstruct(supports, normal, prime_limit=150):
    bound = int(np.max(np.asarray(normal.sum(axis=1))))
    crt = []
    modulus = 1
    prime = 10000019
    degree = None
    accepted = []
    dropped = 0
    limit = None
    for _ in range(prime_limit):
        prime = nextprime(prime)
        try:
            pol = lanczos_for_normal(normal, prime, 500)
        except ArithmeticError:
            dropped += 1
            continue
        if degree is None:
            degree = len(pol) - 1
            crt = [0] * len(pol)
            limit = 2 * pow(bound + 1, degree)
        if len(pol) - 1 != degree:
            dropped += 1
            continue
        inverse = pow(modulus % prime, -1, prime)
        for i, coeff in enumerate(pol):
            crt[i] += ((coeff - crt[i]) % prime) * inverse % prime * modulus
        modulus *= prime
        accepted.append(prime)
        if modulus > limit:
            break
    if modulus <= limit:
        raise RuntimeError('insufficient CRT precision for rigorous reconstruction')
    coefficients = [int(x if x <= modulus // 2 else x - modulus)
                    for x in crt]
    assert coefficients[-1] == 1
    return coefficients, {'CRT_prime_count': len(accepted),
                          'CRT_modulus_exceeds_deterministic_bound': True,
                          'CRT_row_sum_bound': bound,
                          'CRT_dropped_primes': dropped}


def exact_normal(vector, supports):
    result = [0] * len(vector)
    for a, b, c, d in supports:
        v = vector[a] + vector[b] + vector[c] + vector[d]
        if v:
            result[a] += v
            result[b] += v
            result[c] += v
            result[d] += v
    return result


def verify_document(document):
    instances = frozen_instances()
    name = document['instance']
    assert name in instances
    supports, _, d, q_size, row_bound = build_operator(instances[name])
    p = document['polynomial_coefficients_low_to_high']
    assert p[-1] == 1 and p[0] == 0
    assert len(p) - 1 == document['recurrence_degree']
    assert len(supports) == document['distinct_generator_count']
    assert q_size == document['multiplier_character_basis_size']
    assert row_bound == document['normal_operator_row_sum_bound']
    current = [0] * (1 << d)
    for coeff in reversed(p[1:]):
        current = exact_normal(current, supports)
        current[0] += coeff
    # If P(t)=tQ(t), the vector Q(C)e0 is killed by C.
    assert not any(exact_normal(current, supports))
    assert current[0] != 0
    for support in supports:
        assert sum(current[q] for q in support) == 0
    divisor = 0
    for value in current:
        divisor = gcd(divisor, abs(value))
    return {'status': 'EXACT_INTEGER_DEGREE1_NONMEMBERSHIP_PASS',
            'instance': name, 'recurrence_degree': len(p) - 1,
            'multiplier_character_degree_proven_impossible': 1,
            'degree2_SOS_ideal_certificate': 'IMPOSSIBLE',
            'frequency_dimension': 1 << d,
            'integer_frequency_null_witness_nonzero':
            sum(bool(x) for x in current),
            'integer_frequency_null_witness_h0': str(current[0]),
            'integer_frequency_null_witness_gcd': str(divisor),
            'independent_integer_frequency_replay': 'PASS'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--names', nargs='+', default=[
        'SCL63', 'SCL126_flip16', 'SCL126_flip68'])
    parser.add_argument('--max-primes', type=int, default=150)
    parser.add_argument('--verify-only', type=Path)
    args = parser.parse_args()
    if args.verify_only:
        doc = json.loads(args.verify_only.read_text())
        print(json.dumps(verify_document(doc), sort_keys=True, indent=2))
        return
    instances = frozen_instances()
    for name in args.names:
        rows = instances[name]
        supports, normal, d, qsize, bound = build_operator(rows)
        p, crt = reconstruct(supports, normal, args.max_primes)
        doc = {'format': 'JANUS_BABEL10_EXACT_LOWER_SOS2_V1',
               'instance': name, 'n': len(rows),
               'kernel_dimension': d,
               'recurrence_degree': len(p) - 1,
               'distinct_generator_count': len(supports),
               'multiplier_character_basis_size': qsize,
               'normal_operator_row_sum_bound': bound,
               'polynomial_coefficients_low_to_high': p,
               **crt}
        path = Path(f'babel10_{name}_EXACT_DEGREE1_OBSTRUCTION.json')
        path.write_text(json.dumps(doc, sort_keys=True,
                                   separators=(',', ':')) + '\n')
        verification = verify_document(doc)
        verification['proof_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        print(json.dumps(verification, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
