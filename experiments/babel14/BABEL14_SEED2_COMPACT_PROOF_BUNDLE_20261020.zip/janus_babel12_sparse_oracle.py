#!/usr/bin/env python3
"""BABEL-12: implicit polynomial-support Fourier incidence oracle.

For a fixed character multiplier degree ell, enumerate only coordinate
characters expressible by <=ell labels, and explore the incidence connected
component of frequency zero. No 2**dim Fourier array is ever allocated.

Each row has three parity labels a,b,c with a^b^c=0; its defect support
H={0,a,b,c} is an order-four subgroup. Each generator is one affine coset
u+H, for u of coordinate degree <=ell. Supports shared by multiple rows
are deduplicated by subgroup. Connectivity is exactly the bipartite
incidence-component connectivity of the rectangular Fourier multiplier map.
"""

import argparse
import hashlib
import json
import time
from collections import Counter, deque
from pathlib import Path

from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


def row_planes(rows, labels):
    planes = set()
    for row in rows:
        h = tuple(sorted({0, *(labels[j] for j in row)}))
        assert len(h) == 4, (row, h)
        assert h[0] == 0 and h[1] ^ h[2] ^ h[3] == 0
        planes.add(h)
    return sorted(planes)


def explore_zero(rows, ell, limit=None, include_vertices=False):
    """Explore exactly the frequency-zero incidence component.

    Complexity is O(n*|component|*4), with |component| bounded by
    4*n*sum_{j<=ell} binom(n,j), independent of 2**kernel_dim.
    """
    assert ell >= 0
    labels, _, d = xor_labels(rows)
    witnesses = degree_witnesses(labels, ell)
    allowed = set(witnesses)
    planes = row_planes(rows, labels)
    reached = {0}
    waiting = deque([0])
    active_cosets = 0
    attempts = 0
    per_plane = Counter()
    while waiting:
        q = waiting.popleft()
        for i, h in enumerate(planes):
            shifted = (q, q ^ h[1], q ^ h[2], q ^ h[3])
            attempts += 1
            if not any(t in allowed for t in shifted):
                continue
            if q == min(shifted):
                active_cosets += 1
                per_plane[i] += 1
            for t in shifted:
                if t not in reached:
                    reached.add(t)
                    waiting.append(t)
                    if limit is not None and len(reached) > limit:
                        raise RuntimeError('exploration exceeded explicit resource limit')
    encoded = b''.join(int(t).to_bytes((d+7)//8 or 1, 'little')
                       for t in sorted(reached))
    result = {
        'n': len(rows), 'gf2_kernel_dimension': d,
        'character_multiplier_degree': ell,
        'unique_coordinate_characters_le_degree': len(allowed),
        'distinct_row_defect_subgroups': len(planes),
        'zero_incidence_component_vertices': len(reached),
        'zero_incidence_component_cosets': active_cosets,
        'zero_component_vertex_sha256': hashlib.sha256(encoded).hexdigest(),
        'incident_plane_checks': attempts,
        'max_possible_active_vertices_bound': 4*len(planes)*len(allowed),
        'max_possible_active_cosets_bound': len(planes)*len(allowed),
        'enumerates_entire_2^d_frequency_space': False,
        'exact_integer_combinatorics': True,
    }
    if include_vertices:
        result['vertices'] = sorted(reached)
    return result


def brute_component(rows, ell):
    """Independent exhaustive oracle for tiny controls only."""
    labels, _, d = xor_labels(rows)
    assert d <= 14
    allowed = set(degree_witnesses(labels, ell))
    planes = row_planes(rows, labels)
    neighbors = [set() for _ in range(1<<d)]
    for h in planes:
        seen = set()
        for u in allowed:
            coset = tuple(sorted(u ^ j for j in h))
            if coset in seen:
                continue
            seen.add(coset)
            for q in coset:
                neighbors[q].update(coset)
    reached = {0}
    queue = deque([0])
    while queue:
        for q in neighbors[queue.popleft()]:
            if q not in reached:
                reached.add(q)
                queue.append(q)
    return reached


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--instance', default='SCL252_seed0')
    p.add_argument('--degrees', type=int, nargs='+', default=[0,1,2])
    p.add_argument('--output', type=Path)
    p.add_argument('--max-vertices', type=int, default=2000000)
    args=p.parse_args()
    from janus_babel10_degree_scan import frozen_instances
    cases=frozen_instances()
    if args.instance in cases:
        rows=cases[args.instance]
    elif args.instance.startswith('SCL252_seed'):
        from janus_babel10_lift_family import make_lift
        seed=int(args.instance.removeprefix('SCL252_seed'))
        rows,_=make_lift(cases['SCL126_flip68'],seed)
    else:
        raise KeyError(args.instance)
    results=[]
    for ell in args.degrees:
        start=time.monotonic()
        r=explore_zero(rows,ell,args.max_vertices)
        r['instance']=args.instance
        r['elapsed_seconds_diagnostic']=round(time.monotonic()-start,3)
        results.append(r)
        print(json.dumps(r,sort_keys=True),flush=True)
    if args.output:
        args.output.write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':
    main()
