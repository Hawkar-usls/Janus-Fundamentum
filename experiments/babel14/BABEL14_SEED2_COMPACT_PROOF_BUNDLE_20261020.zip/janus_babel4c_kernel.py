#!/usr/bin/env python3
"""BABEL-4c: global degree-4 PSD row-kernel necessary conditions.

This script uses the *entire* 1450 Fourier-character basis of degree <= 2
in the 63 original variables, not selected SOS squares.  At F=-21, all
exact-one row defects have zero quadratic moment.  PSD therefore forces

  L(chi_u * (1 + chi_a + chi_b + chi_c)) = 0

for every u of degree <= 2 and every source row (a,b,c). The resulting
linear map acts on at most 16384 Fourier moments.

The exploratory numerical least-squares diagnostics below are NOT exact
positive/negative SDP certificates. Exact verification support is separate.
"""

import argparse
import hashlib
import json
from collections import Counter
from itertools import combinations
from pathlib import Path

from janus_occam_replay import source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def source_data():
    rows = source_triples(Path(__file__).resolve().with_name('tutte12.am.csv'))
    n = len(rows)
    row_masks = validate(rows, n)
    _, kernel = gf2_kernel(row_masks, n)
    q = columns_of_kernel(kernel, n)
    assert len(kernel) == 14
    defects = []
    for triple in rows:
        labels = tuple(q[i] for i in triple)
        assert len(set(labels)) == 3 and labels[0] ^ labels[1] ^ labels[2] == 0
        defects.append(labels)
    basis = sorted({0,*q,*(a^b for a,b in combinations(q,2))})
    assert len(basis) == 1450 and basis[0] == 0
    return rows, q, defects, basis


def kernel_equations(defects, basis):
    """Deterministic deduplication of 4-sparse homogeneous equations."""
    equations = set()
    for a,b,c in defects:
        for u in basis:
            equations.add(tuple(sorted((u,u^a,u^b,u^c))))
    return sorted(equations)


def build_numeric_map(equations, limit=1 << 14):
    import numpy as np
    from scipy.sparse import csr_matrix
    four = len(equations)
    indices = np.fromiter((q for eq in equations for q in eq),
                          dtype=np.int32,count=4*four)
    data = np.ones(4*four,dtype=np.float64)
    rowptr = np.arange(0,4*(four+1),4,dtype=np.int64)
    mat = csr_matrix((data,indices,rowptr),shape=(four,limit))
    return mat


def numeric_diagnostic(equations,maxiter):
    import numpy as np
    from scipy.sparse.linalg import lsmr
    a = build_numeric_map(equations)
    zerocol = a[:,0].toarray().ravel()
    # s_0 fixed to 1: the remaining 16383 moments must obey A_others*s=-A_0.
    x = lsmr(a[:,1:],-zerocol,atol=1e-11,btol=1e-11,
             maxiter=maxiter,show=False)
    vector = np.concatenate(([1.],x[0]))
    residual = a@vector
    return {'status':'NUMERIC_DIAGNOSTIC_ONLY',
       'solver':'scipy.sparse.linalg.lsmr',
       'iterations':int(x[2]),'istop':int(x[1]),
       'reported_norm_r':float(x[3]),
       'max_abs_residual':float(np.max(np.abs(residual))),
       'norm_residual':float(np.linalg.norm(residual)),
       'max_abs_moment':float(np.max(np.abs(vector))),
       'singular_value_condition_estimate':float(x[6])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--numeric',action='store_true')
    parser.add_argument('--maxiter',type=int,default=1000)
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    rows, labels, defects, basis = source_data()
    equations = kernel_equations(defects,basis)
    histogram = dict(sorted(Counter(sum(q == 0 for q in eq)
                                     for eq in equations).items()))
    report = {'gate':'BABEL-4c',
       'status':'EXACT_EQUATION_GENERATION_VERIFIED',
       'source_rows':len(rows),
       'gf2_nullity':14,
       'degree2_moment_matrix_dimension':len(basis),
       'fourier_moment_domain':1<<14,
       'degree4_kernel_conditions_raw':len(defects)*len(basis),
       'distinct_degree4_kernel_equations':len(equations),
       'number_of_equations_containing_frequency_0':histogram.get(1,0),
       'moment_basis_sha256':hashlib.sha256(
         ','.join(map(str,basis)).encode()).hexdigest(),
       'kernel_equations_sha256':hashlib.sha256(
         ('\n'.join(','.join(map(str,eq)) for eq in equations)+'\n').encode()
         ).hexdigest()}
    if args.numeric:
        report['numeric']=numeric_diagnostic(equations,args.maxiter)
    if args.output:
        args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
