#!/usr/bin/env python3
"""BABEL-5: all global degree-four PSD zero-defect equations of UNSAT SCL126.

Construct from the frozen connected 2-lift of SCL63, not a new search mask.
For a hypothetical F=-42 and PSD moment matrix, g_r lies in its kernel;
thus L(g_r*chi_u)=0 for each degree<=2 character u.
"""

import argparse
import hashlib
import json
from itertools import combinations
from pathlib import Path

from janus_occam_replay import FIXTURES,cover,source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel


def source_data():
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    rows=cover(source,FIXTURES[1][1])
    assert len(rows)==126
    masks=validate(rows,126)
    _,kernel=gf2_kernel(masks,126)
    assert len(kernel)==15
    observed=columns_of_kernel(kernel,126)
    assert len(observed)==126
    defects=[]
    for row in rows:
        a,b,c=(observed[i] for i in row)
        assert len({a,b,c,0})==4 and a^b^c==0
        defects.append((a,b,c))
    basis=sorted({0,*observed,*(a^b for a,b in combinations(observed,2))})
    assert len(basis)==2781
    return rows,observed,defects,basis


def equations_and_origins(defects,basis,origins=False):
    found={}
    for r,(a,b,c) in enumerate(defects):
        for u in basis:
            support=tuple(sorted((u,u^a,u^b,u^c)))
            if support not in found:
                found[support]=(r,u) if origins else None
    eq=sorted(found)
    return (eq,found) if origins else eq


def numeric_diagnostic(equations,domain=32768,maxiter=1000):
    import numpy as np
    from scipy.sparse import csr_matrix
    from scipy.sparse.linalg import lsmr
    k=len(equations)
    indices=np.fromiter((p for support in equations for p in support),
                        dtype=np.int32,count=4*k)
    pointers=np.arange(0,4*(k+1),4,dtype=np.int64)
    data=np.ones(4*k,dtype=np.float64)
    mat=csr_matrix((data,indices,pointers),shape=(k,domain))
    b=-mat[:,0].toarray().ravel()
    result=lsmr(mat[:,1:],b,atol=1e-11,btol=1e-11,maxiter=maxiter)
    moment=np.concatenate(([1.0],result[0]))
    residual=mat@moment
    return {'status':'NUMERICAL_DIAGNOSTIC_ONLY',
       'lsmr_termination':int(result[1]),'iterations':int(result[2]),
       'residual_norm_2':float(np.linalg.norm(residual)),
       'residual_max_abs':float(np.max(np.abs(residual))),
       'max_abs_moment':float(np.max(np.abs(moment)))}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--numeric',action='store_true')
    p.add_argument('--maxiter',type=int,default=1000)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    rows,columns,defects,basis=source_data()
    eq=equations_and_origins(defects,basis)
    result={'gate':'BABEL-5','instance':'UNSAT126',
            'rows':126,'GF2_nullity':15,
            'domain':32768,'observed_frequency_types':len(set(columns)),
            'moment_matrix_dimension':len(basis),
            'raw_zero_defect_equations':len(rows)*len(basis),
            'distinct_zero_defect_equations':len(eq),
            'basis_sha256':hashlib.sha256(
               ','.join(map(str,basis)).encode()).hexdigest(),
            'equation_sha256':hashlib.sha256(
               ('\n'.join(','.join(map(str,s)) for s in eq)+'\n').encode()
               ).hexdigest()}
    if args.numeric:
        result['numeric']=numeric_diagnostic(eq,maxiter=args.maxiter)
    if args.output:
        args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
