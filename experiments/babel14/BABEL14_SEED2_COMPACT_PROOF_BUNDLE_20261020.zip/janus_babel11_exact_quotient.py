#!/usr/bin/env python3
"""Exact equitable Fourier quotient and modular determinant pilot for SOS4.

An equitable partition under integer normal C=M M^T yields a rational
invariant cell-constant subspace. Since e0 is a singleton cell, invertibility
of the quotient over *one* prime proves e0 belongs to range(C) over Q, hence
an exact rational SOS4 identity exists. This is a genuine mathematical
certificate of existence, not merely a modular guess, once quotient
equivariance and full-rank mod-p are independently replayed.
"""

import argparse
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix

from janus_babel8_krylov_exact import matrices, nextprime


def equitable_partition(normal, max_rounds=20):
    n=normal.shape[0]
    colors=[int(v!=0) for v in range(n)]
    sizes=[]
    for round_index in range(max_rounds):
        signatures=[]
        for i in range(n):
            weighted=defaultdict(int)
            for pos in range(normal.indptr[i],normal.indptr[i+1]):
                weighted[colors[normal.indices[pos]]]+=int(normal.data[pos])
            signatures.append((colors[i],tuple(sorted(weighted.items()))))
        lookup={}
        updated=[lookup.setdefault(signature,len(lookup))
                 for signature in signatures]
        sizes.append(len(lookup))
        if updated==colors:
            return colors,sizes
        colors=updated
    raise AssertionError(f'equitable partition did not stabilize: {sizes}')


def quotient(normal,colors):
    n=normal.shape[0]
    m=max(colors)+1
    sizes=np.bincount(np.array(colors,dtype=np.int32),minlength=m)
    assert sizes.sum()==n and sizes[colors[0]]==1
    representatives={}
    for i,cell in enumerate(colors):representatives.setdefault(cell,i)
    rows=[];cols=[];data=[]
    for cell,i in sorted(representatives.items()):
        weights=defaultdict(int)
        for pos in range(normal.indptr[i],normal.indptr[i+1]):
            weights[colors[normal.indices[pos]]]+=int(normal.data[pos])
        for dest,weight in weights.items():
            rows.append(cell);cols.append(dest);data.append(weight)
    Q=csr_matrix((np.array(data,dtype=np.int64),(rows,cols)),shape=(m,m))
    # Independently check every original Fourier vertex, exactly over Z:
    for i in range(n):
        expected={int(j):int(v) for j,v in zip(
            Q.indices[Q.indptr[colors[i]]:Q.indptr[colors[i]+1]],
            Q.data[Q.indptr[colors[i]]:Q.indptr[colors[i]+1]])}
        actual=defaultdict(int)
        for pos in range(normal.indptr[i],normal.indptr[i+1]):
            actual[colors[normal.indices[pos]]]+=int(normal.data[pos])
        assert dict(actual)==expected
    # Weighted symmetry is guaranteed by C=C^T but checked explicitly.
    for i in range(m):
        for pos in range(Q.indptr[i],Q.indptr[i+1]):
            j=int(Q.indices[pos])
            opposite=int(Q[j,i])
            assert int(sizes[i])*int(Q.data[pos]) ==int(sizes[j])*opposite
    return Q,sizes


def weighted_lanczos(matrix,weights,prime,random_seed=0,max_steps=None,
                     include_polynomial=False,start_index=None):
    """Lanczos for symmetrizable quotient over GF(p), with random start."""
    n=matrix.shape[0]
    if max_steps is None:max_steps=n+1
    rng=random.Random(random_seed)
    old=np.zeros(n,dtype=np.int64)
    if start_index is None:
        current=np.array([rng.randrange(1,prime) for _ in range(n)],
                         dtype=np.int64)
    else:
        current=np.zeros(n,dtype=np.int64)
        current[start_index]=1
    modweights=weights%prime
    oldnorm=0
    previous=[0]
    polynomial=[1]
    alphas=[];betas=[]
    for step in range(max_steps):
        norm=int(np.dot((current*modweights)%prime,current)%prime)
        if norm==0:
            raise ArithmeticError(f'isotropic norm at step {step}')
        evaluated=matrix.dot(current)%prime
        alpha=int(np.dot((current*modweights)%prime,evaluated)%prime)
        alpha=alpha*pow(norm,-1,prime)%prime
        beta=norm*pow(oldnorm,-1,prime)%prime if step else 0
        following=(evaluated-alpha*current-beta*old)%prime
        nextpolynomial=[0]*(len(polynomial)+1)
        for j,coeff in enumerate(polynomial):
            nextpolynomial[j]=(nextpolynomial[j]-alpha*coeff)%prime
            nextpolynomial[j+1]=(nextpolynomial[j+1]+coeff)%prime
        for j,coeff in enumerate(previous):
            nextpolynomial[j]=(nextpolynomial[j]-beta*coeff)%prime
        previous,polynomial=polynomial,nextpolynomial
        alphas.append(alpha);betas.append(beta)
        if not np.any(following):
            result={'degree':len(polynomial)-1,
                    'constant_nonzero':bool(polynomial[0]),
                    'constant':polynomial[0],
                    'prime':prime,'seed':random_seed,
                    'all_intermediate_norms_nonzero':True,
                    'lanczos_alpha_beta_sha256':hashlib.sha256(
                        json.dumps([alphas,betas],separators=(',',':')).encode()
                    ).hexdigest()}
            if include_polynomial:
                result['polynomial_coefficients_mod_prime']=polynomial
            return result
        old,current=current,following
        oldnorm=norm
    raise ArithmeticError(f'exceeded {max_steps} weighted Lanczos steps')


def audit(bit=94,primes=(100003,100019,100043),seeds=(0,1,2)):
    _,m,mt,basis,bound=matrices(bit)
    normal=(m@mt).tocsr()
    colors,history=equitable_partition(normal)
    Q,sizes=quotient(normal,colors)
    experiments=[]
    for prime in primes:
        for seed in seeds:
            try:
                evidence=weighted_lanczos(Q,sizes,prime,seed,Q.shape[0]+1)
            except ArithmeticError as err:
                evidence={'prime':prime,'seed':seed,'error':str(err)}
            experiments.append(evidence)
            print(json.dumps(evidence,sort_keys=True),flush=True)
            if evidence.get('degree')==Q.shape[0] and evidence.get('constant_nonzero'):
                break
        if experiments[-1].get('degree')==Q.shape[0] and experiments[-1].get('constant_nonzero'):
            break
    exact_full_rank=any(v.get('degree')==Q.shape[0] and
                        v.get('constant_nonzero') for v in experiments)
    report={'bit':bit,'original_frequency_dimension':normal.shape[0],
            'equitable_partition_history':history,
            'equitable_final_cells':Q.shape[0],
            'quotient_nnz':Q.nnz,
            'zero_frequency_singleton':bool(sizes[colors[0]]==1),
            'exact_Z_equivariance':'PASS',
            'exact_weighted_self_adjointness':'PASS',
            'modular_weighted_lanczos':experiments,
            'full_quotient_rank_mod_p_found':exact_full_rank,
            'rational_SOS4_existence_PROVED':exact_full_rank,
            'scientific_status':('EXACT_RATIONAL_EXISTENCE_PASS' if
                                 exact_full_rank else 'OPEN_NO_FULL_RANK_WITNESS')}
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bit',type=int,default=94)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_BIT94_EXACT_QUOTIENT.json'))
    args=p.parse_args()
    report=audit(args.bit)
    args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()
                      if k!='modular_weighted_lanczos'},sort_keys=True),flush=True)


if __name__=='__main__':main()
