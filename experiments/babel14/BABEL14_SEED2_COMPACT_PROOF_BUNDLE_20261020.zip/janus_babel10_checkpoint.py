#!/usr/bin/env python3
"""Machine-readable provenance-aware BABEL-10 gate manifest.

All statuses have explicit authority; modular pilot does not confer proof.
"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).parent


def sha(name):
    return hashlib.sha256((ROOT / name).read_bytes()).hexdigest()


def checkpoint():
    names = ['SCL63', *(f'SCL126_flip{bit}' for bit in
                         (16, 59, 68, 81, 94, 132, 168, 169))]
    lower = []
    for name in names:
        path = f'babel10_{name}_EXACT_DEGREE1_OBSTRUCTION.json'
        proof = json.loads((ROOT / path).read_text())
        lower.append({'instance': name, 'proof_file': path,
                      'proof_sha256': sha(path),
                      'recurrence_degree': proof['recurrence_degree'],
                      'SOS_degree_at_most_2': 'EXACTLY_EXCLUDED'})
    degree4 = []
    for bit in (16, 59, 68, 81, 132):
        if bit == 16:
            path = 'babel8_DEGREE4_KRYLOV_RATIONAL_DUAL.json'
            verification = 'babel8_DEGREE4_EXACT_VERIFICATION.json'
        elif bit == 68:
            path = 'babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json'
            verification = 'babel9_BIT68_DEGREE4_INTEGER_VERIFICATION.json'
        else:
            path = f'babel10_SCL126_BIT{bit}_DEGREE4_REUSED_POLYNOMIAL.json'
            verification = f'babel10_SCL126_BIT{bit}_DEGREE4_VERIFICATION.json'
        result = json.loads((ROOT / verification).read_text())
        assert result['rational_SOS_degree'] == 4
        assert result['exact_integer_frequency_replay'] == 'PASS'
        degree4.append({'bit': bit, 'proof_file': path,
                        'proof_sha256': sha(path),
                        'verification_file': verification,
                        'verified_recurrence_degree': result['recurrence_degree'],
                        'minimal_SOS_degree': 4,
                        'status': 'LOCAL_EXACT_VERIFIED'})
    covers = json.loads((ROOT / 'babel10_CONNECTED_SCL252_AUDIT.json')
                        .read_text())
    transfer = json.loads((ROOT / 'babel10_SCL252_EXACT_LOWER_TRANSFER.json')
                          .read_text())
    assert len(covers) == len(transfer) == 5
    assert all(c['status'] == 'UNSAT' and c['exact_SAT_count'] == 0
               for c in covers)
    assert all(c['exact_integer_dual_annihilation'] == 'PASS'
               for c in transfer)
    pilot = json.loads((ROOT / 'babel10_EIGHT_SOS4_MODULAR_PILOT.json')
                       .read_text())
    assert all(item['scientific_status'] == 'MODULAR_DIAGNOSTIC_ONLY'
               for item in pilot)
    return {'format': 'JANUS_BABEL10_MINIMAL_SOS_DEGREE_GATE_V1',
            'date': '2026-10-19',
            'CI': 'NOT_RUN',
            'exact_SOS2_nonmembership': lower,
            'exact_minimal_SOS4': degree4,
            'remaining_SCL126_bits_with_minimal_degree_open': [94, 168, 169],
            'remaining_exact_degree_interval': [4, 6],
            'SCL252_verified_UNSAT_count': 5,
            'SCL252_exact_state_counts': [c['checked_kernel_states']
                                          for c in covers],
            'SCL252_SOS_lower_bound': 4,
            'SCL252_exact_transfer_data':
            'babel10_SCL252_EXACT_LOWER_TRANSFER.json',
            'cyclic_infinite_family_formula':
            'rows_i={i,i+1,i+3} mod n, n>=7',
            'cyclic_infinite_family_SOS_degree':
            '0 when 7 does not divide n; 2 when 7 divides n',
            'cyclic_exact_controls':
            'babel10_CYCLIC_FAMILY_EXACT_CONTROLS.json',
            'SOS4_two_prime_screen': pilot,
            'new_general_theorem':
            'SOS Fourier multiplier minimum degree does not decrease under finite graph lifts',
            'universal_polynomial_SolveLinearCubicXSAT': 'NOT_CONSTRUCTED',
            'P_vs_NP': 'OPEN'}


if __name__ == '__main__':
    data = checkpoint()
    path = ROOT / 'babel10_GATE_CHECKPOINT.json'
    path.write_text(json.dumps(data, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': 'PASS',
                      'exact_min_SOS4_cases': len(data['exact_minimal_SOS4']),
                      'exact_SOS2_obstructions': len(data['exact_SOS2_nonmembership']),
                      'new_connected_UNSAT_252': data['SCL252_verified_UNSAT_count'],
                      'still_open_SCL126_bits': data['remaining_SCL126_bits_with_minimal_degree_open']},
                     sort_keys=True))
