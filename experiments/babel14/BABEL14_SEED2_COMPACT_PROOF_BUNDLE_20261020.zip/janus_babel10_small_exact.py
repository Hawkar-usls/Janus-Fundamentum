#!/usr/bin/env python3
"""Exact rational low-dimensional Fourier ideal-membership solver.

Applicable when the parity-kernel dimension is small (e.g. Fano tower).
Unlike LSMR, the certificate is verified over Q coefficient-by-coefficient.
"""

import json
from collections import defaultdict
from fractions import Fraction
from math import lcm
from pathlib import Path

from janus_babel10_degree_scan import character_products
from janus_babel10_fano_tower import fano
from janus_babel10_lift_family import connected_incidence, make_lift


def add_scaled(vec, other, scale):
    for key, val in other.items():
        new = vec.get(key, Fraction(0)) + scale * val
        if new:
            vec[key] = new
        else:
            vec.pop(key, None)


def exact_membership(rows, ell):
    _, d, qsize, generators = character_products(rows, ell)
    if d > 9:
        raise ValueError('small exact solver cap: d<=9')
    pivots = {}
    for index, support in enumerate(generators):
        vec = {q: Fraction(1) for q in support}
        combo = {index: Fraction(1)}
        while vec:
            at = min(vec)
            if at not in pivots:
                inv = Fraction(1, 1) / vec[at]
                pivots[at] = ({q: coeff * inv for q, coeff in vec.items()},
                              {q: coeff * inv for q, coeff in combo.items()})
                break
            source, representation = pivots[at]
            factor = vec[at]
            add_scaled(vec, source, -factor)
            add_scaled(combo, representation, -factor)
    rem = {0: Fraction(1)}
    answer = {}
    while rem:
        at = min(rem)
        if at not in pivots:
            return {'membership': False, 'rank': len(pivots),
                    'frequency_dimension': 1 << d}
        source, representation = pivots[at]
        factor = rem[at]
        add_scaled(rem, source, -factor)
        add_scaled(answer, representation, factor)
    actual = defaultdict(Fraction)
    for index, coeff in answer.items():
        for q in generators[index]:
            actual[q] += coeff
    assert {q: val for q, val in actual.items() if val} == {0: Fraction(1)}
    denominator = 1
    for coeff in answer.values():
        denominator = lcm(denominator, coeff.denominator)
    return {'membership': True, 'rank': len(pivots),
            'frequency_dimension': 1 << d,
            'nonzero_exact_multiplier_terms': len(answer),
            'integer_normalization_D': denominator,
            'integer_multiplier_coefficients': [
                [index, int(coeff * denominator)]
                for index, coeff in sorted(answer.items())]}


def main():
    rows = fano()
    results = []
    for level in range(5):
        result = exact_membership(rows, 1)
        result['n'] = len(rows)
        result['tower_level'] = level
        assert result['membership']
        results.append({k: v for k, v in result.items()
                        if k != 'integer_multiplier_coefficients'})
        print(json.dumps(results[-1], sort_keys=True), flush=True)
        if level < 4:
            for seed in range(20):
                candidate, _ = make_lift(rows, seed + 101 * level)
                if connected_incidence(candidate):
                    rows = candidate
                    break
            else:
                raise AssertionError('no connected next level')
    Path('babel10_FANO_TOWER_EXACT_DEGREE1_PASS.json').write_text(
        json.dumps(results, sort_keys=True, indent=2) + '\n')


if __name__ == '__main__':
    main()
