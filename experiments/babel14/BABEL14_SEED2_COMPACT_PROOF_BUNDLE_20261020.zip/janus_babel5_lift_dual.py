#!/usr/bin/env python3
"""Lift a *restricted* SCL63 polynomial identity into UNSAT SCL126.

Only base characters with BOTH Q126 Fourier lifts can be multiplied by
the idempotent P+=(1+chi_e)/2 while staying in the degree<=2 basis.
If the restricted source still has a rational identity, the positive sector
of the cover is certified without raising the SOS degree.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from janus_babel4c_kernel import kernel_equations,source_data as data63
from janus_babel4c_exact_dual import normal_operator
from janus_babel5_kernel import source_data as data126
from janus_babel5_projection import linear_projection


def restricted_source():
    apply,extra,_=linear_projection()
    _,_,defects,base_basis=data63()
    _,_,_,cover_basis=data126()
    cover_set=set(cover_basis)
    fibers=Counter(apply(q) for q in cover_set)
    chosen=[q for q in base_basis if fibers[q]==2]
    assert len(chosen)==1331
    pairs={}
    for q in cover_set:
        base=apply(q)
        if base in chosen:
            pairs.setdefault(base,[]).append(q)
    assert all(len(qq)==2 and qq[0]^qq[1]==extra for qq in pairs.values())
    return defects,chosen,pairs


def numeric():
    from janus_babel4c_kernel import build_numeric_map
    from scipy.sparse.linalg import lsmr
    import numpy as np
    defects,chosen,_=restricted_source()
    equations=kernel_equations(defects,chosen)
    a=build_numeric_map(equations,limit=16384)
    b=-a[:,0].toarray().ravel()
    ans=lsmr(a[:,1:],b,atol=1e-11,btol=1e-11,maxiter=400)
    residual=a@np.concatenate(([1.],ans[0]))
    return {'source_basis_restricted':len(chosen),
       'distinct_restricted_source_equations':len(equations),
       'LSMR_iter':int(ans[2]),
       'LSMR_residual':float(np.linalg.norm(residual)),
       'status':'NUMERIC_PROBE_ONLY'}


if __name__=='__main__':
    print(json.dumps(numeric(),sort_keys=True,indent=2))
