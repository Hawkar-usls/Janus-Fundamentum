#!/usr/bin/env python3
"""Deterministically regenerate frozen BABEL-3 rational certificates."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_babel3_solver import prove
from janus_babel3_rational_verify import verify
from janus_babel3_exact_cuts import overlap_cut
from janus_babel3_exact_pseudomodel import exact_sparse_pseudo,exact_dense5_pseudo
from janus_babel2_factor import components


SOURCE_SHA='3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899'
ORDER=[9,0,1,5,8,12,11,2,14,4,3,13,6,7,10]


def dump(root,name,data):
    path=root/name
    path.write_text(json.dumps(data,sort_keys=True,indent=1)+'\n')
    return {'name':name,'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    root=Path(__file__).resolve().parent
    srcfile=root/'tutte12.am.csv'
    assert hashlib.sha256(srcfile.read_bytes()).hexdigest()==SOURCE_SHA
    source=source_triples(srcfile)
    fixtures=[('SOURCE63_UNSAT',source,0,None,'UNSAT',-17)]
    for name,mask,expected_sat,rank in FIXTURES[:2]:
        fixtures.append((name,cover(source,mask),6,mask,
                         'SAT' if expected_sat else 'UNSAT',
                         -42 if expected_sat else -34))
    output={}
    for name,rows,width,mask,expected_status,minimum in fixtures:
        assert len(components(rows))==1, f'{name} should be connected'
        opts={'block_width':width,
              'metadata':{'source_sha256':SOURCE_SHA,
                          'frozen_fixture':name,'mask_hex':mask,
                          'connected':True}}
        if width:
            opts['order']=ORDER
        cert=prove(rows,**opts)
        exact=verify(cert)
        assert exact['exact_one_status']==expected_status
        assert exact['minimum_F']==minimum
        path_name=f'JANUS_BABEL3_{name}_OVERLAP_20261018.json'
        meta=dump(root,path_name,cert)
        output[name]={**exact,**meta,
                      'direct_scores_reported_by_constructor':
                          cert['individual_scores_evaluated_by_constructor']}

    exact_cuts={'source63':overlap_cut(source)}
    exact_cuts['SOURCE63_DENSE5_PSEUDOMODEL']=exact_dense5_pseudo(source)
    for name,mask,_,_ in FIXTURES[:2]:
        lifted=cover(source,mask)
        exact_cuts[name]=overlap_cut(lifted)
        exact_cuts[name+'_DENSE5_PSEUDOMODEL']=exact_dense5_pseudo(lifted)
    exact_cuts['SOURCE63_FULL_LOCAL_PSEUDOMODEL']=exact_sparse_pseudo(source)
    assert exact_cuts['SOURCE63_FULL_LOCAL_PSEUDOMODEL']['status']==\
           'EXACT_RANK3_PSEUDOMODEL_FEASIBLE'
    output['exact_root_cuts_and_pseudomodel']=dump(
        root,'JANUS_BABEL3_EXACT_ROOT_AUDIT_20261018.json',exact_cuts)
    print(json.dumps(output,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
