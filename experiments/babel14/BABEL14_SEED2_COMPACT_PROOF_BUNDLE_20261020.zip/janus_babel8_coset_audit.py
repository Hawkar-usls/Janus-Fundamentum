#!/usr/bin/env python3
"""BABEL-8: independent per-cover degree-three coset screening.

All modular rank/membership outputs are diagnostics, NOT rational proofs.
The active-coset count is exact and uses only sparse source-proof support.
"""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels, make_projection
from janus_babel7_degree_audit import (degree_witnesses,
                                       lifted_source_remainder)
from janus_babel7_local_probe import span_closure, modular_probe
from janus_babel7_strip_scan import BALANCED_EDGE_FLIPS
from janus_occam_replay import FIXTURES, cover


def row_local_quotient(source, covered, labels, rows):
    n = len(source)
    local = {labels[j] for r in rows for sheet in (0, 1)
             for j in covered[r + sheet * n]}
    pivots = {}
    for value in sorted(local):
        x = value
        while x:
            p = x.bit_length() - 1
            if p not in pivots:
                pivots[p] = x
                break
            x ^= pivots[p]

    def quotient(q):
        x = q
        for p in sorted(pivots, reverse=True):
            if x & (1 << p):
                x ^= pivots[p]
        return x

    defects = {r: tuple(labels[j] for j in covered[r])
               for row in rows for r in (row, row + n)}
    return len(pivots), quotient, defects


def case_data(bit, rows):
    source, base_terms, D = load_base()
    mask = format(int(FIXTURES[1][1], 16) ^ (1 << bit), 'x')
    lifted = cover(source, mask)
    base_labels, _, base_dim = xor_labels(source)
    labels, Q2, dim = xor_labels(lifted)
    pi, extra = make_projection(base_labels, labels, base_dim, dim)
    difference, remainder, reps = lifted_source_remainder(
        source, base_terms, D, lifted, labels, Q2, pi, extra)
    rank, quotient, defects = row_local_quotient(source, lifted, labels, rows)
    # The extra character must be in the strip span.
    assert quotient(extra) == 0
    targets = defaultdict(lambda: defaultdict(int))
    for q, c in difference.items():
        targets[quotient(q)][q] += 2 * c
        targets[quotient(q)][q ^ extra] -= 2 * c
    targets = {c: {q: v for q, v in t.items() if v}
               for c, t in targets.items()}
    return (source, lifted, labels, extra, remainder, reps, quotient, defects,
            targets, rank)


def modular_case(bit, rows, degree=3, prime=1000000007):
    (source, lifted, labels, extra, remainder, reps, quotient, defects,
     targets, rank) = case_data(bit, rows)
    witnesses = degree_witnesses(labels, degree)
    by_coset = defaultdict(list)
    for u in witnesses:
        by_coset[quotient(u)].append(u)
    counts = Counter()
    failures = []
    equation_counts = {}
    for coset, target in sorted(targets.items()):
        supports = set()
        for columns in defects.values():
            for u in by_coset[coset]:
                supports.add(tuple(sorted((u, *(u ^ a for a in columns)))))
        report = modular_probe(sorted(supports), target, prime)
        passed = report['target_in_modular_span']
        counts[bool(passed)] += 1
        if not passed:
            failures.append(coset)
        equation_counts[coset] = len(supports)
    return {'flip': bit, 'sector_extra_character': extra,
            'local_span_rank': rank, 'ambient_kernel_dimension': 15,
            'ambient_cosets': 1 << (15 - rank),
            'active_cosets': len(targets),
            'degree': degree,
            'local_strip': rows,
            'modular_passes': counts[True],
            'modular_failures': counts[False],
            'failure_cosets': failures,
            'candidate_terms_per_coset': dict(equation_counts),
            'warning': 'modular feasibility is not a rational SOS certificate'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bit', type=int)
    parser.add_argument('--degree', type=int, choices=(2, 3), default=3)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    archive = json.loads(Path(__file__).with_name(
        'babel7_EIGHT_BALANCED_LOCAL_SECTOR_CERTIFICATES.json').read_text())
    rows = {a['bit']: a['certificate']['source_rows_used']
            for a in archive['cases']}
    bits = [args.bit] if args.bit is not None else list(BALANCED_EDGE_FLIPS)
    results = []
    for bit in bits:
        report = modular_case(bit, rows[bit], args.degree)
        results.append(report)
        print(json.dumps({k: v for k, v in report.items()
                          if k not in ('candidate_terms_per_coset',
                                       'failure_cosets')}, sort_keys=True),
              flush=True)
    if args.output:
        args.output.write_text(json.dumps(results, indent=2,
                                          sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
