#!/usr/bin/env python3
"""BABEL-2: exact compositional proof for variable-disjoint SCL components.

For disconnected legal SCL, avoid constructing the exponentially larger
global address space: min F is additive over independent components.
Connected instances simply have one component and are not accelerated.
"""

import argparse
import json
from collections import defaultdict
from pathlib import Path

from janus_occam_solver import validate
from janus_babel2_solver import certified_minimum


FORMAT='JANUS_BABEL2_component_product_v1'


def components(triples):
    n=len(triples)
    validate(triples,n)
    parent=list(range(n))
    def find(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]]
            x=parent[x]
        return x
    def union(x,y):
        a,b=find(x),find(y)
        if a!=b:
            parent[b]=a
    for a,b,c in triples:
        union(a,b)
        union(b,c)
    vertices=defaultdict(list)
    for j in range(n):
        vertices[find(j)].append(j)
    rows=defaultdict(list)
    for i,triple in enumerate(triples):
        root=find(triple[0])
        assert all(find(j)==root for j in triple)
        rows[root].append(i)
    result=[]
    for root, variables in sorted(vertices.items(),key=lambda p:p[1][0]):
        row_indices=rows[root]
        assert len(variables)==len(row_indices)
        renumber={j:i for i,j in enumerate(variables)}
        local=[[renumber[j] for j in triples[i]] for i in row_indices]
        result.append({'variables':variables,'row_indices':row_indices,
                       'local_triples':local})
    return result


def prove(triples,block_width=0):
    n=len(triples)
    groups=components(triples)
    certs=[]
    total_F=0
    leaf_count=0
    score_checks=0
    for component in groups:
        local=component['local_triples']
        subcert=certified_minimum(local,block_width=min(block_width,len(local)))
        certs.append({'variables':component['variables'],
                      'row_indices':component['row_indices'],
                      'proof':subcert})
        total_F+=subcert['minimum_F']
        leaf_count+=subcert['proof_leaf_count']
        score_checks+=subcert['individual_scores_evaluated_by_constructor']
    all_sat=all(item['proof']['exact_one_status']=='SAT' for item in certs)
    return {'format':FORMAT,'n':n,
            'row_triples':[list(row) for row in triples],
            'components':certs,
            'component_count':len(certs),
            'exact_global_min_F':total_F,
            'exact_one_status':'SAT' if all_sat else 'UNSAT',
            'component_proof_leaves_total':leaf_count,
            'explicit_scores_evaluated_total':score_checks}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('instance',type=Path)
    p.add_argument('--block-width',type=int,default=0)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    inp=json.loads(args.instance.read_text())
    result=prove(inp['rows'],args.block_width)
    args.output.write_text(json.dumps(result,sort_keys=True,indent=1)+'\n')
    print(json.dumps({k:result[k] for k in ('n','component_count',
                      'exact_global_min_F','exact_one_status',
                      'component_proof_leaves_total','explicit_scores_evaluated_total')},
                     indent=2))


if __name__=='__main__':
    main()
