#!/usr/bin/env python3
"""Signed graph negative control: frozen SAT vs UNSAT SCL126 covers.

For either nullity-15 2-lift of the same base, the 40 variables whose
sheet-character labels differ form a signed graph with 60 edges. A balanced
graph is necessary for a zero-defect assignment in the negative sector.
"""

import json
from collections import defaultdict,deque
from pathlib import Path

from janus_occam_replay import FIXTURES,cover,source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel


def signed_graph_report(name,mask):
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    rows=cover(source,mask)
    _,kernel=gf2_kernel(validate(rows,126),126)
    assert len(kernel)==15
    col=columns_of_kernel(kernel,126)
    split={i for i in range(63) if col[i]!=col[i+63]}
    assert len(split)==40
    graph=defaultdict(list)
    edge_count=0
    for r,base in enumerate(source):
        two=sorted(split.intersection(base))
        assert len(two) in (0,2)
        if not two:
            continue
        signs=[]
        for i in two:
            selected=next(j for j in rows[r] if j%63==i)
            signs.append(1 if col[selected]==col[i] else -1)
        a,b=two
        relation=-signs[0]*signs[1]
        graph[a].append((b,relation))
        graph[b].append((a,relation))
        edge_count+=1
    assigned={}
    conflicts=0
    component_count=0
    for i in sorted(graph):
        if i in assigned:
            continue
        component_count+=1
        assigned[i]=1
        todo=deque([i])
        while todo:
            u=todo.popleft()
            for v,sign in graph[u]:
                predicted=sign*assigned[u]
                if v not in assigned:
                    assigned[v]=predicted
                    todo.append(v)
                elif assigned[v]!=predicted:
                    conflicts+=1
    assert edge_count==60 and len(graph)==40
    return {'frozen_fixture':name,'gf2_nullity':15,
      'signed_graph_vertices':len(graph),
      'signed_graph_edges':edge_count,
      'connected_components':component_count,
      'balanced':conflicts==0,
      'observed_signed_conflicts':conflicts}


if __name__=='__main__':
    results=[signed_graph_report(name,mask)
             for name,mask,*_ in FIXTURES[:2]]
    assert results[0]['balanced'] and not results[1]['balanced']
    print(json.dumps({'status':'FROZEN_SAT_UNSAT_SIGNED_GRAPH_CONTROL_PASS',
                      'results':results},indent=2,sort_keys=True))
