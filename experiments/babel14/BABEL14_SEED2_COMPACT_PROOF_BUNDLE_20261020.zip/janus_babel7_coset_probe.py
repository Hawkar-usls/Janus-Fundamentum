#!/usr/bin/env python3
"""BABEL-7 cosetwise modular probe for degree-2/3 local corrections.

The 9-dimensional span of seven local source rows splits 32768 Fourier labels
into exactly 64 cosets of size 512. Each degree-k row-character equation acts
within one coset. Mod-p membership is a discovery diagnostic, never a proof.
"""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from janus_babel7_degree_audit import audit,degree_witnesses
from janus_babel7_local_probe import DEFAULT_ROWS,span_closure,modular_probe
from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels
from janus_occam_replay import FIXTURES,cover


def coset_data():
    src,_,_=load_base()
    covered=cover(src,format(int(FIXTURES[1][1],16)^(1<<16),'x'))
    labels,Q,d=xor_labels(covered)
    n=len(src)
    local_labels={labels[j] for r in DEFAULT_ROWS for sheet in (0,1)
                  for j in covered[r+sheet*n]}
    group=span_closure(local_labels)
    assert len(group)==512
    pivots={}
    for value in sorted(local_labels):
        x=value
        while x:
            p=x.bit_length()-1
            if p not in pivots:
                pivots[p]=x
                break
            x^=pivots[p]
    assert len(pivots)==9
    def quotient(q):
        x=q
        for p in sorted(pivots,reverse=True):
            if x&(1<<p):x^=pivots[p]
        return x
    covered_labels_by_row={r:tuple(labels[j] for j in covered[r])
                           for r in DEFAULT_ROWS+ [r+n for r in DEFAULT_ROWS]}
    return labels,quotient,covered_labels_by_row


def investigate(degree=3):
    info,difference,H,reps,witness=audit(16)
    labels,quotient,defects=coset_data()
    degree_sets=degree_witnesses(labels,max_degree=degree)
    by_coset=defaultdict(list)
    for u in degree_sets:
        by_coset[quotient(u)].append(u)
    targets=defaultdict(lambda:defaultdict(int))
    e=2128
    for q,c in difference.items():
        coset=quotient(q)
        targets[coset][q]+=c
        targets[coset][q^e]-=c
    histogram=Counter()
    unsolved=[]
    results={}
    for coset,target in sorted(targets.items()):
        eq=set()
        for row,columns in defects.items():
            for u in by_coset[coset]:
                eq.add(tuple(sorted((u,*(u^a for a in columns)))))
        report=modular_probe(sorted(eq),target,1000000007)
        histogram[report['target_in_modular_span']]+=1
        results[coset]={
            'admissible_multipliers':len(by_coset[coset]),
            'equations':len(eq),'rank':report['rank'],
            'residual_frequencies':sum(bool(c) for c in target.values()),
            'in_span_mod_prime':report['target_in_modular_span']}
        if not report['target_in_modular_span']:
            unsolved.append(coset)
    return {'status':'MODULAR_DIAGNOSTIC_ONLY','degree':degree,
            'cosets_with_nonzero_remainder':len(targets),
            'cosets_passed_mod_prime':histogram.get(True,0),
            'cosets_failed_mod_prime':histogram.get(False,0),
            'failed_coset_indices':unsolved,
            'per_coset':results}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--degree',type=int,choices=[2,3],default=3)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    out=investigate(args.degree)
    if args.output:args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    small={k:v for k,v in out.items() if k!='per_coset'}
    print(json.dumps(small,indent=2,sort_keys=True))


if __name__=='__main__':main()
