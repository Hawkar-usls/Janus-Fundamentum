#!/usr/bin/env python3
"""Experimental rank-three XOR marginal LP on frozen JANUS SCLs.

This script searches for candidate inequalities only; results from the
floating-point LP are NOT a proof. A later exact rational checker is needed.
"""

import argparse
import json
from collections import Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


def planes_from_support(support, min_occupancy):
    present = set(support)
    planes = set()
    for a, b, c in combinations(support, 3):
        if a ^ b == c:
            continue
        plane = tuple(sorted((a, b, c, a ^ b, a ^ c, b ^ c, a ^ b ^ c)))
        if plane in planes:
            continue
        if sum(q in present for q in plane) >= min_occupancy:
            planes.add(plane)
    return sorted(planes)


def constraints(triples, *, min_occupancy=5, include_triangles=True):
    n = len(triples)
    rows = validate(triples, n)
    _, basis = gf2_kernel(rows, n)
    column_freqs = columns_of_kernel(basis, n)
    freq_count = Counter(column_freqs)
    assert 0 not in freq_count
    present = sorted(freq_count)
    planes = planes_from_support(present, min_occupancy)
    triples3 = set()
    if include_triangles:
        for a, b in combinations(present, 2):
            c = a ^ b
            if c in freq_count:
                triples3.add(tuple(sorted((a, b, c))))
    # Every selected 3-space has seven nonzero frequencies and 8 valid
    # characters. The eight affine positivity inequalities are exact.
    freqs = sorted(set(present).union(*(set(p) for p in planes)))
    index = {q: k for k, q in enumerate(freqs)}
    row_i, col_j, values, rhs, labels = [], [], [], [], []

    def add_row(coeff, lower_bound, label):
        number = len(rhs)
        for q, v in coeff.items():
            row_i.append(number)
            col_j.append(index[q])
            values.append(-v)
        rhs.append(-lower_bound)
        labels.append(label)

    for p, q, t in sorted(triples3):
        for signs in ((1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)):
            add_row(dict(zip((p, q, t), signs)), -1, ('tri', p, q, t, signs))
    for plane in planes:
        # independent generators chosen greedily from full F_2^d span
        a, b = plane[0], plane[1]
        c = next(z for z in plane if z not in {a, b, a ^ b})
        for assign in range(8):
            chars = {}
            for mask, frequency in ((1,a),(2,b),(4,c),(3,a^b),
                                    (5,a^c),(6,b^c),(7,a^b^c)):
                chars[frequency] = -1 if (assign & mask).bit_count() & 1 else 1
            add_row(chars, -1, ('plane', *plane, assign))
    ub = coo_matrix((values, (row_i, col_j)), shape=(len(rhs), len(freqs))).tocsr()
    cost = np.array([freq_count.get(q, 0) for q in freqs], dtype=float)
    return {'n': n, 'd': len(basis), 'freqs': freqs, 'cost': cost,
            'ub': ub, 'rhs': np.array(rhs, dtype=float), 'labels': labels,
            'planes': planes, 'triangles': len(triples3),
            'observed_freqs': present}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--instance', choices=['SCL63', 'SAT126', 'UNSAT126'], default='SCL63')
    p.add_argument('--occupancy', type=int, choices=[3, 4, 5, 6, 7], default=5)
    p.add_argument('--fix-uniform-observed', action='store_true')
    p.add_argument('--write-dual', type=Path)
    p.add_argument('--write-primal', type=Path)
    args = p.parse_args()
    src = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    instance = src if args.instance == 'SCL63' else cover(src, FIXTURES[0 if args.instance=='SAT126' else 1][1])
    info = constraints(instance, min_occupancy=args.occupancy)
    bounds = [(-1, 1)] * len(info['freqs'])
    if args.fix_uniform_observed:
        observed = set(info['observed_freqs'])
        bounds = [(-1/3, -1/3) if q in observed else (-1, 1) for q in info['freqs']]
    result = linprog(info['cost'], A_ub=info['ub'], b_ub=info['rhs'],
                     bounds=bounds, method='highs', options={'presolve':True})
    out = {'instance':args.instance,'n':info['n'],'d':info['d'],
           'rank3_min_occupancy':args.occupancy,'selected_planes':len(info['planes']),
           'rank2_triangles':info['triangles'],
           'frequencies':len(info['freqs']),'constraints':len(info['rhs']),
           'LP_status':result.message,'LP_success':bool(result.success),
           'minimum_F_FLOAT_ONLY':float(result.fun) if result.success else None}
    if result.success:
        approximate = Counter(str(Fraction(float(x)).limit_denominator(120))
                              for x in result.x)
        out['approximate_marginal_distinct_values_denominator_le_120'] = len(approximate)
        out['approximate_marginal_most_common_12'] = approximate.most_common(12)
    if result.success and args.write_primal:
        save = {'instance':args.instance, 'occupancy':args.occupancy,
                'observed_uniform':args.fix_uniform_observed,
                'q':info['freqs'],
                's_reconstructed_rational':[
                    str(Fraction(float(x)).limit_denominator(120)) for x in result.x],
                'rounding_denominator_bound':120,
                'solver_objective_FLOAT_ONLY':float(result.fun)}
        args.write_primal.write_text(json.dumps(save, separators=(',', ':'))+'\n')
    if result.success and args.write_dual:
        dual = {'instance':args.instance,'occupancy':args.occupancy,
                'rows':info['labels'],'frequencies':info['freqs'],
                'cost':info['cost'].astype(int).tolist(),
                'dual_ub_marginals':result.ineqlin.marginals.tolist(),
                'dual_lower_marginals':result.lower.marginals.tolist(),
                'dual_upper_marginals':result.upper.marginals.tolist()}
        args.write_dual.write_text(json.dumps(dual))
    print(json.dumps(out, indent=2))


if __name__=='__main__':
    main()
