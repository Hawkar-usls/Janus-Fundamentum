#!/usr/bin/env python3
"""JANUS BABEL-1: an exact address-and-subcube XSAT optimiser.

It never materialises all 2**d Fourier modes. A sparse polynomial-size
bound is checked at each visited node. The number of visited nodes may
nevertheless be exponential: this is NOT a proof of polynomial-time SAT.
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel, walsh_value


FORMAT = 'JANUS_BABEL1_XOR_triple_partition_v1'


def bounded_group(coeff):
    """Return valid lower bound and an explicit disjoint XOR-triple packing."""
    baseline = coeff.get(0, 0) - sum(abs(v) for q, v in coeff.items() if q)
    keys = sorted(q for q, v in coeff.items() if q and v)
    candidates = []
    for i, p in enumerate(keys):
        for q in keys[i + 1:]:
            t = p ^ q
            if t <= q or t not in coeff or not coeff[t]:
                continue
            ap, aq, at = coeff[p], coeff[q], coeff[t]
            # The negative signs of all three Fourier characters cannot
            # coexist when the three coefficient signs have product +1.
            if (ap > 0) ^ (aq > 0) ^ (at > 0):
                gain = 2 * min(abs(ap), abs(aq), abs(at))
                candidates.append((-gain, p, q, t))
    candidates.sort()
    occupied = set()
    selected = []
    gain_total = 0
    for neg_gain, p, q, t in candidates:
        if p in occupied or q in occupied or t in occupied:
            continue
        occupied.update((p, q, t))
        selected.append([p, q, t])
        gain_total -= neg_gain
    return baseline + gain_total, selected


def split(coeff, bit):
    a0, a1 = defaultdict(int), defaultdict(int)
    mask = ~(1 << bit)
    for syndrome, value in coeff.items():
        r = syndrome & mask
        a0[r] += value
        a1[r] += -value if (syndrome >> bit) & 1 else value
    return ({q: value for q, value in a0.items() if value},
            {q: value for q, value in a1.items() if value})


def certified_minimum(triples, *, order=None, initial_selector=0, metadata=None):
    """Find min F(c), and return a checkable complete prefix cover.

    No optimal witness is required: an incumbent improves during DFS.
    Worst-case time and number of leaves remain exponential in nullity.
    """
    n = len(triples)
    rows = validate(triples, n)
    rowspace, kernel = gf2_kernel(rows, n)
    d = len(kernel)
    if order is None:
        order = list(range(d))
    if sorted(order) != list(range(d)):
        raise ValueError('basis_bit_order must be a permutation')
    if not 0 <= initial_selector < (1 << d):
        raise ValueError('initial selector outside kernel coordinates')
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5*n+100))
    columns = columns_of_kernel(kernel, n)
    current_best = walsh_value(columns, initial_selector)
    current_selector = initial_selector
    scored_selectors = 1
    improved = 0
    expanded = 0
    leaves = []

    def recurse(coeff, depth, path, selector):
        nonlocal current_best, current_selector, scored_selectors, improved, expanded
        lower, triples_used = bounded_group(coeff)
        if lower >= current_best:
            leaves.append([path, lower, triples_used])
            return
        if depth == d:
            # Once all selector coordinates are fixed, the remaining score
            # is exactly the coefficient of the zero syndrome.
            assert lower == coeff.get(0, 0)
            if current_best > lower:
                current_best = lower
                current_selector = selector
                improved += 1
            scored_selectors += 1
            leaves.append([path, lower, triples_used])
            return
        expanded += 1
        left, right = split(coeff, order[depth])
        # Look first in the child with the smaller rigorous lower bound.
        # It tends to find an improved witness early, but is not essential.
        branches = [(left, '0', selector),
                    (right, '1', selector | (1 << order[depth]))]
        branches.sort(key=lambda x: (bounded_group(x[0])[0], x[1]))
        for child, direction, child_selector in branches:
            recurse(child, depth + 1, path + direction, child_selector)

    recurse(Counter(columns), 0, '', 0)
    # The root path is always the empty address. The incumbent supplied by
    # initial_selector is only a bound, not the root's actual assignment.
    word = 0
    for k, v in enumerate(kernel):
        if (current_selector >> k) & 1:
            word ^= v
    assert n - 2*word.bit_count() == current_best
    coverage = sum(1 << (d - len(path)) for path, _, _ in leaves)
    assert coverage == (1 << d)
    x = ((1 << n) - 1) ^ word
    exact_one = all((row & x).bit_count() == 1 for row in rows)
    assert exact_one == (n % 3 == 0 and current_best == -n // 3)
    cert = {
        'format': FORMAT, 'n': n,
        'row_triples': [list(row) for row in triples],
        'rank_GF2': len(rowspace), 'nullity_GF2': d,
        'basis_bit_order': list(order),
        'optimum_F': current_best,
        'witness_selector_hex': hex(current_selector),
        'witness_kernel_word_hex': hex(word),
        'initial_selector_hex': hex(initial_selector),
        'proof_leaves': leaves,
        'proof_leaf_count': len(leaves),
        'proof_expanded_nodes': expanded,
        'symbolically_covered_selectors': coverage,
        'individual_score_evaluations_during_search': scored_selectors,
        'incumbent_improvements': improved,
        'exact_one_status': 'SAT' if exact_one else 'UNSAT',
    }
    if exact_one:
        cert['witness_true_variables'] = [i for i in range(n) if (x >> i) & 1]
    if metadata is not None:
        cert['input_metadata'] = metadata
    return cert


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('instance', type=Path, help='JSON with legal SCL rows')
    parser.add_argument('--order', help='comma-delimited 0-based basis bit permutation')
    parser.add_argument('--initial-selector', default='0x0')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    inp = json.loads(args.instance.read_text())
    order = [int(v) for v in args.order.split(',')] if args.order else None
    certificate = certified_minimum(inp['rows'], order=order,
                                    initial_selector=int(args.initial_selector, 0))
    args.output.write_text(json.dumps(certificate, sort_keys=True, indent=1) + '\n')
    print(json.dumps({key: certificate[key] for key in
                      ('n', 'nullity_GF2', 'optimum_F', 'proof_leaf_count',
                       'symbolically_covered_selectors',
                       'individual_score_evaluations_during_search')}, indent=2))


if __name__ == '__main__':
    main()
