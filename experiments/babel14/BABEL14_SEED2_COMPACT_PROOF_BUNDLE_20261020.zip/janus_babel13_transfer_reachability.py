#!/usr/bin/env python3
"""A finite, exact support-only sufficient criterion for 2-lift SOS4 transfer.

When the source has an exact degree-2 Fourier multiplier certificate,
the BABEL-6 transfer corrects each extra-sector remainder using an anchored
split variable. This tool checks the stronger condition that *every* active
degree-3 lift frequency can be corrected, not merely the source certificate's
particular support. Passing proves existence of a rational degree-2 lift
certificate by construction, conditional only on the separately verified
source identity and on the transfer theorem's hypotheses.
"""

import argparse
import json
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import make_lift
from janus_babel6_transfer import (anchor_identities, make_projection,
                                   xor_labels)
from janus_babel7_degree_audit import degree_witnesses


def check(seed):
    source=frozen_instances()['SCL126_flip68']
    lift=make_lift(source,seed)[0]
    source_labels,source_D2,source_dim=xor_labels(source)
    labels,D2,lift_dim=xor_labels(lift)
    result={'seed':seed,'base_dim':source_dim,'lift_dim':lift_dim,
            'multiplier_degree':2,'source_D2_size':len(source_D2),
            'lift_D2_size':len(D2)}
    if lift_dim !=source_dim+1:
        result['status']='TRANSFER_NOT_APPLICABLE_EXTRA_DIMENSION'
        return result
    pi,extra=make_projection(source_labels,labels,source_dim,lift_dim)
    projections={pi(x) for x in D2}
    result['all_source_D2_represented_in_lift_D2']=(source_D2<=projections)
    anchors,info=anchor_identities(source,lift,labels,extra)
    result['anchor_graph']=info
    if not source_D2<=projections:
        result['status']='TRANSFER_NOT_APPLICABLE_SOURCE_REPRESENTATIVES'
        return result
    active=degree_witnesses(labels,3)
    anchor_labels={labels[i] for i in anchors}
    sector_union={q for u in D2 for q in (u^x for x in anchor_labels)}
    # In the group algebra, a signed-graph anchor corrects the paired
    # characters q and q^extra simultaneously.
    reachable={q for q in active if q in sector_union or q^extra in sector_union}
    result.update({'extra_frequency':extra,'lift_D3_size':len(active),
                   'reachable_lift_D3':len(reachable),
                   'unreachable_lift_D3':len(active)-len(reachable),
                   'all_lift_D3_correctable':len(active)==len(reachable)})
    representatives={}
    for u in sorted(D2):
        representatives.setdefault(pi(u),u)
    potential_source_remainder=set()
    for u in source_D2:
        q=representatives[u]
        for r in range(len(source)):
            potential_source_remainder.add(q)
            for i in lift[r]:
                potential_source_remainder.add(q^labels[i])
    missing_potential=potential_source_remainder-reachable
    result.update({'possible_remainder_frequencies_from_arbitrary_source_terms':len(potential_source_remainder),
                   'possible_remainder_frequencies_outside_anchor_reachability':len(missing_potential),
                   'first_unreachable_possible_remainder':min(missing_potential) if missing_potential else None})
    if len(active)==len(reachable) and anchors:
        result['status']='EXACT_SUPPORT_ONLY_SUFFICIENT_CONDITION_PASS'
    else:
        result['status']='SUPPORT_ONLY_SUFFICIENT_CONDITION_FAIL'
        result['first_unreachable']=next((q for q in sorted(active) if q not in reachable),None)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=check(args.seed)
    if args.output:
        args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps(result,sort_keys=True),flush=True)
