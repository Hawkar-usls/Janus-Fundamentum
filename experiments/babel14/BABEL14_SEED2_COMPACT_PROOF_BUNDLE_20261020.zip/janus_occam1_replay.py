#!/usr/bin/env python3
"""Clean compact Gate OCCAM-1 Walsh statistics on frozen JANUS controls."""

import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam_walsh import analyse_kernel


def main():
    source = source_triples(Path(__file__).with_name("tutte12.am.csv"))
    report = {}
    expected_b2 = (23, 23, 15)
    for (name, mask, expected_sat, expected_rank), b2 in zip(FIXTURES, expected_b2):
        triples = cover(source, mask)
        rows = validate(triples, 126)
        independent_rows, kernel = gf2_kernel(rows, 126)
        assert len(independent_rows) == expected_rank
        result = analyse_kernel(kernel, 126)
        assert (result["SAT_count_exact"], result["B1_rowspace"],
                result["B2_rowspace"]) == (expected_sat, 0, b2)
        optimum_v = int(result["optimal_kernel_word_hex"], 16)
        optimum_x = ((1 << 126) - 1) ^ optimum_v
        bad_rows = [i for i, row in enumerate(rows) if (row & optimum_x).bit_count() == 3]
        assert all((row & optimum_x).bit_count() in (1, 3) for row in rows)
        assert len(bad_rows) == 126 - (3 * optimum_v.bit_count()) // 2
        assert result["maximum_kernel_weight"] <= 84
        assert sum(int(key) * num for key, num in result["weight_histogram"].items()) == (
            1 << len(kernel)) * 63
        report[name] = {
            "rank": expected_rank,
            "nullity": len(kernel),
            "SAT_count_exact": result["SAT_count_exact"],
            "B1": result["B1_rowspace"],
            "B2": result["B2_rowspace"],
            "unique_column_syndromes": result["unique_column_syndromes"],
            "Walsh_hit_target": result["target_walsh_score"],
            "nearest_weight_gap": result["nearest_weight_gap"],
            "max_kernel_weight": result["maximum_kernel_weight"],
            "min_parity_relaxation_violations": len(bad_rows),
            "bad_row_indices_for_witness": bad_rows,
            "optimal_kernel_word_hex": result["optimal_kernel_word_hex"],
            "Walsh_second_moment": result["second_walsh_moment"],
            "modes": result["enumerated_fourier_modes"],
        }
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
