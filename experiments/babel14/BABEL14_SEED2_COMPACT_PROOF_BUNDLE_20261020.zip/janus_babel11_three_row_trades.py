#!/usr/bin/env python3
"""Search first genuinely new Fourier-line geometry via 3-row cubic trades.

A two-row rank-preserving trade never changes the *multiset of character
lines*; three-row trades are the first candidates that might do so.
"""

import argparse
import json
import random
from collections import defaultdict
from itertools import combinations
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import connected_incidence
from janus_babel6_transfer import xor_labels
from janus_occam_solver import gf2_kernel, kernel_search, validate


def line_pattern(row, labels):
    return tuple(sorted(labels[i] for i in row))


def proposals(rows, labels, iterations=30000, seed=0, limit=20,
              exhaustive=False):
    rng = random.Random(seed)
    n = len(rows)
    tested = set()
    counters = defaultdict(int)
    witnesses = []
    _, source_kernel = gf2_kernel(validate(rows,n),n)
    target_d = len(source_kernel)
    samples = (combinations(range(n),3) if exhaustive else
               (tuple(sorted(rng.sample(range(n),3)))
                for _ in range(iterations)))
    for selected in samples:
        if selected in tested:
            continue
        tested.add(selected)
        old_rows = [tuple(rows[i]) for i in selected]
        support = set().union(*(set(t) for t in old_rows))
        if len(support) != 9:
            continue
        counters['disjoint_triples'] += 1
        support = tuple(sorted(support))
        old_pattern = sorted(line_pattern(t,labels) for t in old_rows)
        possible = [tuple(t) for t in combinations(support,3)
                    if labels[t[0]]^labels[t[1]]^labels[t[2]]==0]
        if len(possible)<=3:
            continue
        counters['available_alt_triples'] += 1
        for new_first in possible:
            remainder = set(support)-set(new_first)
            if len(remainder)!=6:
                continue
            for new_second in possible:
                if len(set(new_second)&remainder)!=3:
                    continue
                new_third = tuple(sorted(remainder-set(new_second)))
                if labels[new_third[0]]^labels[new_third[1]]^labels[new_third[2]]:
                    continue
                new_rows = sorted((new_first,new_second,new_third))
                if sorted(line_pattern(t,labels) for t in new_rows)==old_pattern:
                    continue
                counters['different_character_lines']+=1
                candidate=list(rows)
                for index, new in zip(selected,new_rows):candidate[index]=new
                try:
                    bits=validate(candidate,n)
                except ValueError:continue
                counters['legal'] += 1
                if len(gf2_kernel(bits,n)[1])!=target_d:
                    continue
                counters['same_kernel']+=1
                if not connected_incidence(candidate):continue
                sat,_,states=kernel_search(source_kernel,2*n//3,True)
                assert sat==0 and states==(1<<target_d)
                witness={'original_row_indices':selected,
                         'old_rows':old_rows,'new_rows':new_rows,
                         'all_rows':candidate,'nullity':target_d,
                         'same_kernel':True,'exact_UNSAT':True}
                witnesses.append(witness)
                if len(witnesses)>=limit:
                    return dict(counters),witnesses
    return dict(counters),witnesses


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--flip',type=int,default=94)
    p.add_argument('--iterations',type=int,default=30000)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--limit',type=int,default=20)
    p.add_argument('--exhaustive',action='store_true')
    p.add_argument('--output',type=Path,
                   default=Path('babel11_THREE_ROW_TRADES.json'))
    args=p.parse_args()
    rows=frozen_instances()[f'SCL126_flip{args.flip}']
    labels,_,d=xor_labels(rows)
    counts,witnesses=proposals(rows,labels,args.iterations,args.seed,
                               args.limit,args.exhaustive)
    result={'source_bit':args.flip,'search_seed':args.seed,
            'iterations':args.iterations,'counts':counts,
            'exhaustive':args.exhaustive,
            'row_triples_total':len(rows)*(len(rows)-1)*(len(rows)-2)//6,
            'found':len(witnesses),'witnesses':witnesses}
    args.output.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='witnesses'},
                     sort_keys=True),flush=True)


if __name__=='__main__':main()
