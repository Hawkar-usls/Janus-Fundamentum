#!/usr/bin/env python3
"""BABEL-14: exact degree-two anti-deck correction tests, seed 2.

All generators are legitimate degree-two Fourier-multiplier differences.
Integer rank modulo a prime is a rigorous rational *lower bound* on rank.
Never mistake the rank of an anti-sector subspace for that of the full M2.
"""

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import make_lift
from janus_babel6_transfer import xor_labels, make_projection, signed_graph
from janus_babel7_degree_audit import degree_witnesses


def prepare(seed=2):
    source = frozen_instances()['SCL126_flip68']
    lift = make_lift(source, seed)[0]
    base_labels, _, d = xor_labels(source)
    labels, Q, D = xor_labels(lift)
    pi, e = make_projection(base_labels, labels, d, D)
    assert D == d+1
    bit = e & -e

    def canonical(q):
        return (q ^ e, -1) if q & bit else (q, 1)

    _, _, split_rows = signed_graph(source, lift, labels, e)
    touched = set()
    for a, b, _sa, _sb in split_rows.values():
        for u in Q:
            touched.add(canonical(u ^ labels[a])[0])
            touched.add(canonical(u ^ labels[b])[0])
    all_active = degree_witnesses(labels, 3)
    canonical_active = {canonical(q)[0] for q in all_active}
    missing = sorted(canonical_active-touched)
    return source, lift, labels, Q, e, canonical, touched, canonical_active, missing


def extra_generators(source, lift, labels, Q, e, canonical, missing):
    index = {q: j for j, q in enumerate(missing)}
    signatures = {}
    supports = Counter()
    singleton_witnesses = {}
    processed = 0
    for u in sorted(Q):
        if u ^ e not in Q or u > u ^ e:
            continue
        for r, row in enumerate(lift[:len(source)]):
            processed += 1
            coord = defaultdict(int)
            for q in (u, *(u ^ labels[x] for x in row)):
                c, orient = canonical(q)
                j = index.get(c)
                if j is not None:
                    coord[j] += orient
            sig = tuple(sorted((j, x) for j, x in coord.items() if x))
            if not sig:
                continue
            supports[len(sig)] += 1
            signatures.setdefault(sig, (r, u))
            if len(sig) == 1:
                singleton_witnesses.setdefault(sig[0][0], (r, u, sig[0][1]))
    return signatures, supports, singleton_witnesses, processed


def modular_rank(signatures, n, p=65521):
    # First run simple supports, then larger supports. Sparse elimination
    # requires only len(vector)<=4 initial nonzeros, and selected pivots.
    pivots = {}
    witnesses = {}
    count = 0
    for sig, representative in sorted(signatures.items(), key=lambda t: len(t[0])):
        count += 1
        v = {j: c % p for j, c in sig}
        while v:
            lead = min(v)
            if lead not in pivots:
                inv = pow(v[lead], -1, p)
                pivots[lead] = {j: (z*inv) % p for j, z in v.items()}
                witnesses[lead] = (representative[0], representative[1], sig)
                break
            factor = v[lead]
            for j, z in pivots[lead].items():
                new = (v.get(j, 0)-factor*z) % p
                if new:
                    v[j] = new
                else:
                    v.pop(j, None)
        if len(pivots) == n:
            break
    return len(pivots), count, witnesses


def audit(seed=2):
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(seed)
    print(f'Preparing {len(missing)} missing nodes and {len(touched)} full-rank graph nodes', flush=True)
    signatures, supports, singles, count = extra_generators(source, lift, labels, Q, e, canonical, missing)
    print(f'Scanned {count} paired-character generators; distinct signatures {len(signatures)}; singleton coverage {len(singles)}', flush=True)
    rank, processed, pivots = modular_rank(signatures, len(missing))
    result = {'seed': seed, 'extra_character': e,
              'canonical_D3_active': len(active), 'prior_row_difference_graph_touched': len(touched),
              'prior_row_difference_graph_missing': len(missing),
              'degree2_eligible_paired_multiplier_generators': count,
              'projected_nonzero_signatures': len(signatures),
              'support_sizes': dict(sorted(supports.items())),
              'singleton_frequency_coverage': len(singles),
              'modulus': 65521, 'augmented_projected_rank_lower_bound_over_Q': rank,
              'modular_elimination_columns_scanned': processed,
              'augmented_projected_full_row_rank': rank == len(missing),
              'status': 'MODULAR_INTEGER_MINOR_WITNESS' if rank == len(missing) else 'INCOMPLETE_SECTOR_SUBSPACE'}
    return result, pivots, missing


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=2)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result, pivots, missing = audit(args.seed)
    if args.output:
        args.output.write_text(json.dumps({'result': result, 'missing': missing,
                                           'rank_pivot_generators': pivots}, sort_keys=True, indent=2)+'\n')
    print(json.dumps(result, sort_keys=True, indent=2), flush=True)
