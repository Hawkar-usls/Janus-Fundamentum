#!/usr/bin/env python3
"""BABEL-7: exact rational negative-sector identity on seven source rows.

Finite-field linear algebra is ONLY the discovery device. The final identity
is reconstructed over Q and verified in the unrestricted Boolean group ring
using exact integer arithmetic, without trusting modular arithmetic.
"""

import argparse
import json
from collections import defaultdict, Counter
from fractions import Fraction
from pathlib import Path

from janus_babel7_local_probe import DEFAULT_ROWS,local_equations
from janus_babel6_transfer import xor_labels,make_projection
from janus_occam_replay import FIXTURES, cover, source_triples


PRIME=1000000007


def sub_mul(left, right, scalar, p=PRIME):
    """In-place sparse vector -= scalar*right (mod p)."""
    for col,val in right.items():
        new=(left.get(col,0)-scalar*val)%p
        if new:left[col]=new
        elif col in left:del left[col]


def add_mul(left, right, scalar, p=PRIME):
    for col,val in right.items():
        new=(left.get(col,0)+scalar*val)%p
        if new:left[col]=new
        elif col in left:del left[col]


def modular_certificate(supports, target, p=PRIME):
    pivot={}
    for index,support in enumerate(supports):
        vec={q:1 for q in support}
        combo={index:1}
        while vec:
            at=min(vec)
            if at not in pivot:
                inv=pow(vec[at],-1,p)
                pivot[at]=({q:v*inv%p for q,v in vec.items()},
                           {q:v*inv%p for q,v in combo.items()})
                break
            factor=vec[at]
            row,source=pivot[at]
            sub_mul(vec,row,factor,p)
            sub_mul(combo,source,factor,p)
    solution={}
    remainder={q:v%p for q,v in target.items() if v%p}
    while remainder:
        at=min(remainder)
        if at not in pivot:
            raise ValueError('target is not in modular span')
        factor=remainder[at]
        row,source=pivot[at]
        sub_mul(remainder,row,factor,p)
        add_mul(solution,source,factor,p)
    return solution,len(pivot)


def rational_reconstruct(value, modulus, max_numerator=100000,
                         max_denominator=512):
    if value == 0:
        return Fraction(0)
    candidates=[]
    for den in range(1,max_denominator+1):
        num=(value*den)%modulus
        if num>modulus//2:num-=modulus
        if abs(num)<=max_numerator:
            candidates.append(Fraction(num,den))
    if not candidates:
        raise ValueError(f'could not reconstruct modular residue {value}')
    return min(candidates,key=lambda x:(abs(x.numerator)+x.denominator,
                                        x.denominator))


def verify_sector(cover_rows, labels, dual, denominator, extra):
    assert denominator>0
    result=defaultdict(int)
    Q=xor_labels(cover_rows)[1]
    for (r,u),val in dual.items():
        if not val:continue
        assert 0<=r<len(cover_rows) and u in Q
        result[u]+=val
        for col in cover_rows[r]:
            result[u^labels[col]]+=val
    actual={q:c for q,c in result.items() if c}
    assert actual=={0:denominator, extra:-denominator},actual
    return len(actual)


def construct(flip=16,rows=DEFAULT_ROWS):
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    cov=cover(source,format(int(FIXTURES[1][1],16)^(1<<flip),'x'))
    base_labels,_,base_dim=xor_labels(source)
    labels,Q,dim=xor_labels(cov)
    assert dim==base_dim+1
    _,e=make_projection(base_labels,labels,base_dim,dim)
    space,supports,origins,qcount=local_equations(rows,source,cov,labels,Q)
    sol,rank=modular_certificate(supports,{0:1,e:-1})
    recovered={i:rational_reconstruct(y,PRIME) for i,y in sol.items() if y}
    # Reconstruct genuine RATIONAL coefficients, not modular coefficients.
    terms=defaultdict(Fraction)
    for i,coeff in recovered.items():
        terms[origins[supports[i]]]+=coeff
    denominator=1
    from math import lcm
    for val in terms.values():denominator=lcm(denominator,val.denominator)
    integers={key:int(c*denominator) for key,c in terms.items() if c}
    verify_sector(cov,labels,integers,denominator,e)
    result={'format':'BABEL7_BALANCED_UNSAT_LOCAL_SECTOR_INTEGER_DUAL_V1',
      'source_mask_hex':format(int(FIXTURES[1][1],16)^(1<<flip),'x'),
      'flipped_base_edge_index':flip,
      'source_rows_used':rows,'extra_character':e,
      'local_fourier_domain':len(space),'local_modular_rank':rank,
      'equations_examined':len(supports),
      'normalization_D':denominator,
      'terms':[[r,u,c] for (r,u),c in sorted(integers.items())]}
    summary={'status':'EXACT_RATIONAL_SECTOR_MINUS_CERTIFICATE_PASS',
             'source_rows':rows,'fourier_domain':len(space),
             'modular_rank':rank,'integer_terms':len(integers),
             'normalization_D':denominator,
             'max_integer_multiplier_bits':max(abs(c).bit_length()
                                             for c in integers.values()),
             'coefficients_verified':len(space)}
    return result,summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--flip',type=int,default=16)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    record,summary=construct(args.flip)
    if args.output:args.output.write_text(json.dumps(record,sort_keys=True,
                                      separators=(',',':'))+'\n')
    print(json.dumps(summary,indent=2,sort_keys=True))


if __name__=='__main__':main()
