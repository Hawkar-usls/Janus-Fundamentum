#!/usr/bin/env python3
"""Exact rank-4 separator search against BABEL-3's rational pseudomodel.

Generate 4-spaces by extending every dense five-observed 3-space by a sixth
observed frequency. This is a finite *selected* family, not the full
exponentially larger family of rank-four subspaces.
"""

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

from janus_occam_replay import FIXTURES,cover,source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_occam2_prove import columns_of_kernel
from janus_babel3_exact_pseudomodel import all_root_planes


def moment_three(q,observed,positive):
    return -1 if q in observed else 1 if q in positive else 0


def basis_patterns(points):
    span={0:0}
    bases=[]
    for q in points:
        if q in span:
            continue
        k=len(bases)
        bases.append(q)
        span.update({p^q: mask|(1<<k) for p,mask in list(span.items())})
    return bases,span


def selected_rank4_planes(observed):
    """Return a deterministic list of rank-4 planes and dense rank3 origins."""
    all_planes=all_root_planes(observed)
    dense=[p for p in all_planes if sum(q in observed for q in p)==5]
    points=sorted(observed)
    result=set()
    for rank3 in dense:
        current={0}|set(rank3)
        for q in points:
            if q in current:
                continue
            rank4=tuple(sorted(current|{q^v for v in current}))
            assert len(rank4)==16
            result.add(rank4)
    return sorted(result),dense


def scan(triples,*,maximum_stored_examples=5):
    rows=validate(triples,len(triples))
    n=len(rows)
    _,kernel=gf2_kernel(rows,n)
    observed=set(columns_of_kernel(kernel,n))
    assert 0 not in observed
    planes,dense=selected_rank4_planes(observed)
    positive={q for p in dense for q in p if q not in observed}
    occupied_hist=Counter()
    violated=0
    all_violations=0
    min_numerator=None
    examples=[]
    for plane in planes:
        space=plane[1:]
        occupied_hist[sum(q in observed for q in space)]+=1
        bases,span=basis_patterns(space)
        assert len(bases)==4 and len(span)==16
        scaled={q:moment_three(q,observed,positive) for q in space}
        worst=None
        worst_z=None
        for z in range(16):
            numerator=3+sum(weight*(-1 if (span[q]&z).bit_count()&1 else 1)
                            for q,weight in scaled.items())
            if worst is None or numerator<worst:
                worst,worst_z=numerator,z
            min_numerator=numerator if min_numerator is None else min(min_numerator,numerator)
            all_violations+=int(numerator<0)
        if worst<0:
            violated+=1
            if len(examples)<maximum_stored_examples:
                examples.append({'plane_nonzero_frequencies':list(space),
                                 'generator_basis':bases,
                                 'state':worst_z,
                                 'numerator_48_times_probability':worst,
                                 'cut_rational_violation':f'{-worst}/3',
                                 'observed_frequency_count':sum(q in observed for q in space)})
    return {'n':n,'nullity':len(kernel), 'observed_syndrome_types':len(observed),
            'positive_auxiliary_syndrome_types':len(positive),
            'dense_rank3_origins':len(dense),
            'selected_rank4_planes':len(planes),
            'rank4_nonnegativity_constraints_checked':16*len(planes),
            'violated_rank4_planes':violated,
            'violated_rank4_inequalities':all_violations,
            'most_negative_48_times_probability':min_numerator,
            'rank4_observed_occupancy':dict(sorted(occupied_hist.items())),
            'examples':examples,
            'scope':'only rank4 planes spanned by dense5 rank3 plane plus observed frequency'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--instance',choices=['SCL63','SAT126','UNSAT126'],default='SCL63')
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    rows=source if args.instance=='SCL63' else cover(source,FIXTURES[0 if args.instance=='SAT126' else 1][1])
    result={'instance':args.instance,**scan(rows)}
    if args.output:
        args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__=='__main__':
    main()
