#!/usr/bin/env python3
"""BABEL-11 rational theorem, code-restriction and exact-SOS regression gates.

Run `BABEL11_DEEP=1 python3 -m unittest -v test_janus_babel11` to recompute
the 32k-frequency equitable quotients and independent dense modular ranks.
"""

import json
import os
import unittest
from pathlib import Path

from janus_babel11_cyclic_orbit import quotient_membership
from janus_babel11_cyclic_scout import cyclic
from janus_babel11_cyclic_solver import decide,regression
from janus_babel11_degree4_rank_proof import prove
from janus_babel11_independent_det import audit as independent_det
from janus_babel11_mutation_exact_lower import verify
from janus_babel11_mutation_transfer_upper import transfer


ROOT=Path(__file__).resolve().parent
BITS=(16,59,68,81,94,132,168,169)


class TestBabel11(unittest.TestCase):
    def test_cyclic_polynomial_decision_and_83304_exact_controls(self):
        data=regression(ROOT/'babel11_CYCLIC_ALL_NONZERO126_SCOUT.json')
        self.assertEqual(data['total_connected_linear_cyclic_cases'],83304)
        self.assertEqual(data['SAT'],20148)
        self.assertEqual(data['UNSAT'],63156)
        self.assertEqual(decide(126,1,8)['status'],'SAT')
        self.assertEqual(decide(105,1,12)['status'],'UNSAT')
        self.assertEqual(decide(42,6,12)['status'],'UNSAT')
        for n,a,b in ((63,1,6),(105,1,12)):
            rows=cyclic(n,a,b)
            proof=quotient_membership(rows,1,True)
            self.assertTrue(proof['member'])
            self.assertEqual(proof['exact_full_frequency_replay'],'PASS')

    def test_all_eight_symbolic_rational_SOS4_receipts(self):
        for bit in BITS:
            proof=json.loads((ROOT/f'babel11_BIT{bit}_SOS4_EXACT_QUOTIENT_DET.json').read_text())
            self.assertEqual(proof['status'],'EXACT_RATIONAL_SOS4_EXISTENCE_PASS')
            self.assertTrue(proof['integer_determinant_nonzero_proven'])
            self.assertTrue(proof['exact_rational_SOS4_certificate_exists'])
            self.assertEqual(proof['full_rank_prime_witness']['prime'],100003)
            m=proof['rational_invariant_quotient_dimension']
            self.assertEqual(proof['full_rank_prime_witness']['degree'],m)
            self.assertEqual(proof['equitable_cells'],m+1)
            self.assertEqual(proof['determinant_mod_prime'],
                             (-1 if m%2 else 1)*proof[
                                 'full_rank_prime_witness']['constant']%100003)
        for bit in (94,168,169):
            independent=json.loads((ROOT/f'babel11_BIT{bit}_INDEPENDENT_DET.json').read_text())
            full=json.loads((ROOT/f'babel11_BIT{bit}_SOS4_EXACT_QUOTIENT_DET.json').read_text())
            self.assertEqual(independent['exact_GF_p_rank'],1419)
            self.assertEqual(independent['exact_GF_p_determinant_mod_p'],
                             full['determinant_mod_prime'])

    def test_twelve_noncover_exact_degree4_and_rigidity(self):
        summary=json.loads((ROOT/'babel11_NONCOVER_SCL63_EXACT_MIN_DEGREES.json').read_text())
        self.assertEqual(summary['minimum_SOS_degree_4_verified'],12)
        self.assertEqual(len(set(v['SHA256_rows'] for v in summary['cases'])),12)
        for case in summary['cases']:
            source=ROOT/f'babel11_MUTATION_SEED{case["seed"]}_LOWER_SOS2.json'
            proof=json.loads(source.read_text())
            result=verify(proof)
            self.assertEqual(result['status'],'EXACT_INTEGER_SOS2_OBSTRUCTION_PASS')
        for seed in (0,2,5):
            u=transfer(seed,1)
            self.assertEqual(u['independent_frequency_replay'],'PASS')
        for bit in (16,68,94):
            data=json.loads((ROOT/f'babel11_THREE_ROW_EXHAUSTIVE_BIT{bit}.json').read_text())
            self.assertTrue(data['exhaustive'])
            self.assertEqual(data['row_triples_total'],325500)
            self.assertEqual(data['found'],0)

    @unittest.skipUnless(os.environ.get('BABEL11_DEEP')=='1',
                         'set BABEL11_DEEP=1 for expensive clean-room replay')
    def test_deep_all_eight_quotients_and_three_independent_determinants(self):
        for bit in BITS:
            new=prove(bit)
            old=json.loads((ROOT/f'babel11_BIT{bit}_SOS4_EXACT_QUOTIENT_DET.json').read_text())
            self.assertEqual(new['determinant_mod_prime'],old['determinant_mod_prime'])
            self.assertEqual(new['equitable_partition_cell_history'],
                             old['equitable_partition_cell_history'])
        for bit in (94,168,169):
            new=independent_det(bit)
            old=json.loads((ROOT/f'babel11_BIT{bit}_INDEPENDENT_DET.json').read_text())
            self.assertEqual(new['exact_GF_p_determinant_mod_p'],
                             old['exact_GF_p_determinant_mod_p'])


if __name__=='__main__':unittest.main()
