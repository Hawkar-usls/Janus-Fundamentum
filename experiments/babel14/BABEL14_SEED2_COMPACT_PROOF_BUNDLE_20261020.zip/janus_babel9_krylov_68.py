#!/usr/bin/env python3
"""BABEL-9: exact CRT discovery of a degree-4 SOS for balanced flip 68.

Uses a cached sparse integer normal operator and reconstructs its monic
Lanczos annihilator. A modular answer alone is NOT a proof; the independent
integer recurrence verifier must be run on the resulting certificate.
"""

import argparse
import json
import time
from pathlib import Path

import numpy as np

from janus_babel8_krylov_exact import matrices, nextprime


def lanczos_for_normal(c_normal, prime, max_powers=700):
    old = np.zeros(c_normal.shape[0], dtype=np.int64)
    current = old.copy()
    current[0] = 1
    oldnorm = 0
    previous_polynomial = [0]
    polynomial = [1]
    for step in range(max_powers):
        qnorm = int(np.dot(current, current)) % prime
        if not qnorm:
            raise ArithmeticError(f'isotropic Lanczos norm at step {step}')
        evaluated = c_normal.dot(current) % prime
        alpha = int(np.dot(current, evaluated)) % prime
        alpha = alpha * pow(qnorm, -1, prime) % prime
        beta = qnorm * pow(oldnorm, -1, prime) % prime if step else 0
        following = (evaluated - alpha * current - beta * old) % prime
        next_polynomial = [0] * (len(polynomial) + 1)
        for j, coeff in enumerate(polynomial):
            next_polynomial[j] = (next_polynomial[j] - alpha * coeff) % prime
            next_polynomial[j + 1] = (next_polynomial[j + 1] + coeff) % prime
        for j, coeff in enumerate(previous_polynomial):
            next_polynomial[j] = (next_polynomial[j] - beta * coeff) % prime
        previous_polynomial, polynomial = polynomial, next_polynomial
        if not np.any(following):
            return polynomial
        old, current = current, following
        oldnorm = qnorm
    raise ArithmeticError(f'Lanczos exceeded {max_powers} steps')


def discover(bit, output, checkpoint=None, max_primes=300, initial_prime=10000019):
    start = time.monotonic()
    eq, matrix, transpose, q_count, bound = matrices(bit)
    normal = (matrix @ transpose).tocsr()
    assert normal.shape == (32768, 32768)
    assert int(np.max(np.asarray(normal.sum(axis=1)))) == bound
    degree = None
    crt = []
    modulus = 1
    prime = initial_prime
    accepted = []
    exceptions = []
    limit = None
    for trial in range(max_primes):
        prime = nextprime(prime)
        try:
            coefficients = lanczos_for_normal(normal, prime)
        except ArithmeticError as err:
            exceptions.append([prime, str(err)])
            continue
        trial_degree = len(coefficients) - 1
        if degree is None:
            degree = trial_degree
            crt = [0] * len(coefficients)
            limit = 2 * pow(bound + 1, degree)
        elif degree != trial_degree:
            exceptions.append([prime, f'non-generic degree {trial_degree}'])
            continue
        inverse = pow(modulus % prime, -1, prime)
        for index, coeff in enumerate(coefficients):
            adjust = ((coeff - crt[index]) % prime) * inverse % prime
            crt[index] += adjust * modulus
        modulus *= prime
        accepted.append(prime)
        if len(accepted) % 10 == 0:
            progress = {'case': bit, 'prime_count': len(accepted),
                        'degree': degree, 'modulus_bits': modulus.bit_length(),
                        'required_bits': limit.bit_length(),
                        'elapsed_seconds': round(time.monotonic() - start, 1)}
            print(json.dumps(progress), flush=True)
            if checkpoint:
                checkpoint.write_text(json.dumps(progress, indent=2) + '\n')
        if modulus > limit:
            break
    rigorous = modulus > limit
    if not rigorous:
        raise RuntimeError('insufficient primes for the deterministic bound: '
                           f'{len(accepted)} accepted, '
                           f'{modulus.bit_length()}/{limit.bit_length()} bits')
    polynomial = [int(v if v <= modulus // 2 else v - modulus) for v in crt]
    assert polynomial[-1] == 1 and polynomial[0] != 0
    document = {
        'format': 'BABEL8_INTEGER_KRYLOV_DEGREE4_CERTIFICATE_V1',
        'flipped_base_edge_index': bit,
        'degree_of_recurrence': degree,
        'normal_operator_row_sum_bound': bound,
        'theoretical_CRT_coefficient_bound_expression':
        f'({bound}+1)^{degree}',
        'CRT_modulus_exceeds_twice_coefficient_bound': True,
        'CRT_modulus_digits': len(str(modulus)),
        'prime_count': len(accepted),
        'modular_exceptions': len(exceptions),
        'number_of_distinct_row_products': len(eq),
        'degree2_fourier_basis_size': q_count,
        'polynomial_coefficients_low_to_high': polynomial,
    }
    output.write_text(json.dumps(document, sort_keys=True,
                                 separators=(',', ':')) + '\n')
    return {'status': 'RIGOROUSLY_RECONSTRUCTED_CRT_REQUIRES_EXACT_REPLAY',
            'proof_path': str(output), 'degree': degree,
            'accepted_primes': len(accepted),
            'elapsed_seconds': round(time.monotonic() - start, 1),
            'exception_count': len(exceptions)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bit', type=int, default=68)
    parser.add_argument('--max-primes', type=int, default=300)
    parser.add_argument('--output', type=Path,
                        default=Path('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json'))
    parser.add_argument('--checkpoint', type=Path,
                        default=Path('babel9_BIT68_CRT_PROGRESS.json'))
    args = parser.parse_args()
    print(json.dumps(discover(args.bit, args.output, args.checkpoint,
                              args.max_primes), indent=2), flush=True)


if __name__ == '__main__':
    main()
