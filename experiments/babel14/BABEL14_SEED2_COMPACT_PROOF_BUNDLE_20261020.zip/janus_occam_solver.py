#!/usr/bin/env python3
"""JANUS/OCCAM: tiny *exact*, not polynomial-time, Linear Cubic XSAT solver.

Input JSON: {"rows": [[0, 1, 2], ...]}, optionally with "n".
Every row and column must have degree three, and pairs of rows may
intersect in at most one column. No third-party packages are needed.
"""

import argparse
import json
import sys
from functools import lru_cache
from pathlib import Path


def validate(triples, n):
    if n != len(triples) or n < 1:
        raise ValueError("expected a square SCL: exactly n triples")
    degrees = [0] * n
    used_pairs = set()
    rows = []
    for i, triple in enumerate(triples):
        if len(triple) != 3 or any(type(j) is not int or j < 0 or j >= n for j in triple):
            raise ValueError(f"row {i}: need three valid distinct indices")
        if len(set(triple)) != 3:
            raise ValueError(f"row {i}: repeated variable")
        row = 0
        for j in triple:
            degrees[j] += 1
            row |= 1 << j
        for a, b in ((0, 1), (0, 2), (1, 2)):
            pair = tuple(sorted((triple[a], triple[b])))
            if pair in used_pairs:
                raise ValueError("nonlinear SCL: two rows share two variables")
            used_pairs.add(pair)
        rows.append(row)
    if any(degree != 3 for degree in degrees):
        raise ValueError("every column must occur in exactly three rows")
    return rows


def gf2_kernel(rows, n):
    """Independent row echelon basis and a free-variable kernel basis."""
    ledgers = {}
    for row in rows:
        w = row
        while w:
            p = w.bit_length() - 1
            if p in ledgers:
                w ^= ledgers[p]
            else:
                ledgers[p] = w
                break
    pivots = sorted(ledgers)
    null_basis = []
    for free in range(n):
        if free in ledgers:
            continue
        vector = 1 << free
        for p in pivots:
            if (vector & ledgers[p]).bit_count() % 2:
                vector ^= 1 << p
        null_basis.append(vector)
    assert len(pivots) + len(null_basis) == n
    assert all((row & v).bit_count() % 2 == 0
               for row in rows for v in null_basis)
    return [ledgers[p] for p in pivots], null_basis


def kernel_search(null_basis, target, count_all=False):
    """Gray-code enumeration of exactly 2**d distinct kernel words."""
    word = 0
    total = 0
    witness = None
    checked = 0
    for index in range(1 << len(null_basis)):
        if index:
            flip = (index & -index).bit_length() - 1
            word ^= null_basis[flip]
        checked += 1
        if word.bit_count() == target:
            total += 1
            if witness is None:
                witness = word
            if not count_all:
                break
    return total if count_all else int(witness is not None), witness, checked


def syndrome_search(row_basis, n, target, count_all=False):
    """Exact weight/syndrome DP: up to O(n*target*2**rank) states."""
    columns = [sum(((row >> j) & 1) << k
                   for k, row in enumerate(row_basis)) for j in range(n)]
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5 * n + 100))

    @lru_cache(maxsize=None)
    def ways(i, syndrome, left):
        if left < 0 or left > n - i:
            return 0
        if i == n:
            return int(syndrome == 0 and left == 0)
        skip = ways(i + 1, syndrome, left)
        if skip and not count_all:
            return 1
        take = ways(i + 1, syndrome ^ columns[i], left - 1)
        return skip + take if count_all else int(bool(take))

    count = ways(0, 0, target)
    witness = None
    if count:
        witness = 0
        syndrome, left = 0, target
        for i in range(n):
            if ways(i + 1, syndrome, left):
                continue
            assert ways(i + 1, syndrome ^ columns[i], left - 1)
            witness |= 1 << i
            syndrome ^= columns[i]
            left -= 1
        assert syndrome == left == 0
    return count, witness, ways.cache_info().misses


def solve(triples, n=None, count_all=False):
    if n is None:
        n = len(triples)
    rows = validate(triples, n)
    if n % 3:
        return {"status": "UNSAT", "method": "divisibility", "n": n,
                "proof": "3*number_of_true_variables = n is impossible"}
    row_basis, null_basis = gf2_kernel(rows, n)
    rank, d = len(row_basis), len(null_basis)
    target = 2 * n // 3
    if d <= rank:
        method = "GF2-kernel-Gray"
        sat_count, v, visited = kernel_search(null_basis, target, count_all)
    else:
        method = "GF2-dual-syndrome-DP"
        sat_count, v, visited = syndrome_search(row_basis, n, target, count_all)
    result = {"status": "SAT" if v is not None else "UNSAT", "n": n,
              "rank": rank, "nullity": d, "target_kernel_weight": target,
              "method": method, "states_visited": visited,
              "exact_count": sat_count if count_all else None}
    if v is not None:
        x = ((1 << n) - 1) ^ v
        assert x.bit_count() == n // 3
        assert all((row & x).bit_count() == 1 for row in rows)
        result["witness_true_variables"] = [j for j in range(n) if (x >> j) & 1]
        result["witness_all_rows_checked"] = True
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="JSON object with n and rows")
    parser.add_argument("--count", action="store_true", help="count all assignments exactly")
    args = parser.parse_args()
    instance = json.loads(args.input.read_text())
    print(json.dumps(solve(instance["rows"], instance.get("n"), args.count),
                     sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
