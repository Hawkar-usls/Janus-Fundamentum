#!/usr/bin/env python3
"""BABEL-11: enumerate connected *linear* cyclic cubic SCL and their GF(2) nullities.

For rows {i,i+a,i+b} modulo n the binary kernel dimension is
deg gcd(1+t**a+t**b, 1+t**n). This scan never claims an SOS result.
"""

import argparse
import json
from collections import Counter
from math import gcd
from pathlib import Path

from janus_occam_solver import gf2_kernel, kernel_search, validate


def gf2_mod(a, b):
    while a and a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length() - b.bit_length())
    return a


def gf2_gcd(a, b):
    while b:
        a, b = b, gf2_mod(a, b)
    return a


def valid_offsets(n, a, b):
    if not 0 < a < b < n or gcd(n, gcd(a, b)) != 1:
        return False
    # Three unordered pair-differences are distinct up to sign modulo n.
    differences = [a, b, b - a]
    canonical = [min(z, n - z) for z in differences]
    return len(set(canonical)) == 3 and all(2 * z != n for z in canonical)


def cyclic(n, a, b):
    rows = [((i) % n, (i + a) % n, (i + b) % n) for i in range(n)]
    validate(rows, n)
    return rows


def scan(max_n=126, min_d=6, max_d_audit=18):
    cases = []
    histogram = Counter()
    for n in range(9, max_n + 1, 3):
        for a in range(1, n):
            for b in range(a + 1, n):
                if not valid_offsets(n, a, b):
                    continue
                dim = gf2_gcd((1 << 0) | (1 << a) | (1 << b),
                              (1 << n) | 1).bit_length() - 1
                histogram[dim] += 1
                if dim < min_d:
                    continue
                item = {'n': n, 'a': a, 'b': b, 'nullity': dim}
                if dim <= max_d_audit:
                    rows = cyclic(n, a, b)
                    _, kernel = gf2_kernel(validate(rows, n), n)
                    assert len(kernel) == dim
                    sat, _, checked = kernel_search(kernel, 2 * n // 3,
                                                    count_all=True)
                    item.update({'SAT_count_exact': sat,
                                 'enumerated': checked,
                                 'status': 'UNSAT' if sat == 0 else 'SAT'})
                else:
                    item['status'] = 'EXACT_SAT_AUDIT_NOT_PERFORMED'
                cases.append(item)
    cases.sort(key=lambda t: (-t['nullity'], t['n'], t['a'], t['b']))
    return {'max_n': max_n, 'min_d': min_d,
            'nullity_histogram': dict(sorted(histogram.items())),
            'cases': cases}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-n', type=int, default=126)
    parser.add_argument('--min-d', type=int, default=6)
    parser.add_argument('--audit-d', type=int, default=18)
    parser.add_argument('--output', type=Path,
                        default=Path('babel11_CYCLIC_NULLITY_SCOUT.json'))
    args = parser.parse_args()
    result = scan(args.max_n, args.min_d, args.audit_d)
    args.output.write_text(json.dumps(result, indent=2,
                                      sort_keys=True) + '\n')
    summary = Counter((c['n'], c['nullity'], c['status']) for c in result['cases'])
    print(json.dumps({'candidate_count': len(result['cases']),
                      'nullity_histogram': result['nullity_histogram'],
                      'case_summary': [[*key, count] for key, count
                                       in sorted(summary.items())]},
                     sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
