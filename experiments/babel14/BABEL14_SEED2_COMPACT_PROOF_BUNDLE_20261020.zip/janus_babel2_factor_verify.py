#!/usr/bin/env python3
"""Independent verifier for BABEL-2 product-of-components certificates."""

import argparse
import json
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate
from janus_babel2_verify import verify as verify_part


def verify(data):
    if not __debug__:
        raise RuntimeError('exact assertions required')
    assert data['format']=='JANUS_BABEL2_component_product_v1'
    n=data['n']
    rows=data['row_triples']
    raw=validate(rows,n)
    all_vars=set()
    all_rows=set()
    total_F=0
    total_rank=0
    total_nullity=0
    leaf_count=0
    score_count=0
    statuses=[]
    for part in data['components']:
        vertices=part['variables']
        row_ids=part['row_indices']
        assert vertices==sorted(vertices) and row_ids==sorted(row_ids)
        assert vertices and len(vertices)==len(row_ids)
        assert all(type(j) is int and 0<=j<n for j in vertices)
        assert all(type(i) is int and 0<=i<n for i in row_ids)
        assert not all_vars.intersection(vertices)
        assert not all_rows.intersection(row_ids)
        all_vars.update(vertices)
        all_rows.update(row_ids)
        to_local={j:k for k,j in enumerate(vertices)}
        local=[]
        for i in row_ids:
            assert all(j in to_local for j in rows[i])
            local.append([to_local[j] for j in rows[i]])
        subcert=part['proof']
        assert subcert['row_triples']==local
        checked=verify_part(subcert)
        total_F+=checked['minimum_F']
        total_rank+=checked['rank']
        total_nullity+=checked['nullity']
        leaf_count+=checked['proof_leaves']
        score_count+=subcert['individual_scores_evaluated_by_constructor']
        statuses.append(checked['exact_one_status'])

    assert all_vars==set(range(n)) and all_rows==set(range(n))
    _,global_kernel=gf2_kernel(raw,n)
    assert len(global_kernel)==total_nullity and n-len(global_kernel)==total_rank
    assert len(statuses)==data['component_count']
    assert total_F==data['exact_global_min_F']
    overall='SAT' if all(status=='SAT' for status in statuses) else 'UNSAT'
    assert overall==data['exact_one_status']
    assert leaf_count==data['component_proof_leaves_total']
    assert score_count==data['explicit_scores_evaluated_total']
    return {'status':'PROVED_EXACT_COMPONENT_PRODUCT',
            'n':n,'component_count':len(statuses),
            'global_nullity':len(global_kernel),
            'total_possible_global_addresses':str(1<<len(global_kernel)),
            'exact_minimum_F':total_F,
            'exact_one_status':overall,
            'summed_proof_leaves':leaf_count,
            'scores_reported_evaluated':score_count}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate',type=Path)
    args=p.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),
                     sort_keys=True,indent=2))


if __name__=='__main__':
    main()
