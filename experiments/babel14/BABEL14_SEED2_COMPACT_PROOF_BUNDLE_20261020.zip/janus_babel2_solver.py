#!/usr/bin/env python3
"""BABEL-2: exact hybrid subcube proof, XOR triangles + constant-bit blocks.

This exact algorithm works for every legal SCL, but may take exponential
time in kernel nullity. Block width is a fixed local parameter, not an
asymptotic complexity theorem.
"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel, walsh_value
from janus_babel1_solver import bounded_group, split


FORMAT = 'JANUS_BABEL2_hybrid_XOR3_BLOCK_v1'


def certified_minimum(triples, *, order=None, block_width=4, metadata=None):
    n = len(triples)
    rows = validate(triples, n)
    rowspace, kernel = gf2_kernel(rows, n)
    d = len(kernel)
    if order is None:
        order = list(range(d))
    if sorted(order) != list(range(d)):
        raise ValueError('invalid selector order')
    if not 0 <= block_width <= d:
        raise ValueError('block width outside 0..d')
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5*n+100))
    columns = columns_of_kernel(kernel, n)
    best = walsh_value(columns, 0)
    best_selector = 0
    explicit_scores = 1
    improved = 0
    expanded = 0
    leaves = []

    def descend(coeff, depth, path, fixed_selector):
        nonlocal best, best_selector, explicit_scores, improved, expanded
        bound, packets = bounded_group(coeff)
        if bound >= best:
            leaves.append([path, 'xor3', bound, packets])
            return
        remaining = d - depth
        if remaining <= block_width:
            block_best = None
            block_selector = None
            for extension in range(1 << remaining):
                free_c = sum(((extension >> j) & 1) << order[depth+j]
                             for j in range(remaining))
                value = sum(a * (-1 if (q & free_c).bit_count() & 1 else 1)
                            for q, a in coeff.items())
                if block_best is None or value < block_best:
                    block_best, block_selector = value, fixed_selector | free_c
                explicit_scores += 1
            assert block_best is not None and bound <= block_best
            if block_best < best:
                best = block_best
                best_selector = block_selector
                improved += 1
            leaves.append([path, 'block', block_best, []])
            return

        expanded += 1
        left, right = split(coeff, order[depth])
        children = [(left, '0', fixed_selector),
                    (right, '1', fixed_selector | (1 << order[depth]))]
        children.sort(key=lambda child: (bounded_group(child[0])[0], child[1]))
        for child_coeff, direction, child_selector in children:
            descend(child_coeff, depth + 1, path + direction, child_selector)

    descend(Counter(columns), 0, '', 0)
    v = 0
    for k, vector in enumerate(kernel):
        if (best_selector >> k) & 1:
            v ^= vector
    assert best == n - 2*v.bit_count()
    x = ((1 << n) - 1) ^ v
    is_sat = all((row & x).bit_count() == 1 for row in rows)
    assert is_sat == (n % 3 == 0 and best == -(n//3))
    cover = sum(1 << (d - len(path)) for path, _, _, _ in leaves)
    assert cover == 1 << d
    cert = {
        'format': FORMAT, 'n': n,
        'row_triples': [list(row) for row in triples],
        'rank_GF2': len(rowspace), 'nullity_GF2': d,
        'basis_bit_order': list(order),
        'block_width': block_width,
        'minimum_F': best,
        'witness_selector_hex': hex(best_selector),
        'witness_kernel_word_hex': hex(v),
        'exact_one_status': 'SAT' if is_sat else 'UNSAT',
        'proof_leaves': leaves, 'proof_leaf_count': len(leaves),
        'symbolically_covered_selectors': cover,
        'individual_scores_evaluated_by_constructor': explicit_scores,
        'expanded_nodes': expanded,
        'incumbent_improvements': improved,
    }
    if is_sat:
        cert['witness_true_variables'] = [i for i in range(n) if (x >> i) & 1]
    if metadata:
        cert['input_metadata'] = metadata
    return cert


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('instance', type=Path)
    p.add_argument('--block-width', type=int, default=4)
    p.add_argument('--order', help='comma-separated GF(2) kernel coordinate order')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    inp = json.loads(args.instance.read_text())
    order = [int(v) for v in args.order.split(',')] if args.order else None
    result = certified_minimum(inp['rows'], order=order, block_width=args.block_width)
    args.output.write_text(json.dumps(result, sort_keys=True, indent=1) + '\n')
    print(json.dumps({key:result[key] for key in ('n','nullity_GF2','minimum_F',
                'exact_one_status','proof_leaf_count',
                'individual_scores_evaluated_by_constructor')},indent=2))


if __name__ == '__main__':
    main()
