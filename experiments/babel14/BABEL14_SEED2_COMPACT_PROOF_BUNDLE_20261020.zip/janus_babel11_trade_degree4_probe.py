#!/usr/bin/env python3
"""Modular ONLY SOS4 rank pilot on rank-preserving non-cover SCLs.

A nonzero Lanczos constant over a finite field does not prove rational
membership. A zero constant over one prime is equally not an obstruction.
Any proposed proof requires a separate rational reconstruction and replay.
"""

import argparse
import json
import time
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix

from janus_babel10_degree_scan import character_products
from janus_babel9_krylov_68 import lanczos_for_normal


def probe(rows, prime, max_powers):
    _, dimension, basis_size, products = character_products(rows, 2)
    if dimension > 15:
        raise ValueError('pilot capped at Fourier dimension 2**15')
    count = len(products)
    frequency = np.asarray(products, dtype=np.int64)
    matrix = coo_matrix((np.ones(4 * count, dtype=np.int64),
                         (frequency.ravel(),
                          np.repeat(np.arange(count), 4))),
                        shape=(1 << dimension, count)).tocsr()
    normal = matrix @ matrix.T
    polynomial = lanczos_for_normal(normal, prime, max_powers)
    return {'prime':prime,'recurrence_degree':len(polynomial)-1,
            'constant_nonzero_mod_prime':bool(polynomial[0]),
            'Fourier_column_count':count,'multiplier_basis_size':basis_size,
            'parity_kernel_dimension':dimension}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',type=Path,default=Path('babel11_TRADES_SEED0.json'))
    ap.add_argument('--max-powers',type=int,default=3000)
    ap.add_argument('--primes',type=int,nargs='+',default=[10000079,10000103])
    ap.add_argument('--max-cases',type=int,default=0)
    ap.add_argument('--output',type=Path,
                    default=Path('babel11_TRADE_MODULAR_SOS4.json'))
    args=ap.parse_args()
    evidence=json.loads(args.input.read_text())
    results=[]
    cases=evidence if isinstance(evidence,list) else evidence['cases']
    if args.max_cases:
        cases=cases[:args.max_cases]
    for case in cases:
        start=time.monotonic()
        reps=[]
        for prime in args.primes:
            try:
                reps.append(probe(case['rows'],prime,args.max_powers))
            except ArithmeticError as err:
                reps.append({'prime':prime,'error':str(err)})
        item={'seed':case['seed'],'steps':case['steps'],
              'SHA256_rows_canonical':case.get('SHA256_rows_canonical',
                                              case.get('SHA256_rows')),
              'observations':reps,'elapsed_s':round(time.monotonic()-start,2),
              'scientific_status':'MODULAR_ONLY'}
        results.append(item)
        print(json.dumps(item,sort_keys=True),flush=True)
        args.output.write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')


if __name__=='__main__':main()
