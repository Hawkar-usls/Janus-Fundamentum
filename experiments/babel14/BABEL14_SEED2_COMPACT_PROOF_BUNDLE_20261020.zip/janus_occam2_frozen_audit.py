#!/usr/bin/env python3
"""Bind an OCCAM-2 self-contained proof to the exact frozen JANUS matrix."""

import hashlib
import json
from pathlib import Path

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam2_verify import verify


def main():
    folder = Path(__file__).resolve().parent
    proof_path = folder / 'JANUS_OCCAM2_UNSAT_L1_certificate_20261018.json'
    cert = json.loads(proof_path.read_text())
    meta = cert['input_metadata']
    source_path = folder / 'tutte12.am.csv'
    digest = hashlib.sha256(source_path.read_bytes()).hexdigest()
    assert meta['tutte12_am_csv_sha256'] == digest
    name, mask, sat, rank = FIXTURES[1]
    assert (meta['frozen_fixture'], meta['mask']) == (name, mask)
    assert (sat, rank) == (0, 111)
    reconstructed = cover(source_triples(source_path), mask)
    assert reconstructed == cert['row_triples'], 'certificate is not for the frozen matrix'
    result = verify(cert)
    assert result['minimum_walsh_score'] == -34
    assert result['leaf_count'] == 1216
    print(json.dumps({**result, 'frozen_matrix_hash_verified': True,
                      'certificate_matches_frozen_mask': True}, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
