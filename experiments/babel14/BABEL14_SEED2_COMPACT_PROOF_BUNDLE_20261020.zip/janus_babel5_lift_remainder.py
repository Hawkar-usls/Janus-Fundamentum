#!/usr/bin/env python3
"""Inspect whether a lifted BABEL-4c dual has a correctable -sector tail."""

import argparse
import json
from collections import Counter,defaultdict
from pathlib import Path

from janus_babel4c_kernel import source_data as source63
from janus_babel5_kernel import source_data as source126
from janus_babel5_projection import linear_projection


def lifted_remainder():
    full=json.loads(Path(__file__).with_name(
         'babel4c_SCL63_krylov_rational_dual.json').read_text())
    _,_,source_defects,source_basis=source63()
    cover,labels,_,cover_basis=source126()
    apply,extra,_=linear_projection()
    origins={}
    for r,(a,b,c) in enumerate(source_defects):
        for u in source_basis:
            support=tuple(sorted((u,u^a,u^b,u^c)))
            origins.setdefault(support,(r,u))
    assert len(origins)==len(full['multipliers'])==60354
    rep={}
    for u in cover_basis:
        rep.setdefault(apply(u),u)
    assert len(rep)==1450
    polynomial=defaultdict(int)
    for support,y in zip(sorted(origins),full['multipliers']):
        r,base_u=origins[support]
        u=rep[base_u]
        polynomial[u]+=y
        for col in cover[r]:
            polynomial[u^labels[col]]+=y
    plus=defaultdict(int)
    for q,a in polynomial.items():
        plus[apply(q)]+=a
    assert plus[0]==full['normalization_D']
    assert all(v==0 for q,v in plus.items() if q)
    # Remainder H is D*P_+ plus a polynomial restricted to P_-.
    representatives={}
    mask=extra&-extra
    for q in range(1<<15):
        representatives.setdefault(apply(q),q if not q&mask else q^extra)
    assert len(representatives)==16384
    tail={}
    for b,q in representatives.items():
        val=polynomial[q]-polynomial[q^extra]
        if val:
            tail[b]=val
    cover_set=set(cover_basis)
    split=[labels[i] for i in range(63) if labels[i]!=labels[i+63]]
    reachable=sum(any((representatives[b]^a) in cover_set
                      or (representatives[b]^extra^a) in cover_set
                      for a in split) for b in tail)
    return {'status':'EXACT_LIFTED_PLUS_PROJECTION_PASS',
       'source_identity_D':full['normalization_D'],
       'lift_polynomial_nonzero_frequencies':sum(bool(v) for v in polynomial.values()),
       'source_degree2_character_types':len(source_basis),
       'lift_degree2_character_types':len(cover_basis),
       'nonzero_sector_minus_remainder_frequencies':len(tail),
       'sector_minus_tail_reachable_by_one_split_anchor':reachable,
       'sector_minus_unreachable_count':len(tail)-reachable,
       'sector_minus_tail_max_abs_coefficient':max(map(abs,tail.values()))}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    args=p.parse_args()
    report=lifted_remainder()
    if args.output:
        args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,indent=2,sort_keys=True))
