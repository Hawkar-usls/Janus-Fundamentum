#!/usr/bin/env python3
"""Try all combinatorial seven-row strips for degree-6 local transfer.

Prime-field feasibility is only a screen. Successful hits still require the
integer group-algebra verification from janus_babel8_degree6_transfer.py.
"""

import argparse
import json
from pathlib import Path

from janus_babel6_transfer import xor_labels, make_projection, signed_graph
from janus_babel7_strip_scan import candidate_strips
from janus_babel8_coset_audit import modular_case
from janus_occam_replay import FIXTURES, cover, source_triples


def investigate(bit):
    src = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    base_labels, _, bd = xor_labels(src)
    lifted = cover(src, format(int(FIXTURES[1][1], 16) ^ (1 << bit), 'x'))
    labels, _, d = xor_labels(lifted)
    _, extra = make_projection(base_labels, labels, bd, d)
    split, _, _ = signed_graph(src, lifted, labels, extra)
    candidates = [rowset for rowset, proof in candidate_strips(
        src, lifted, split)]
    results = []
    for i, rows in enumerate(candidates):
        report = modular_case(bit, rows, degree=3)
        results.append({'rows': rows, 'ambient_cosets':
                        report['ambient_cosets'],
                        'active_cosets': report['active_cosets'],
                        'failures': report['modular_failures'],
                        'failed_cosets': report['failure_cosets']})
        print(json.dumps({'flip': bit, 'candidate': i + 1,
                          'total': len(candidates),
                          'modular_failures': report['modular_failures']},
                         sort_keys=True), flush=True)
        if report['modular_failures'] == 0:
            break
    return {'bit': bit, 'cases_checked': len(results),
            'candidate_count': len(candidates), 'results': results,
            'warning': 'prime-field diagnostic only'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bits', nargs='+', type=int, default=[68, 94, 168, 169])
    args = p.parse_args()
    output = []
    for bit in args.bits:
        output.append(investigate(bit))
    path = Path(__file__).with_name('babel8_ALTERNATIVE_STRIP_MODULAR.json')
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')


if __name__ == '__main__':
    main()
