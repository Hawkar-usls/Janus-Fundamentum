#!/usr/bin/env python3
"""Independent sparse verifier for BABEL-6 integer SOS dual.

Does not import the discovery/transfer code; checks each represented Fourier
character (not an enumerated list of all 2**d characters). Exact integers.
"""

import argparse
import hashlib
import json
from collections import defaultdict, deque
from fractions import Fraction
from itertools import combinations
from pathlib import Path

from janus_occam_replay import cover, source_triples
from janus_occam_solver import gf2_kernel, validate


def connected_vertices(rows):
    n = len(rows)
    graph = [[] for _ in range(2*n)]
    for r,triple in enumerate(rows):
        for c in triple:
            graph[r].append(n+c)
            graph[n+c].append(r)
    seen = {0}
    todo = deque([0])
    while todo:
        for v in graph[todo.popleft()]:
            if v not in seen:
                seen.add(v)
                todo.append(v)
    return len(seen)


def verify(record):
    assert record['format'] == 'JANUS_BABEL6_SPARSE_TRANSFER_DUAL_V1'
    source_path = Path(__file__).with_name('tutte12.am.csv')
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == record['source_csv_sha256']
    base = source_triples(source_path)
    covered = cover(base,record['cover_mask_hex'])
    assert len(covered) == 126
    _, kernel = gf2_kernel(validate(covered,126),126)
    assert len(kernel) == 15
    assert connected_vertices(covered) == 252
    labels = [sum(((vector >> i) & 1) << bit
                  for bit,vector in enumerate(kernel)) for i in range(126)]
    degree2 = {0, *labels, *(a^b for a,b in combinations(labels,2))}
    assert len(degree2) == 2781
    seen = set()
    frequencies = defaultdict(int)
    l1 = [0]*126
    for term in record['terms']:
        assert len(term) == 3
        r,u,value = term
        assert all(type(x) is int for x in term)
        assert 0 <= r < 126 and u in degree2 and value
        assert (r,u) not in seen
        seen.add((r,u))
        l1[r] += abs(value)
        frequencies[u] += value
        for j in covered[r]:
            frequencies[u^labels[j]] += value
    D = record['normalization_D']
    C = record['dual_norm_upper_bound_C']
    assert type(D) is int and type(C) is int and D > 0 and C > 0
    support = {q:c for q,c in frequencies.items() if c}
    assert support == {0:D}, f'invalid sparse Fourier dual: {len(support)} frequencies'
    assert sum(v*v for v in l1) == C
    gap = Fraction(D*D,12*C)
    assert gap > 0
    return {
      'status':'BABEL6_INDEPENDENT_SPARSE_RATIONAL_SOS_DUAL_PASS',
      'certificate_terms_checked':len(record['terms']),
      'frequency_additions':4*len(record['terms']),
      'fourier_nonzero_target_terms':len(support),
      'GF2_kernel_dimension':len(kernel),
      'moment_matrix_dimension':len(degree2),
      'connected_incidence_vertices':252,
      'D':str(D),'C':str(C),
      'strict_gap':str(gap),
      'lower_bound_F':f'-42+{gap}',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('proof_json',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    report=verify(json.loads(args.proof_json.read_text()))
    if args.output:
        args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps(report,sort_keys=True,indent=2))


if __name__=='__main__':
    main()
