#!/usr/bin/env python3
"""Independent small brute-force, soundness, and corruption gates for BABEL-3."""

import copy
import json
import random
from collections import Counter
from pathlib import Path

from janus_occam_solver import gf2_kernel,validate
from janus_occam_replay import source_triples
from janus_babel3_solver import prove
from janus_babel3_packets import packet_min,rank3_group_bound
from janus_babel3_rational_verify import verify
from janus_babel3_exact_pseudomodel import exact_sparse_pseudo


def expect_bad(proof):
    try:
        verify(proof)
    except (AssertionError,ValueError,KeyError,TypeError,IndexError):
        return
    raise AssertionError('forged proof erroneously accepted')


def main():
    # Small 9x9 connected legal cubic Exact-One instance.
    nine=[[0,1,2],[0,3,4],[0,5,6],
          [1,3,7],[1,5,8],[2,4,8],
          [2,6,7],[3,6,8],[4,5,7]]
    rows=validate(nine,len(nine))
    _,kernel=gf2_kernel(rows,len(rows))
    brute=[]
    for mask in range(1<<len(kernel)):
        v=0
        for k,w in enumerate(kernel):
            if mask>>k&1:
                v^=w
        brute.append(len(rows)-2*v.bit_count())
    cert=prove(nine,block_width=2)
    assert verify(cert)['minimum_F']==min(brute)==-3

    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    real=prove(source,block_width=0)
    accepted=verify(real)
    assert accepted['minimum_F']==-17 and accepted['overlapping_five_term_packets_verified']>0
    rng=random.Random(703)
    test_groups=0
    # Every random local bound must be below the true minimum in the 14-bit
    # selector space; use 2^14 evaluations only for small test samples.
    support=list(set(range(1,32)))
    for _ in range(10):
        coeff={q:rng.randint(-4,4) for q in support}
        coeff={q:a for q,a in coeff.items() if a}
        bound,groups=rank3_group_bound(coeff)
        true=min(sum(a*(-1 if (q&c).bit_count()&1 else 1)
                     for q,a in coeff.items()) for c in range(32))
        assert bound<=true
        for group in groups:
            assert packet_min(coeff,group)>=-sum(abs(coeff[q]) for q in group)
        test_groups+=len(groups)

    forged=[]
    f=copy.deepcopy(real);f['minimum_F']-=2;forged.append(f)
    f=copy.deepcopy(real);f['exact_one_status']='SAT';forged.append(f)
    f=copy.deepcopy(real);f['proof_leaves'].pop();f['proof_leaf_count']-=1;forged.append(f)
    f=copy.deepcopy(real);f['proof_leaves'][0][2]+=2;forged.append(f)
    f=copy.deepcopy(real)
    for leaf in f['proof_leaves']:
        if leaf[1]=='overlap' and leaf[3]:
            leaf[3][0][0]=leaf[3][0][1]
            break
    forged.append(f)
    for f in forged:
        expect_bad(f)
    pseudo=exact_sparse_pseudo(source)
    assert pseudo['status']=='EXACT_RANK3_PSEUDOMODEL_FEASIBLE'
    print(json.dumps({'nine_full_brute':'PASS','nine_minimum':-3,
                      'SCL63_exact_rank3_packet_certificate':'PASS',
                      'SCL63_minimum':-17,
                      'SCL63_rank3_packets':accepted['overlapping_five_term_packets_verified'],
                      'rank3_packet_random_lower_bound_checks':10,
                      'random_packets_checked':test_groups,
                      'corruption_cases_rejected':len(forged),
                      'SCL63_rank3_pseudomodel_exact':'PASS'},sort_keys=True,indent=2))


if __name__=='__main__':
    main()
