#!/usr/bin/env python3
"""BABEL-7: rational degree-six SOS transfer via 64 Fourier cosets.

This is a multi-prime DISCOVERY algorithm with mandatory independent exact
integer group-algebra verification before any proof is accepted.
"""

import argparse
import hashlib
import json
from collections import defaultdict,Counter
from fractions import Fraction
from math import lcm
from pathlib import Path

from janus_babel7_coset_probe import coset_data
from janus_babel7_degree_audit import audit,degree_witnesses
from janus_babel7_local_probe import DEFAULT_ROWS
from janus_babel7_local_dual import modular_certificate
from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels
from janus_occam_replay import FIXTURES,cover


PRIMES=(1000000007,1000000009,998244353,1004535809,469762049)


def crt_values(residues,primes):
    out=0
    modulus=1
    for residue,p in zip(residues,primes):
        factor=((residue-out)%p)*pow(modulus%p,-1,p)%p
        out+=factor*modulus
        modulus*=p
    return out,modulus


def recover(value,modulus,max_numerator=10**24,max_denominator=8192):
    if value==0:return Fraction(0)
    # Denominators of the observed local equations are tiny powers of two;
    # if not, fall back to all denominators within the finite search bound.
    preferred=[1<<i for i in range(max_denominator.bit_length())
               if 1<<i<=max_denominator]
    for b in preferred:
        x=value*b%modulus
        a=x-modulus if x>modulus//2 else x
        if abs(a)<=max_numerator:
            return Fraction(a,b)
    for b in range(2,max_denominator+1):
        if b in preferred:continue
        x=value*b%modulus
        a=x-modulus if x>modulus//2 else x
        if abs(a)<=max_numerator:
            return Fraction(a,b)
    raise ValueError('CRT rational reconstruction out of bounded range')


def sparse_fourier_check(rows,labels,terms,D):
    poly=defaultdict(int)
    l1=[0]*len(rows)
    for (row,u),coef in terms.items():
        if not coef:continue
        l1[row]+=abs(coef)
        poly[u]+=coef
        for col in rows[row]:
            poly[u^labels[col]]+=coef
    remaining={q:a for q,a in poly.items() if a}
    if remaining!={0:D}:
        raise AssertionError(f'bad exact dual: {len(remaining)} residuals')
    return sum(x*x for x in l1)


def construct(case_limit=None):
    source,base_terms,D=load_base()
    lifted=cover(source,format(int(FIXTURES[1][1],16)^(1<<16),'x'))
    labels,Q,dim=xor_labels(lifted)
    info,difference,H,reps,witness=audit(16)
    coset_labels,quotient,defects=coset_data()
    assert coset_labels==labels
    degree3=degree_witnesses(labels,max_degree=3)
    by_coset=defaultdict(list)
    for u in degree3:
        by_coset[quotient(u)].append(u)
    targets=defaultdict(lambda:defaultdict(int))
    e=2128
    for q,c in difference.items():
        r=quotient(q)
        targets[r][q]+=2*c
        targets[r][q^e]-=2*c
    assert len(targets)==64
    correction=defaultdict(Fraction)
    denominators=Counter()
    term_counts=Counter()
    for index,(coset,tgt) in enumerate(sorted(targets.items())):
        if case_limit is not None and index>=case_limit:
            break
        origin={}
        for row,columns in defects.items():
            for u in by_coset[coset]:
                four=tuple(sorted((u,*(u^a for a in columns))))
                origin.setdefault(four,(row,u))
        supports=sorted(origin)
        modular=[]
        ranks=[]
        for prime in PRIMES:
            sol,rank=modular_certificate(supports,tgt,prime)
            modular.append(sol)
            ranks.append(rank)
        assert len(set(ranks))==1,('modular rank drift',coset,ranks)
        coefficient_indices=set().union(*(x.keys() for x in modular))
        part=defaultdict(Fraction)
        for equation_index in coefficient_indices:
            residues=[sol.get(equation_index,0) for sol in modular]
            value,modulus=crt_values(residues,PRIMES)
            recovered=recover(value,modulus)
            if recovered:
                part[origin[supports[equation_index]]]+=recovered
                denominators[recovered.denominator]+=1
        # Critical: verify each coset separately OVER THE RATIONALS;
        # otherwise modular false positives cannot enter the output.
        rational_freq=defaultdict(Fraction)
        for (row,u),coeff in part.items():
            rational_freq[u]+=coeff
            for char in defects[row]:
                rational_freq[u^char]+=coeff
        assert {q:c for q,c in rational_freq.items() if c}==\
            {q:c for q,c in tgt.items() if c}, ('rational coset failure',coset)
        for key,val in part.items():
            correction[key]+=val
        term_counts[coset]=len([v for v in part.values() if v])
    if case_limit is not None:
        return None,{'checked_cosets':len(term_counts),
                     'rational_reconstruction_passed':True,
                     'denominator_histogram':dict(denominators),
                     'terms_per_coset':dict(term_counts)}
    main=defaultdict(Fraction)
    for (r,u),y in base_terms.items():
        main[r,reps[u]]+=4*y
    for key,val in correction.items():
        main[key]+=val
    denominator=1
    for val in main.values():
        denominator=lcm(denominator,val.denominator)
    terms={key:int(val*denominator) for key,val in main.items() if val}
    assert all(u in degree3 for r,u in terms)
    Dfull=4*D*denominator
    C=sparse_fourier_check(lifted,labels,terms,Dfull)
    gap=Fraction(Dfull*Dfull,12*C)
    record={'format':'JANUS_BABEL7_BALANCED_UNSAT126_DEGREE6_SOS_DUAL_V1',
       'source_csv_sha256':
         '3fa7fa40e970dfc975af7413b7a419edcf57e341a53e0f11b9242e5d67f41899',
       'cover_mask_hex':format(int(FIXTURES[1][1],16)^(1<<16),'x'),
       'degree_limit_for_multiplier_characters':3,
       'degree_limit_for_SOS':6,
       'normalization_D':Dfull,'dual_norm_upper_bound_C':C,
       'strict_gap_numerator':gap.numerator,
       'strict_gap_denominator':gap.denominator,
       'terms':[[r,u,y] for (r,u),y in sorted(terms.items())]}
    summary={'status':'BABEL7_EXACT_GLOBAL_DEGREE6_RATIONAL_SOS_PASS',
       'cosets_exactly_solved':64,
       'rational_denominator_scaling':denominator,
       'local_correction_terms_before_merge':sum(term_counts.values()),
       'exact_terms':len(terms),
       'degree3_basis_size':len(degree3),
       'max_character_degree':max(len(degree3[u]) for r,u in terms),
       'D':str(Dfull),'C':str(C),
       'strict_F_gap':str(gap),
       'strict_F_bound':f'-42+{gap}',
       'CRT_primes_count':len(PRIMES),
       'denominator_histogram':dict(denominators)}
    return record,summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path)
    p.add_argument('--report',type=Path)
    p.add_argument('--first-cosets',type=int)
    args=p.parse_args()
    record,summary=construct(args.first_cosets)
    if args.output and record:
        args.output.write_text(json.dumps(record,separators=(',',':'),
                                         sort_keys=True)+'\n')
        summary['proof_sha256']=hashlib.sha256(args.output.read_bytes()).hexdigest()
    if args.report:
        args.report.write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
    short={k:v for k,v in summary.items()
           if k not in ('terms_per_coset','denominator_histogram')}
    print(json.dumps(short,indent=2,sort_keys=True))


if __name__=='__main__':main()
