#!/usr/bin/env python3
"""Exact BABEL-3 rational packet/subcube proof generator for legal SCLs.

This is a finite proof-producing algorithm with exponential worst-case
time and size. Packet bounds are integral/rational and independently checked.
"""

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel, walsh_value
from janus_babel1_solver import split
from janus_babel3_packets import rank3_group_bound


FORMAT = 'JANUS_BABEL3_OVERLAP5_XOR3_BLOCK_v1'


def prove(triples, *, order=None, block_width=0, metadata=None):
    n = len(triples)
    rows = validate(triples, n)
    rowspace, kernel = gf2_kernel(rows, n)
    d = len(kernel)
    if order is None:
        order = list(range(d))
    if sorted(order) != list(range(d)):
        raise ValueError('invalid kernel selector order')
    if not 0 <= block_width <= d:
        raise ValueError('invalid local block width')
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5*n + 100))
    columns = columns_of_kernel(kernel, n)
    best = walsh_value(columns, 0)
    best_selector = 0
    direct_scores = 1
    leaves = []
    expanded = 0
    used_five_packets = 0

    def dfs(coeff, depth, path, selector):
        nonlocal best, best_selector, direct_scores, expanded, used_five_packets
        bound, packets = rank3_group_bound(coeff)
        if bound >= best:
            used_five_packets += sum(len(p) == 5 for p in packets)
            leaves.append([path, 'overlap', bound, packets])
            return
        remaining = d - depth
        if remaining <= block_width:
            block_min = None
            block_selector = None
            for free in range(1 << remaining):
                rest = sum(((free >> j) & 1) << order[depth + j]
                           for j in range(remaining))
                value = sum(a * (-1 if (q & rest).bit_count() & 1 else 1)
                            for q, a in coeff.items())
                direct_scores += 1
                if block_min is None or value < block_min:
                    block_min = value
                    block_selector = selector | rest
            assert bound <= block_min
            if block_min < best:
                best, best_selector = block_min, block_selector
            leaves.append([path, 'block', block_min, []])
            return
        expanded += 1
        left, right = split(coeff, order[depth])
        choices = [(left, '0', selector), (right, '1', selector | (1 << order[depth]))]
        choices.sort(key=lambda item: (rank3_group_bound(item[0])[0], item[1]))
        for child, bit, child_selector in choices:
            dfs(child, depth + 1, path + bit, child_selector)

    dfs(Counter(columns), 0, '', 0)
    witness = 0
    for k, vector in enumerate(kernel):
        if best_selector & (1 << k):
            witness ^= vector
    assert best == n - 2 * witness.bit_count()
    complement = ((1 << n) - 1) ^ witness
    is_sat = all((r & complement).bit_count() == 1 for r in rows)
    assert is_sat == (n % 3 == 0 and best == -(n // 3))
    coverage = sum(1 << (d - len(row[0])) for row in leaves)
    assert coverage == 1 << d
    result = {'format': FORMAT, 'n': n, 'row_triples': [list(row) for row in triples],
              'rank_GF2': len(rowspace), 'nullity_GF2': d,
              'basis_bit_order': list(order), 'block_width': block_width,
              'minimum_F': best, 'exact_one_status': 'SAT' if is_sat else 'UNSAT',
              'witness_selector_hex': hex(best_selector),
              'witness_kernel_word_hex': hex(witness),
              'proof_leaves': leaves, 'proof_leaf_count': len(leaves),
              'symbolically_covered_selectors': coverage,
              'individual_scores_evaluated_by_constructor': direct_scores,
              'overlap5_packets_in_proof': used_five_packets,
              'expanded_nodes': expanded}
    if is_sat:
        result['witness_true_variables'] = [j for j in range(n)
                                            if complement & (1 << j)]
    if metadata:
        result['input_metadata'] = metadata
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('instance', type=Path)
    p.add_argument('--block-width', type=int, default=0)
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    triples = json.loads(args.instance.read_text())['rows']
    cert = prove(triples, block_width=args.block_width)
    args.output.write_text(json.dumps(cert, sort_keys=True, indent=1) + '\n')
    print(json.dumps({k: cert[k] for k in ('minimum_F', 'exact_one_status',
                                         'proof_leaf_count', 'overlap5_packets_in_proof')},
                     indent=2))


if __name__ == '__main__':
    main()
