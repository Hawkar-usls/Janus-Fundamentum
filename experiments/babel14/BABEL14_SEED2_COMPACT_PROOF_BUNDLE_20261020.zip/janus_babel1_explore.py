#!/usr/bin/env python3
"""Explore XOR-triple lower bounds for the Babylon-prefix JANUS index."""

from collections import Counter, defaultdict
from pathlib import Path
import json
import time

from janus_occam_replay import FIXTURES, cover, source_triples
from janus_occam_solver import gf2_kernel, validate
from janus_occam2_prove import columns_of_kernel


ORDER = (9, 0, 1, 5, 8, 12, 11, 2, 14, 4, 3, 13, 6, 7, 10)


def xor3_bound(coeff, return_triples=False):
    """A valid L1 bound improved by a greedily packed disjoint XOR triples."""
    base = coeff.get(0, 0) - sum(abs(value) for q, value in coeff.items() if q)
    support = sorted(q for q, value in coeff.items() if q and value)
    candidates = []
    for i, p in enumerate(support):
        ap = coeff[p]
        for q in support[i + 1:]:
            t = p ^ q
            if t <= q or t not in coeff or not coeff[t]:
                continue
            aq, at = coeff[q], coeff[t]
            if (ap > 0) == (aq > 0) == (at > 0):
                # Only a shorthand for same signs, not correct for +--.
                pass
            if (ap > 0) ^ (aq > 0) ^ (at > 0):
                # Three signs with odd positive count have product +1.
                gain = 2 * min(abs(ap), abs(aq), abs(at))
                candidates.append((-gain, p, q, t))
    candidates.sort()
    used = set()
    selected = []
    gain = 0
    for negative, p, q, t in candidates:
        if p in used or q in used or t in used:
            continue
        used.update((p, q, t))
        gain -= negative
        selected.append((p, q, t))
    return (base + gain, selected) if return_triples else base + gain


def explore(columns, order, target, enhanced=True):
    stats = Counter()
    leaf_lengths = Counter()

    def visit(coeff, depth):
        bound = (xor3_bound(coeff) if enhanced
                 else coeff.get(0, 0)-sum(abs(v) for q, v in coeff.items() if q))
        if bound >= target:
            stats['leaves'] += 1
            stats['coverage'] += 1 << (len(order) - depth)
            leaf_lengths[depth] += 1
            return
        if depth == len(order):
            raise ValueError('witness not optimal')
        stats['internal'] += 1
        bit = 1 << order[depth]
        left, right = defaultdict(int), defaultdict(int)
        for q, v in coeff.items():
            r = q & ~bit
            left[r] += v
            right[r] += (-v if q & bit else v)
        visit(left, depth+1)
        visit(right, depth+1)

    start = time.monotonic()
    visit(Counter(columns), 0)
    return {'leaves': stats['leaves'], 'internal': stats['internal'],
            'coverage': stats['coverage'],
            'depths': dict(sorted(leaf_lengths.items())),
            'wall_seconds': round(time.monotonic()-start, 3)}


if __name__ == '__main__':
    source = source_triples(Path(__file__).with_name('tutte12.am.csv'))
    data = {}
    for name,mask,_,_ in FIXTURES[:2]:
        rows = validate(cover(source, mask), 126)
        _, kernel = gf2_kernel(rows, 126)
        columns = columns_of_kernel(kernel, 126)
        target = -42 if name.endswith('SAT2') else -34
        data[name] = {
            'L1': explore(columns, ORDER, target, False),
            'XOR3': explore(columns, ORDER, target, True),
        }
    print(json.dumps(data, sort_keys=True, indent=2))
