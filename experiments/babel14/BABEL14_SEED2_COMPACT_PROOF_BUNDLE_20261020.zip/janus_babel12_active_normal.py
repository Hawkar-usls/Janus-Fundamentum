#!/usr/bin/env python3
"""Build exact integer SOS normal operator without a 2**dim ambient array.

The four-point affine subgroup cosets are deduplicated directly from
degree-ell multiplier characters. Only their polynomial-size active union
is stored. For the stabilized partition, this gives the same quotient as
the ambient construction, except for any completely isolated zero cell.
"""

import argparse
import hashlib
import json
import time
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix

from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses
from janus_babel12_sparse_oracle import row_planes


def active_normal(rows, ell=2):
    labels, _, d = xor_labels(rows)
    allowed=sorted(degree_witnesses(labels,ell))
    planes=row_planes(rows,labels)
    cosets=[]
    for h in planes:
        seen=set()
        a,b,c=h[1:]
        for u in allowed:
            key=min(u,u^a,u^b,u^c)
            if key not in seen:
                seen.add(key)
                cosets.append((key,key^a,key^b,key^c))
    cosets=np.array(cosets,dtype=np.int32)
    unique=np.unique(cosets)
    assert unique[0]==0
    indices=np.searchsorted(unique,cosets.reshape(-1)).astype(np.int32)
    assert np.array_equal(unique[indices],cosets.reshape(-1))
    columns=cosets.shape[0]
    mat=csr_matrix((np.ones(4*columns,dtype=np.int32),(
        indices,np.repeat(np.arange(columns,dtype=np.int32),4))),
        shape=(len(unique),columns))
    normal=(mat@mat.T).tocsr()
    assert int(normal[0,0])==len(planes)
    assert (normal-normal.T).nnz==0
    assert np.min(normal.data)>0
    return unique, normal, {'n':len(rows),'kernel_dimension':d,
        'multiplier_degree':ell,'allowed_characters':len(allowed),
        'distinct_planes':len(planes),'active_frequencies':len(unique),
        'unique_affine_plane_cosets':columns,'normal_nnz':normal.nnz,
        'all_active_C_rows_have_positive_diagonal':True}


def refine(normal, rounds=4):
    size=normal.shape[0]
    colors=[int(i!=0) for i in range(size)]
    history=[]
    for ri in range(rounds):
        start=time.monotonic()
        lookup={}
        new=[]
        for i in range(size):
            weights={}
            for pos in range(normal.indptr[i],normal.indptr[i+1]):
                c=colors[int(normal.indices[pos])]
                weights[c]=weights.get(c,0)+int(normal.data[pos])
            signature=(colors[i],tuple(sorted(weights.items())))
            new.append(lookup.setdefault(signature,len(lookup)))
        stable=new==colors
        history.append({'round':ri+1,'cells':len(lookup),'stable':stable,
                        'elapsed_seconds_diagnostic':round(time.monotonic()-start,3)})
        print(json.dumps(history[-1],sort_keys=True),flush=True)
        colors=new
        if stable:
            break
    return colors,history


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--instance',default='SCL252_seed0')
    parser.add_argument('--ell',type=int,default=2)
    parser.add_argument('--rounds',type=int,default=4)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    from janus_babel10_degree_scan import frozen_instances
    cases=frozen_instances()
    if args.instance in cases:
        rows=cases[args.instance]
    elif args.instance.startswith('SCL252_seed'):
        from janus_babel10_lift_family import make_lift
        seed=int(args.instance.removeprefix('SCL252_seed'))
        rows,_=make_lift(cases['SCL126_flip68'],seed)
    else:
        raise KeyError(args.instance)
    start=time.monotonic()
    frequencies,normal,report=active_normal(rows,args.ell)
    report['normal_build_elapsed_seconds_diagnostic']=round(time.monotonic()-start,3)
    report['frequency_sha256']=hashlib.sha256(
        frequencies.astype('<i4').tobytes()).hexdigest()
    print(json.dumps(report,sort_keys=True),flush=True)
    colors,history=refine(normal,args.rounds)
    report['equitable_refinement_history']=history
    report['partition_stable']=history[-1]['stable']
    report['current_partition_cells']=history[-1]['cells']
    report['exact_integer_normal_from_sparse_four_point_cosets']='PASS'
    report['status']=('EXACT_EQUITABLE_QUOTIENT' if report['partition_stable']
                      else 'EXACT_REFINEMENT_LOWER_BOUND_ONLY')
    if args.output:
        args.output.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'instance':args.instance,'ell':args.ell,
                      'status':report['status'],
                      'cells':report['current_partition_cells']},sort_keys=True),flush=True)


if __name__=='__main__':main()
