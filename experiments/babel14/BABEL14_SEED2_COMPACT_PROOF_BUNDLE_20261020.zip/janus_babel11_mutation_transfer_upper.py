#!/usr/bin/env python3
"""Transfer the archived SCL63 integer SOS4 identity to a changed geometry.

This is valid when (i) K_new is a subcode of K_old, (ii) each new cubic row
has the SAME MULTISET of coordinate characters on K_new as the old row with
the same index. An old degree-2 multiplier restricts to degree <=2, and
the identity is independently checked on every frequency over Z.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from janus_babel11_mutation_exact_lower import mutation_case
from janus_babel6_gate import load_base
from janus_babel6_transfer import xor_labels
from janus_babel7_degree_audit import degree_witnesses


def projector(old_labels,new_labels):
    assert len(old_labels)==len(new_labels)
    basis={}
    for x0,y0 in zip(old_labels,new_labels):
        x,y=x0,y0
        while x:
            p=x.bit_length()-1
            if p not in basis:
                basis[p]=(x,y)
                break
            u,v=basis[p]
            x^=u
            y^=v
        else:
            assert y==0, 'new parity kernel is not included in the old kernel'

    def project(q):
        target=0
        while q:
            u,v=basis[q.bit_length()-1]
            q^=u
            target^=v
        return target

    assert all(project(x)==y for x,y in zip(old_labels,new_labels))
    return project


def transfer(seed=0,steps=1):
    original, terms, D=load_base()
    candidate=mutation_case(seed,steps)
    changed=candidate['rows']
    old_labels,_,old_d=xor_labels(original)
    new_labels,_,new_d=xor_labels(changed)
    assert old_d==14 and new_d==candidate['nullity']
    pi=projector(old_labels,new_labels)
    identical=all(sorted(pi(old_labels[c]) for c in original[r])==
                  sorted(new_labels[c] for c in changed[r])
                  for r in range(len(original)))
    assert identical, 'changed row defects differ on the smaller code'
    low=degree_witnesses(new_labels,2)
    newterms=defaultdict(int)
    for (r,u),coeff in terms.items():
        projected=pi(u)
        assert projected in low, 'projection increases multiplier degree'
        newterms[(r,projected)]+=coeff
    newterms={key:c for key,c in newterms.items() if c}
    frequency=defaultdict(int)
    row_l1=[0]*len(changed)
    for (r,u),coeff in newterms.items():
        frequency[u]+=coeff
        for col in changed[r]:
            frequency[u^new_labels[col]]+=coeff
        row_l1[r]+=abs(coeff)
    assert {q:c for q,c in frequency.items() if c}=={0:D}
    C=sum(t*t for t in row_l1)
    assert C>0
    gap=Fraction(D*D,12*C)
    assert gap>0
    return {'format':'BABEL11_RESTRICT_SOURCE_SOS4_INTEGER_IDENTITY_V1',
            'seed':seed,'steps':steps,
            'SHA256_rows':candidate['SHA256_rows'],
            'source_SCL63_character_dim':old_d,
            'new_SCL63_character_dim':new_d,
            'old_row_defects_identical_after_restriction':True,
            'multipliers_degree_at_most_2_verified':True,
            'source_term_count':len(terms),
            'projected_nonzero_integer_multiplier_count':len(newterms),
            'nonzero_integer_frequency_count':1,
            'integer_normalization_D':str(D),
            'integer_row_l1_sq_C':str(C),
            'strict_rational_gap':[str(gap.numerator),str(gap.denominator)],
            'independent_frequency_replay':'PASS',
            'new_SOS_degree_upper_bound':4,
            'source_archived_proof_SHA256':hashlib.sha256(
                Path(__file__).with_name(
                    'babel4c_SCL63_krylov_rational_dual.json').read_bytes()).hexdigest()}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--steps',type=int,default=1)
    p.add_argument('--output',type=Path,
                   default=Path('babel11_MUTATION_SEED0_SOS4_EXACT_TRANSFER.json'))
    args=p.parse_args()
    record=transfer(args.seed,args.steps)
    args.output.write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items()
                      if k not in ('integer_normalization_D',
                                   'integer_row_l1_sq_C','strict_rational_gap')},
                     sort_keys=True),flush=True)


if __name__=='__main__':main()
