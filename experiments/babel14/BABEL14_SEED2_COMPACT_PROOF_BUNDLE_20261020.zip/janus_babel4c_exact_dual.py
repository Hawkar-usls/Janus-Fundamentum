#!/usr/bin/env python3
"""Exact polynomial-calculus kernel identity for BABEL-4c.

The 1450x1450 global degree-4 moment matrix has entries L(chi_p chi_q).
At objective F=-21, each row-defect g=1+chi_a+chi_b+chi_c lies in its
kernel.  We seek integer Y indexed by the 60354 distinct products g*chi_u
such that sum_e Y[e] * g_e == D as a Boolean-group algebra identity.

Exact Krylov arithmetic recovers a certificate of such an identity from the
positive semidefinite normal operator C=A^T A. No floating point is used.
"""

import argparse
import json
from fractions import Fraction
from math import lcm
from pathlib import Path

from janus_babel4c_kernel import kernel_equations, source_data


def equation_origins(defects,basis):
    """One canonical row and degree<=2 character for each distinct product."""
    origins={}
    for row,(a,b,c) in enumerate(defects):
        for u in basis:
            equation=tuple(sorted((u,u^a,u^b,u^c)))
            if equation not in origins:
                origins[equation]=(row,u)
    return origins


def compute_dual_gap(equations,multipliers,defects,basis,denominator):
    origins=equation_origins(defects,basis)
    assert len(origins)==len(equations)
    row_l1=[0]*len(defects)
    for eq,y in zip(equations,multipliers):
        row,_=origins[eq]
        row_l1[row]+=abs(y)
    norm_bound=sum(x*x for x in row_l1)
    assert norm_bound>0
    gap=Fraction(denominator*denominator,12*norm_bound)
    return row_l1,norm_bound,gap


def normal_operator(vector,equations,n=16384):
    out=[0]*n
    for a,b,c,d in equations:
        value=vector[a]+vector[b]+vector[c]+vector[d]
        out[a]+=value
        out[b]+=value
        out[c]+=value
        out[d]+=value
    return out


def pivot_candidate(vector,previous,pivots,prime=1000000007):
    """Detect independent power by a modular column elimination."""
    if not previous:
        return next((i for i,z in enumerate(vector) if z%prime),None)
    # Project out the prior vector columns at their independently chosen pivots.
    # The previous pivot columns form an invertible square submatrix mod prime.
    residual=[int(z%prime) for z in vector]
    for j,index in enumerate(pivots):
        divisor=previous[j][index]%prime
        assert divisor
        factor=residual[index]*pow(divisor,-1,prime)%prime
        if factor:
            base=previous[j]
            for k in range(len(residual)):
                residual[k]=(residual[k]-factor*base[k])%prime
    return next((i for i,z in enumerate(residual) if z),None)


def eliminate_and_find_identity(equations,max_powers=48):
    def rational_solve(matrix,target):
        size=len(matrix)
        aug=[[Fraction(x) for x in line]+[Fraction(b)]
             for line,b in zip(matrix,target)]
        for i in range(size):
            pivot=next(j for j in range(i,size) if aug[j][i])
            aug[i],aug[pivot]=aug[pivot],aug[i]
            divisor=aug[i][i]
            aug[i]=[x/divisor for x in aug[i]]
            for j in range(size):
                if j != i and aug[j][i]:
                    factor=aug[j][i]
                    aug[j]=[a-factor*b for a,b in zip(aug[j],aug[i])]
        return [aug[i][-1] for i in range(size)]
    unit=[0]*16384
    unit[0]=1
    powers=[]
    basis=[]
    pivots=[]
    vector=unit
    for power in range(max_powers+1):
        # Keep an upper-triangular modular elimination basis for pivot search.
        modvector=[x%1000000007 for x in vector]
        for j,index in enumerate(pivots):
            factor=modvector[index]*pow(basis[j][index],-1,1000000007)%1000000007
            if factor:
                modvector=[(x-factor*y)%1000000007
                           for x,y in zip(modvector,basis[j])]
        pivot=next((i for i,x in enumerate(modvector) if x),None)
        if pivot is not None:
            assert power==len(powers)
            powers.append(vector)
            pivots.append(pivot)
            basis.append(modvector)
            print(json.dumps({'new_independent_power':power,
                   'pivot_coordinate':pivot,'integer_magnitude_digits':
                       len(str(max(abs(x) for x in vector)))}),flush=True)
            vector=normal_operator(vector,equations)
            continue
        assert powers
        coeff=rational_solve(
            [[powers[j][i] for j in range(len(powers))] for i in pivots],
            [vector[i] for i in pivots])
        assert all(vector[i]==sum(int(powers[j][i])*coeff[j]
                       for j in range(len(powers))) for i in range(16384))
        assert coeff[0] != 0, 'e0 has nonzero projection to ker(A)'
        # e0=(C^power*e0 - sum_{j>=1} coeff[j] C^j*e0) / coeff[0].
        # Build w with e0=Cw, then y=A w and A^T y=e0.
        scalar=[-c/coeff[0] for c in coeff[1:]]
        scalar.append(Fraction(1)/coeff[0])
        denominator=1
        for c in scalar:
            denominator=lcm(denominator,c.denominator)
        int_scalar=[int(c*denominator) for c in scalar]
        w=[sum(int_scalar[j]*powers[j][i] for j in range(len(int_scalar)))
           for i in range(16384)]
        y=[w[a]+w[b]+w[c]+w[d] for a,b,c,d in equations]
        lhs=[0]*16384
        for coefficient,eq in zip(y,equations):
            if coefficient:
                for q in eq:
                    lhs[q]+=coefficient
        assert lhs[0]==denominator and all(not x for x in lhs[1:])
        return denominator,int_scalar,y,{
            'krylov_minimal_power':power,
            'krylov_identity_coefficients':[str(x) for x in coeff],
            'number_of_nonzero_dual_multipliers':sum(bool(a) for a in y),
            'max_abs_dual_multiplier':max(abs(a) for a in y),
            'sum_abs_dual_multipliers':sum(abs(a) for a in y)}
    raise RuntimeError('Krylov did not terminate at max_powers')


def verify(record):
    _,_,defects,basis=source_data()
    eq=kernel_equations(defects,basis)
    assert record['format']=='BABEL4C_INTEGER_GROUP_ALGEBRA_DUAL_V1'
    assert record['instance']=='SCL63'
    assert record['fourier_moment_domain']==16384
    assert record['moment_matrix_dimension']==1450
    assert record['distinct_equation_count']==len(eq)
    assert record['normalization_D']>0
    coefficients=record['multipliers']
    assert len(coefficients)==len(eq) and all(isinstance(x,int) for x in coefficients)
    aggregate=[0]*16384
    for c,indices in zip(coefficients,eq):
        for index in indices:
            aggregate[index]+=c
    assert aggregate[0]==record['normalization_D']
    assert all(x==0 for x in aggregate[1:])
    _,norm_bound,gap=compute_dual_gap(eq,coefficients,defects,basis,
                                      record['normalization_D'])
    assert record['dual_norm_upper_bound_C']==norm_bound
    assert record['strict_F_gap_numerator']==gap.numerator
    assert record['strict_F_gap_denominator']==gap.denominator
    assert gap>0
    return {'status':'EXACT_INTEGER_GROUP_ALGEBRA_IDENTITY_VERIFIED',
         'instance':'SCL63',
         'identity':'sum(multiplier*(1+chi_a+chi_b+chi_c)*chi_u)=D',
         'D':record['normalization_D'],
         'equations':len(eq),
         'nonzero_multipliers':sum(bool(x) for x in coefficients),
         'global_degree4_PSD_dual_lower_bound_F':
             f'-21+{gap.numerator}/{gap.denominator}',
         'logical_status':'STRICT_RATIONAL_SOS_DUAL_CERTIFICATE'}


def verify_compact(record):
    """Reconstruct the full 60354-term exact dual from only 11 integers."""
    assert record['format']=='BABEL4C_KRYLOV_COMPACT_DUAL_V1'
    _,_,defects,basis=source_data()
    equations=kernel_equations(defects,basis)
    assert len(equations)==record['distinct_equation_count']==60354
    polynomial=record['normal_operator_inverse_polynomial']
    assert len(polynomial)==11 and polynomial[-1]==1
    assert all(type(c) is int for c in polynomial)
    denominator=record['normalization_D']
    assert type(denominator) is int and denominator>0
    e0=[0]*16384
    e0[0]=1
    powers=[e0]
    for _ in range(len(polynomial)):
        powers.append(normal_operator(powers[-1],equations))
    witness=[sum(polynomial[j]*powers[j][q]
                 for j in range(len(polynomial))) for q in range(16384)]
    normal=normal_operator(witness,equations)
    assert normal[0]==denominator and all(v==0 for v in normal[1:])
    y=[sum(witness[q] for q in eq) for eq in equations]
    _,norm_bound,gap=compute_dual_gap(equations,y,defects,basis,denominator)
    assert norm_bound==record['dual_norm_upper_bound_C']
    assert gap==Fraction(record['strict_F_gap_numerator'],
                         record['strict_F_gap_denominator'])
    assert gap>0
    return {'status':'COMPACT_RATIONAL_SOS_DUAL_REPLAYED_EXACTLY',
      'matrix_dimension':1450,'equations':len(equations),
      'group_algebra_coordinates':16384,
      'krylov_integer_terms':len(polynomial),
      'positive_integer_D':denominator,
      'strict_F_lower_bound':f'-21+{gap.numerator}/{gap.denominator}'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--verify',type=Path)
    parser.add_argument('--verify-compact',type=Path)
    parser.add_argument('--compact-output',type=Path)
    parser.add_argument('--max-powers',type=int,default=48)
    args=parser.parse_args()
    if args.verify:
        record=json.loads(args.verify.read_text())
        print(json.dumps(verify(record),indent=2,sort_keys=True))
        return
    if args.verify_compact:
        record=json.loads(args.verify_compact.read_text())
        print(json.dumps(verify_compact(record),indent=2,sort_keys=True))
        return
    _,_,defects,basis=source_data()
    eq=kernel_equations(defects,basis)
    denominator,scalar,y,stats=eliminate_and_find_identity(eq,args.max_powers)
    _,norm_bound,gap=compute_dual_gap(eq,y,defects,basis,denominator)
    record={'format':'BABEL4C_INTEGER_GROUP_ALGEBRA_DUAL_V1',
         'instance':'SCL63','fourier_moment_domain':16384,
         'moment_matrix_dimension':1450,
         'distinct_equation_count':len(eq),
         'normalization_D':denominator,'multipliers':y,
         'dual_norm_upper_bound_C':norm_bound,
         'strict_F_gap_numerator':gap.numerator,
         'strict_F_gap_denominator':gap.denominator,
         'krylov_integer_coefficients':scalar,'discovery_stats':stats}
    print(json.dumps(verify(record),indent=2,sort_keys=True))
    print(json.dumps(stats,indent=2,sort_keys=True))
    if args.output:
        args.output.write_text(json.dumps(record,separators=(',',':'))+'\n')
    if args.compact_output:
        compact={'format':'BABEL4C_KRYLOV_COMPACT_DUAL_V1',
            'instance':'SCL63','moment_matrix_dimension':1450,
            'distinct_equation_count':len(eq),
            'normalization_D':denominator,
            'normal_operator_inverse_polynomial':scalar,
            'dual_norm_upper_bound_C':norm_bound,
            'strict_F_gap_numerator':gap.numerator,
            'strict_F_gap_denominator':gap.denominator}
        print(json.dumps(verify_compact(compact),sort_keys=True))
        args.compact_output.write_text(json.dumps(compact,indent=2,
                                               sort_keys=True)+'\n')


if __name__=='__main__':
    main()
