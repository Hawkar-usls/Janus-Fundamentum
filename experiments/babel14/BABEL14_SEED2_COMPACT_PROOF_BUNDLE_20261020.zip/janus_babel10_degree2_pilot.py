#!/usr/bin/env python3
"""Finite-field-only degree-2 Krylov pilot for all eight balanced lifts.

No rational SOS certificate follows merely from these modular recurrences.
This script MUST NOT be cited as an exact PASS for masks 94/168/169.
"""

import json
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix

from janus_babel8_degree4_probe import all_equations
from janus_babel8_krylov_exact import nextprime
from janus_babel9_krylov_68 import lanczos_for_normal


def main():
    primes = (nextprime(10000019), nextprime(nextprime(10000019)))
    records = []
    for bit in (16, 59, 68, 81, 94, 132, 168, 169):
        eq, qsize = all_equations(bit)
        count = len(eq)
        matrix = coo_matrix((np.ones(4 * count, dtype=np.int64),
                             (eq.ravel(), np.repeat(np.arange(count), 4))),
                            shape=(32768, count)).tocsr()
        c = (matrix @ matrix.T).tocsr()
        observations = []
        for prime in primes:
            coefficients = lanczos_for_normal(c, prime, 1600)
            observations.append({'prime': prime,
                                 'recurrence_degree': len(coefficients) - 1,
                                 'constant_nonzero_mod_prime':
                                 bool(coefficients[0])})
        assert len({v['recurrence_degree'] for v in observations}) == 1
        item = {'flip': bit, 'degree2_character_basis_size': qsize,
                'number_of_fourier_products': count,
                'modular_recurrences': observations,
                'scientific_status': 'MODULAR_DIAGNOSTIC_ONLY'}
        records.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)
    Path('babel10_EIGHT_SOS4_MODULAR_PILOT.json').write_text(
        json.dumps(records, sort_keys=True, indent=2) + '\n')


if __name__ == '__main__':
    main()
