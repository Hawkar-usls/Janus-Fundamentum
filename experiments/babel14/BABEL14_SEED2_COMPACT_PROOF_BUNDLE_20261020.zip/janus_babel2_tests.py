#!/usr/bin/env python3
"""Independent small exhaustive, proof corruption and factorisation checks."""

import copy
import json
from pathlib import Path

from janus_occam_replay import source_triples
from janus_occam_solver import gf2_kernel,validate
from janus_babel2_solver import certified_minimum
from janus_babel2_verify import verify
from janus_babel2_factor import prove as factor_prove
from janus_babel2_factor_verify import verify as factor_verify
from janus_babel2_triangle_barrier import exact_rank2_barrier


def nine_point_scl():
    return ([[(3*i+j) for j in range(3)] for i in range(3)] +
            [[(3*i+j) for i in range(3)] for j in range(3)] +
            [[(3*i+j) for i in range(3) for j in range(3)
              if (i+j)%3==k] for k in range(3)])


def rejects(checker,corrupted):
    try:
        checker(corrupted)
    except (AssertionError,ValueError,KeyError,TypeError):
        return
    raise AssertionError('an invalid proof was accepted')


def main():
    nine=nine_point_scl()
    _,basis=gf2_kernel(validate(nine,9),9)
    cert9=certified_minimum(nine,block_width=2)
    got9=verify(cert9)
    weight_scores=[]
    for c in range(1<<len(basis)):
        w=0
        for i,b in enumerate(basis):
            if c&(1<<i):
                w^=b
        weight_scores.append(9-2*w.bit_count())
    assert got9['minimum_F']==min(weight_scores)==-3

    source=source_triples(Path(__file__).with_name('tutte12.am.csv'))
    cert63=certified_minimum(source,block_width=4)
    got63=verify(cert63)
    assert (got63['minimum_F'],got63['minimum_defect'])==(-17,3)
    assert exact_rank2_barrier(source)['rank2_optimum_integer_if_divisible3']==-21

    broken=copy.deepcopy(cert63)
    broken['proof_leaves'][0][2]+=2
    rejects(verify,broken)
    broken=copy.deepcopy(cert63)
    broken['proof_leaves'].pop()
    broken['proof_leaf_count']-=1
    rejects(verify,broken)
    broken=copy.deepcopy(cert63)
    broken['witness_selector_hex']=hex(int(broken['witness_selector_hex'],16)^1)
    rejects(verify,broken)
    broken=copy.deepcopy(cert63)
    for leaf in broken['proof_leaves']:
        if leaf[1]=='xor3' and leaf[3]:
            leaf[3][0][2]^=1
            break
    else:
        raise AssertionError('no XOR3 leaf for tamper test')
    rejects(verify,broken)

    double=[[j+63*k for j in row] for k in range(2) for row in source]
    factor=factor_prove(double,block_width=0)
    gotfactor=factor_verify(factor)
    assert gotfactor['global_nullity']==28
    assert gotfactor['exact_minimum_F']==-34
    broken=copy.deepcopy(factor)
    broken['components'][0]['variables'][0]=63
    rejects(factor_verify,broken)

    print(json.dumps({'nine_SAT':got9,'source63_UNSAT':got63,
                      '2xSCL63_factor':gotfactor,
                      'corruption_cases_rejected':5,
                      'small_full_enumeration':'PASS'},sort_keys=True,indent=2))


if __name__=='__main__':
    main()
