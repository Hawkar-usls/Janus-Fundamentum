#!/usr/bin/env python3
"""Exact linear relation between degree-2 Fourier labels of SCL63/126.

The 15-dimensional parity kernel of the UNSAT cover contains the
14-dimensional diagonal lift of the SCL63 kernel. Restricting Fourier
characters to that subspace induces a linear map GF(2)^15 -> GF(2)^14.
"""

import json
from collections import Counter
from itertools import combinations

from janus_babel4c_kernel import source_data as data63
from janus_babel5_kernel import source_data as data126


def linear_projection():
    _,base_q,_,base_Q=data63()
    _,cover_q,_,cover_Q=data126()
    red={}
    for sheet in (0,1):
        for i in range(63):
            x=cover_q[63*sheet+i]
            y=base_q[i]
            while x:
                p=x.bit_length()-1
                if p not in red:
                    red[p]=(x,y)
                    break
                a,b=red[p]
                x^=a
                y^=b
            else:
                assert y==0
    assert len(red)==15

    def apply(x):
        y=0
        while x:
            p=x.bit_length()-1
            a,b=red[p]
            x^=a
            y^=b
        return y

    assert all(apply(cover_q[i])==base_q[i%63] for i in range(126))
    extra=[q for q in range(1,1<<15) if apply(q)==0]
    assert len(extra)==1
    e=extra[0]
    assert any((cover_q[i]^cover_q[63+i])==e for i in range(63))
    Qset=set(cover_Q)
    fiber_counts=Counter(apply(q) for q in cover_Q)
    all_values=set(base_Q)
    outside=[q for q in fiber_counts if q not in all_values]
    assert not outside
    return apply,e,{
            'base_basis_size':len(base_Q),
            'cover_basis_size':len(cover_Q),
            'extra_frequency':e,
            'extra_frequency_is_degree2':e in Qset,
            'base_frequencies_with_zero_lifts':len(all_values-set(fiber_counts)),
            'base_frequencies_with_one_lift':sum(v==1 for v in fiber_counts.values()),
            'base_frequencies_with_two_lifts':sum(v==2 for v in fiber_counts.values()),
            'base_pairwise_character_labels':len(set(base_q)),
            'cover_pairwise_character_labels':len(set(cover_q))}


def projection():
    _,_,summary=linear_projection()
    return summary


if __name__=='__main__':
    print(json.dumps(projection(),indent=2,sort_keys=True))
