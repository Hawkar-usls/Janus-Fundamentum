#!/usr/bin/env python3
"""Independent exact verifier of overlapping rank3 XOR-packet BABEL-3 proofs.

Its packet validator enumerates all 2^3 consistent signs directly, without
using the packet optimizer or its internal basis/span representation.
"""

import argparse
import json
from collections import Counter, defaultdict
from itertools import combinations, product
from pathlib import Path

from janus_occam_solver import gf2_kernel, validate


FORMAT = 'JANUS_BABEL3_OVERLAP5_XOR3_BLOCK_v1'


def packet_exact_gain(coeff, group):
    assert isinstance(group, list) and len(group) in (3, 5)
    assert all(type(q) is int and q > 0 and coeff[q] != 0 for q in group)
    assert len(set(group)) == len(group)
    lines = [tuple(comb) for comb in combinations(group, 3)
             if comb[0] ^ comb[1] ^ comb[2] == 0]
    if len(group) == 3:
        assert len(lines) == 1
    else:
        assert len(lines) == 2
        assert len(set(lines[0]) & set(lines[1])) == 1
    positions = {q: i for i, q in enumerate(group)}
    consistent = []
    for signs in product((-1, 1), repeat=len(group)):
        if all(signs[positions[a]] * signs[positions[b]] * signs[positions[c]] == 1
               for a, b, c in lines):
            consistent.append(sum(coeff[q]*signs[positions[q]] for q in group))
    assert len(consistent) == (4 if len(group) == 3 else 8)
    return min(consistent) + sum(abs(coeff[q]) for q in group)


def verify(cert):
    if not __debug__:
        raise RuntimeError('run without Python -O; exact assertions needed')
    assert cert['format'] == FORMAT
    n = cert['n']
    rows = validate(cert['row_triples'], n)
    pivots, basis = gf2_kernel(rows, n)
    d = len(basis)
    assert (len(pivots), d) == (cert['rank_GF2'], cert['nullity_GF2'])
    order = cert['basis_bit_order']
    assert sorted(order) == list(range(d))
    width = cert['block_width']
    assert type(width) is int and 0 <= width <= d
    selector = int(cert['witness_selector_hex'], 16)
    assert 0 <= selector < (1 << d)
    witness = 0
    for k, v in enumerate(basis):
        if selector & (1 << k):
            witness ^= v
    assert cert['witness_kernel_word_hex'] == hex(witness)
    optimum = n - 2*witness.bit_count()
    assert optimum == cert['minimum_F']
    x = ((1 << n)-1) ^ witness
    sat = all((r & x).bit_count() == 1 for r in rows)
    assert sat == (n % 3 == 0 and optimum == -(n // 3))
    assert cert['exact_one_status'] == ('SAT' if sat else 'UNSAT')
    if sat:
        assert cert['witness_true_variables'] == [j for j in range(n) if x & (1<<j)]
    else:
        assert 'witness_true_variables' not in cert
    columns = [sum(((v >> j) & 1) << k for k, v in enumerate(basis))
               for j in range(n)]
    assert optimum == sum(-1 if (q & selector).bit_count() & 1 else 1
                          for q in columns)

    trie = {}
    checked_p3 = checked_p5 = checked_blocks = covered = 0
    modes = Counter()
    assert len(cert['proof_leaves']) == cert['proof_leaf_count'] >= 1
    for path, mode, reported_bound, packets in cert['proof_leaves']:
        assert isinstance(path, str) and len(path) <= d
        assert set(path).issubset({'0', '1'})
        node = trie
        for v in path:
            assert '#' not in node
            node = node.setdefault(v, {})
        assert not node
        node['#'] = True
        covered += 1 << (d-len(path))
        modes[mode] += 1
        fixed = selected = 0
        for k, char in enumerate(path):
            fixed |= 1 << order[k]
            if char == '1':
                selected |= 1 << order[k]
        coeff = defaultdict(int)
        for q in columns:
            coeff[q & ~fixed] += (-1 if (q & selected).bit_count() & 1 else 1)
        if mode == 'overlap':
            baseline = coeff[0] - sum(abs(a) for q, a in coeff.items() if q)
            used = set()
            gain = 0
            for group in packets:
                assert used.isdisjoint(group)
                used.update(group)
                gain += packet_exact_gain(coeff, group)
                assert gain >= 0
                if len(group) == 3:
                    checked_p3 += 1
                else:
                    checked_p5 += 1
            lower = baseline + gain
        elif mode == 'block':
            assert not packets
            rem = d - len(path)
            assert rem <= width
            outcomes = []
            for mask in range(1<<rem):
                extension = sum(((mask >> j) & 1) << order[len(path)+j]
                                for j in range(rem))
                outcomes.append(sum(a * (-1 if (q & extension).bit_count() & 1 else 1)
                                    for q, a in coeff.items()))
                checked_blocks += 1
            lower = min(outcomes)
        else:
            raise ValueError(f'unknown leaf mode {mode!r}')
        assert lower == reported_bound
        assert lower >= optimum, (path, lower, optimum)
    assert covered == 1 << d == cert['symbolically_covered_selectors']
    assert checked_p5 == cert['overlap5_packets_in_proof']
    return {'status':'PROVED_EXACT_MINIMUM', 'n':n,'rank':len(pivots), 'nullity':d,
            'minimum_F':optimum,'exact_one_status':'SAT' if sat else 'UNSAT',
            'proof_leaves':len(cert['proof_leaves']),
            'leaf_methods':dict(sorted(modes.items())),
            'xor_triples_verified':checked_p3,
            'overlapping_five_term_packets_verified':checked_p5,
            'local_scores_verified':checked_blocks,
            'selectors_covered':covered}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('certificate', type=Path)
    args=p.parse_args()
    print(json.dumps(verify(json.loads(args.certificate.read_text())),
                     indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
