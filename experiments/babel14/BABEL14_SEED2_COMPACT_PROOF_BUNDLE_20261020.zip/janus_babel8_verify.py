#!/usr/bin/env python3
"""Clean-room exact integer verifier of BABEL-8 degree-six SOS duals.

This file imports no certificate builder, CRT routine or coset solver.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path

from janus_occam_replay import cover, source_triples
from janus_occam_solver import gf2_kernel, validate


def low_degree_symbols(labels, degree):
    levels = {0: 0}
    current = {0}
    for d in range(1, degree + 1):
        future = set()
        for u in current:
            for symbol in labels:
                q = u ^ symbol
                if q not in levels:
                    future.add(q)
        for q in future:
            levels[q] = d
        current = future
    return levels


def verify(path):
    rec = json.loads(Path(path).read_text())
    assert rec['format'] == 'JANUS_BABEL8_BALANCED_UNSAT126_DEGREE6_SOS_DUAL_V1'
    bit = rec['flipped_base_edge_index']
    assert 0 <= bit < 189
    csv = Path(__file__).with_name('tutte12.am.csv')
    assert hashlib.sha256(csv.read_bytes()).hexdigest() == rec['source_csv_sha256']
    original = source_triples(csv)
    known_mask = int('f3f8bcef56c536a5d5a2a6967e9947a803340bba408e0c5', 16)
    assert rec['cover_mask_hex'] == format(known_mask ^ (1 << bit), 'x')
    lifted = cover(original, rec['cover_mask_hex'])
    validate(lifted, 126)
    _, K = gf2_kernel(validate(lifted, 126), 126)
    assert len(K) == 15
    labels = [sum(((v >> j) & 1) << a for a, v in enumerate(K))
              for j in range(126)]
    representable = low_degree_symbols(labels, 3)
    assert len(representable) >= 1

    accum = defaultdict(int)
    per_row = [0] * 126
    seen = set()
    for r, u, y in rec['terms']:
        assert type(r) is int and 0 <= r < 126
        assert type(u) is int and u in representable
        assert type(y) is int and y
        assert (r, u) not in seen
        seen.add((r, u))
        per_row[r] += abs(y)
        accum[u] += y
        for j in lifted[r]:
            accum[u ^ labels[j]] += y
    D = rec['normalization_D']
    C = sum(value * value for value in per_row)
    assert type(D) is int and D > 0
    assert {u: v for u, v in accum.items() if v} == {0: D}
    assert C == rec['dual_norm_upper_bound_C']
    assert rec['SOS_degree'] == 6
    assert rec['multiplier_character_degree'] == 3
    gap = Fraction(D * D, 12 * C)
    assert gap == Fraction(rec['strict_gap_numerator'],
                           rec['strict_gap_denominator'])
    assert gap > 0
    return {'status': 'BABEL8_CLEANROOM_EXACT_DEGREE6_SOS_PASS',
            'flipped_base_edge_index': bit,
            'number_of_rows': 126,
            'nullity': len(K),
            'moment_matrix_basis_size': len(representable),
            'nonzero_integer_terms': len(seen),
            'exact_group_ring_additions': 4 * len(seen),
            'D': str(D), 'C': str(C),
            'strict_F_lower_bound': f'-42+{gap}'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    reports = [verify(path) for path in args.files]
    if args.output:
        args.output.write_text(json.dumps(reports, indent=2,
                                          sort_keys=True) + '\n')
    print(json.dumps(reports, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
