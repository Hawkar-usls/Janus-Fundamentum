#!/usr/bin/env python3
"""Exact degree-4 SOS via modular Lanczos and integer CRT reconstruction.

CERTIFICATION RULE: A modular recurrence is not a proof. The published
integer recurrence must pass an exact all-frequency normal-operator replay.
"""

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix
from janus_babel8_degree4_probe import all_equations


def nextprime(x):
    candidate = x + 1 if x % 2 == 0 else x + 2
    while True:
        prime = True
        for factor in range(3, int(candidate ** .5) + 1, 2):
            if candidate % factor == 0:
                prime = False
                break
        if prime:
            return candidate
        candidate += 2


def matrices(bit=16):
    eq, qcount = all_equations(bit)
    n_eq = len(eq)
    matrix = coo_matrix((np.ones(4 * n_eq, dtype=np.int64),
                         (eq.ravel(), np.repeat(np.arange(n_eq), 4))),
                        shape=(32768, n_eq)).tocsr()
    normal_bound = int(np.max(4 * np.bincount(
        eq.ravel(), minlength=32768)))
    return eq, matrix, matrix.T.tocsr(), qcount, normal_bound


def lanczos_prime(matrix, transpose, prime, max_powers=700):
    assert prime < 16000000
    old = np.zeros(32768, dtype=np.int64)
    current = old.copy()
    current[0] = 1
    oldnorm = 0
    previous_polynomial = [0]
    polynomial = [1]
    alphas = []
    betas = []
    for step in range(max_powers):
        qnorm = int(np.dot(current, current)) % prime
        if not qnorm:
            raise ArithmeticError(f'isotropic norm at step {step} prime={prime}')
        evaluated = matrix.dot(transpose.dot(current)) % prime
        alpha = int(np.dot(current, evaluated)) % prime
        alpha = alpha * pow(qnorm, -1, prime) % prime
        beta = qnorm * pow(oldnorm, -1, prime) % prime if step else 0
        # Keep intermediate vector products in signed 64-bit range.
        following = (evaluated - alpha * current - beta * old) % prime
        nextpolynomial = [0] * (len(polynomial) + 1)
        for j, c in enumerate(polynomial):
            nextpolynomial[j] = (nextpolynomial[j] - alpha * c) % prime
            nextpolynomial[j + 1] = (nextpolynomial[j + 1] + c) % prime
        for j, c in enumerate(previous_polynomial):
            nextpolynomial[j] = (nextpolynomial[j] - beta * c) % prime
        previous_polynomial, polynomial = polynomial, nextpolynomial
        alphas.append(alpha)
        betas.append(beta)
        if not np.any(following):
            return polynomial, {'steps': step + 1,
                                'constant_nonzero': bool(polynomial[0])}
        old, current = current, following
        oldnorm = qnorm
    return None, {'steps': max_powers, 'terminated': False}


def reconstruct_polynomial(max_primes=None, output=None, bit=16):
    eq, matrix, transpose, qcount, bound = matrices(bit)
    modulus = 1
    crt = []
    completed = []
    exception_count = 0
    prime = 10000019
    theoretical_limit = None
    for index in range(max_primes or 400):
        prime = int(nextprime(prime))
        try:
            residue, diagnostics = lanczos_prime(matrix, transpose, prime)
        except ArithmeticError:
            exception_count += 1
            continue
        if residue is None or len(residue) != 246:
            exception_count += 1
            continue
        if not crt:
            crt = [0] * len(residue)
            theoretical_limit = 2 * pow(bound + 1, 245)
        inverse = pow(modulus % prime, -1, prime)
        for j, value in enumerate(residue):
            t = ((value - crt[j]) % prime) * inverse % prime
            crt[j] += t * modulus
        modulus *= prime
        completed.append(prime)
        if len(completed) % 10 == 0:
            print(json.dumps({'primes': len(completed),
                              'bit_size_of_modulus': modulus.bit_length(),
                              'required_bits_for_rigorous_CRT':
                              theoretical_limit.bit_length(),
                              'constant_nonzero_mod_last_prime':
                              bool(residue[0])}), flush=True)
        if modulus > theoretical_limit:
            break
    if not crt:
        return {'status': 'NO_KRYLOV_POLYNOMIAL_RECONSTRUCTED_WITHIN_LIMIT',
                'bit': bit, 'modular_exceptions': exception_count,
                'attempted_primes': max_primes or 400}
    completed_exactly = modulus > theoretical_limit
    polynomial = [int(a if a <= modulus // 2 else a - modulus)
                  for a in crt]
    assert polynomial and polynomial[-1] == 1
    result = {'format': 'BABEL8_INTEGER_KRYLOV_DEGREE4_CERTIFICATE_V1',
              'degree_of_recurrence': len(polynomial) - 1,
              'normal_operator_row_sum_bound': bound,
              'theoretical_CRT_coefficient_bound_expression':
              f'({bound}+1)^{len(polynomial)-1}',
              'CRT_modulus_exceeds_twice_coefficient_bound': completed_exactly,
              'CRT_modulus_digits': len(str(modulus)),
              'prime_count': len(completed),
              'modular_exceptions': exception_count,
              'number_of_distinct_row_products': len(eq),
              'degree2_fourier_basis_size': qcount,
              'polynomial_coefficients_low_to_high': polynomial}
    if bit != 16:
        result['flipped_base_edge_index'] = bit
    if output is not None:
        output.write_text(json.dumps(result, separators=(',', ':'),
                                     sort_keys=True) + '\n')
    return {k: v for k, v in result.items()
            if k != 'polynomial_coefficients_low_to_high'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--max-primes', type=int, default=160)
    p.add_argument('--bit', type=int, default=16)
    p.add_argument('--output', type=Path,
                   default=Path(__file__).with_name(
                       'babel8_DEGREE4_KRYLOV_RATIONAL_DUAL.json'))
    args = p.parse_args()
    print(json.dumps(reconstruct_polynomial(args.max_primes, args.output,
                                            args.bit),
                     indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
