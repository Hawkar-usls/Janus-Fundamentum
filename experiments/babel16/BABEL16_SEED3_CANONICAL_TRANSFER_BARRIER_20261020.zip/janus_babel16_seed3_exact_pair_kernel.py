#!/usr/bin/env python3
"""BABEL-16 exploratory exact Q-left-kernel for the *paired* seed3 subspace.

This is NOT a left-kernel certificate for the full degree-2 SCL matrix.
It only tests the anti-sector paired-character correction generators after
the automatically-zero base-source coordinates have been quotiented out.
"""

import argparse
import json
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators, modular_rank
from janus_babel15_sector_quotient import forced_source_zero_coordinates


class WeightedUnion:
    def __init__(self, n):
        self.parent = list(range(n))
        self.weight = [Fraction(1)] * n
        self.zero = set()
        self.union_count = 0

    def find(self, i):
        p = self.parent[i]
        if i == p:
            return p, self.weight[i]
        root, scale = self.find(p)
        self.weight[i] *= scale
        self.parent[i] = root
        return root, self.weight[i]

    def set_zero(self, i):
        root, _ = self.find(i)
        if root in self.zero:
            return False
        self.zero.add(root)
        return True

    def union(self, i, a, j, b):
        ri, wi = self.find(i)
        rj, wj = self.find(j)
        if ri == rj:
            if a * wi + b * wj:
                return self.set_zero(i)
            return False
        # a*wi*y_ri + b*wj*y_rj = 0
        self.parent[ri] = rj
        self.weight[ri] = -(b * wj) / (a * wi)
        if ri in self.zero or rj in self.zero:
            self.zero.discard(ri)
            self.zero.add(rj)
        self.union_count += 1
        return True


def compress_equation(uf, equation):
    coefficients = defaultdict(Fraction)
    for i, c in equation:
        root, scale = uf.find(i)
        if root not in uf.zero:
            coefficients[root] += c * scale
    return [(r, c) for r, c in sorted(coefficients.items()) if c]


def audit(seed=3, max_rounds=12):
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(seed)
    signatures, _, _, _ = extra_generators(source, lift, labels, Q, e, canonical, missing)
    forced, _ = forced_source_zero_coordinates(source, lift, labels, Q, canonical, missing)
    remaining = [q for q in missing if q not in forced]
    index = {q: i for i, q in enumerate(remaining)}
    equations = []
    for sig in signatures:
        row = [(index[missing[j]], Fraction(v))
               for j, v in sig if missing[j] in index]
        if row:
            equations.append(row)
    reduced_signatures = {}
    for eq in equations:
        key = tuple((i, int(c)) for i, c in eq)
        reduced_signatures.setdefault(key, (0, 0))
    modular_lower_bound, _, _ = modular_rank(reduced_signatures, len(remaining))
    print(f'seed {seed}: exact paired-signature equations={len(equations)}, variables={len(remaining)}',flush=True)
    uf = WeightedUnion(len(remaining))
    history = []
    for attempt in range(max_rounds):
        changed = 0
        complex_eq = 0
        for eq in equations:
            row = compress_equation(uf, eq)
            if len(row) == 1:
                changed += uf.set_zero(row[0][0])
            elif len(row) == 2:
                (i, a), (j, b) = row
                changed += uf.union(i, a, j, b)
            elif len(row) > 2:
                complex_eq += 1
        surviving = {uf.find(i)[0] for i in range(len(remaining))}
        surviving -= uf.zero
        item = {'round': attempt + 1, 'change_operations': changed,
                'surviving_weighted_components': len(surviving),
                'nonbinary_residual_equations': complex_eq}
        history.append(item)
        print(json.dumps(item), flush=True)
        if not changed:
            break
    final = [compress_equation(uf, eq) for eq in equations]
    unresolved = [row for row in final if len(row) > 2]
    roots = sorted({uf.find(i)[0] for i in range(len(remaining))} - uf.zero)
    result = {'gate':'BABEL-16_EXPLORATORY', 'seed':seed,
              'complete_antisector_after_source_quotient_variables':len(remaining),
              'original_paired_generator_equations':len(equations),
              'prime_modulus':65521,
              'modular_rank_lower_bound_for_rational_rank':modular_lower_bound,
              'source_forced_zero':len(forced),
              'weighted_components_surviving':len(roots),
              'remaining_nonbinary_equations':len(unresolved),
              'history':history,
              'scientific_limit':'This is only the paired-generator projection. No full degree-2 impossibility claim.'}
    if not unresolved:
        kernels=[]
        for root in roots:
            sparse=[]
            for i,q in enumerate(remaining):
                r,w = uf.find(i)
                if r == root:
                    sparse.append([q, str(w)])
            assert sparse
            kernels.append(sparse)
        # Exact exhaustive verification of every original sparse equation.
        for kernel in kernels:
            terms={index[q]: Fraction(w) for q,w in kernel}
            for eq in equations:
                assert not sum((coeff * terms.get(i, 0) for i, coeff in eq), Fraction(0))
        result['exact_rational_independent_leftkernel_vectors']=len(kernels)
        result['exact_all_paired_equations_annihilated']=True
        assert modular_lower_bound + len(kernels) == len(remaining), (
            'Exact kernel and modular lower rank do not yet close the dimension')
        result['exact_rational_paired_projection_rank']=modular_lower_bound
        result['exact_rational_paired_projection_nullity']=len(kernels)
        result['kernel_vectors_sparse']=kernels
        result['status']='EXACT_Q_PAIRED_PROJECTION_LEFTKERNEL_PASS'
    else:
        result['status']='EXACT_Q_PAIRED_KERNEL_NOT_YET_FINISHED'
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--seed',type=int,default=3)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    proof=audit(args.seed)
    if args.output:
        args.output.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items() if k!='kernel_vectors_sparse'},sort_keys=True,indent=2),flush=True)
