#!/usr/bin/env python3
"""Regression assertions on the narrow BABEL-16 transfer obstruction."""

import json
import unittest
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators
from janus_babel15_sector_quotient import forced_source_zero_coordinates

HERE = Path(__file__).resolve().parent
FREQUENCIES = [7984, 16142, 16156, 31072, 33062, 55754, 59828]


class Babel16Exact(unittest.TestCase):
    def test_01_rational_rank_sandwich(self):
        cert = json.loads((HERE/'babel16_SEED3_EXACT_PAIRED_KERNEL.json').read_text())
        self.assertEqual(cert['exact_rational_paired_projection_rank'], 5119)
        self.assertEqual(cert['exact_rational_paired_projection_nullity'], 7)
        self.assertTrue(cert['exact_all_paired_equations_annihilated'])
        self.assertEqual(cert['modular_rank_lower_bound_for_rational_rank'],5119)
        self.assertEqual([x[0][0] for x in cert['kernel_vectors_sparse']], FREQUENCIES)

    def test_02_independent_all_generator_supports_miss_seven(self):
        source,lift,labels,Q,e,canonical,touched,active,missing=prepare(3)
        signatures,_,_,_=extra_generators(source,lift,labels,Q,e,canonical,missing)
        forced,_=forced_source_zero_coordinates(source,lift,labels,Q,canonical,missing)
        self.assertEqual(len(forced),483)
        self.assertFalse(set(FREQUENCIES) & forced)
        indexes={i for i,q in enumerate(missing) if q in FREQUENCIES}
        self.assertEqual(len(indexes),7)
        self.assertEqual(len(signatures),43485)
        self.assertTrue(all(not any(i in indexes for i,_ in sig) for sig in signatures))

    def test_03_persisted_integer_residual(self):
        report=json.loads((HERE/'babel16_SEED3_SOURCE_RESIDUAL.json').read_text())
        self.assertEqual(report['status'],'CANONICAL_BASE_TRANSFER_HAS_UNCORRECTABLE_PAIRED_RESIDUAL')
        self.assertEqual(report['nonzero_residual_frequencies'],[16142,16156,31072,55754,59828])
        self.assertEqual(report['paired_generator_invisible_frequencies'],FREQUENCIES)
        errors=report['unrestricted_integer_residual']
        self.assertEqual([int(errors[str(q)])==0 for q in FREQUENCIES],
                         [True,False,False,False,True,False,False])


if __name__ == '__main__':
    unittest.main(verbosity=2)
