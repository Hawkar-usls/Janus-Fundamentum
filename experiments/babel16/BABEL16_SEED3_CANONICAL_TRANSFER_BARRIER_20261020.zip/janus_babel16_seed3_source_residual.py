#!/usr/bin/env python3
"""Check exact seed3 errors at the seven paired-generator-invisible frequencies.

This diagnoses only the canonical lift of a particular frozen source Krylov
certificate. Nonzero error means *that lift* cannot be corrected by paired
generators; it does not imply SOS4 is impossible for the full system.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators
from janus_babel15_sector_quotient import forced_source_zero_coordinates
from janus_babel6_transfer import make_projection
from janus_babel8_krylov_verify import input_data, normal


def run():
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(3)
    signatures, _, _, _ = extra_generators(source, lift, labels, Q, e, canonical, missing)
    forced, _ = forced_source_zero_coordinates(source, lift, labels, Q, canonical, missing)
    frozen = Path(__file__).with_name('babel16_SEED3_EXACT_PAIRED_KERNEL.json')
    kernel = json.loads(frozen.read_text())
    witness = kernel['kernel_vectors_sparse']
    assert len(witness) == 7 and all(len(w) == 1 and w[0][1] == '1' for w in witness)
    seven = [w[0][0] for w in witness]
    assert not set(seven) & forced
    missing_indices = {q: i for i, q in enumerate(missing)}
    invisible = {missing_indices[q] for q in seven}
    assert all(not any(i in invisible for i, _ in signature)
               for signature in signatures)

    rows, src_labels, src_basis, eq, origins = input_data(68)
    assert rows == source
    pi, _ = make_projection(src_labels, labels, 15, 16)
    reps = {}
    for u in sorted(Q):
        reps.setdefault(pi(u), u)
    assert set(reps) == set(src_basis)
    polynomial_path = Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    poly = json.loads(polynomial_path.read_text())['polynomial_coefficients_low_to_high']
    P0 = poly[0]
    v = [0] * 32768
    for step, c in enumerate(reversed(poly[1:])):
        v = normal(v, eq)
        v[0] += c
        if (step + 1) % 100 == 0:
            print(f'seed3 source Krylov Horner {step+1}/{len(poly)-1}', flush=True)
    check = normal(v, eq)
    assert check[0] == -P0 and not any(check[1:])
    sign = -1 if P0 > 0 else 1
    residual = defaultdict(int)
    for a, b, c, d in eq:
        r, u0 = origins[(a, b, c, d)]
        coeff = 4 * sign * (v[a] + v[b] + v[c] + v[d])
        if not coeff:
            continue
        u = reps[u0]
        for z in (u, *(u ^ labels[j] for j in lift[r])):
            q, orient = canonical(z)
            if q in seven:
                residual[q] += orient * coeff
    return {
        'gate': 'BABEL-16_SOURCE_RESIDUAL',
        'seed': 3,
        'source_polynomial_sha256': hashlib.sha256(polynomial_path.read_bytes()).hexdigest(),
        'checked_paired_generator_signatures': len(signatures),
        'paired_generator_invisible_frequencies': seven,
        'unrestricted_integer_residual': {str(q): str(residual[q]) for q in seven},
        'nonzero_residual_frequencies': [q for q in seven if residual[q]],
        'status': ('CANONICAL_BASE_TRANSFER_HAS_UNCORRECTABLE_PAIRED_RESIDUAL'
                   if any(residual[q] for q in seven)
                   else 'CANONICAL_BASE_TRANSFER_PASSES_SEVEN_INVISIBLE_FREQUENCIES'),
        'important_scope': 'Only fixed source certificate and paired-generator correction. No full SOS4 lower bound or P-vs-NP inference.'
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path)
    args = ap.parse_args()
    result = run()
    if args.output:
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k!='unrestricted_integer_residual'},indent=2,sort_keys=True),flush=True)
