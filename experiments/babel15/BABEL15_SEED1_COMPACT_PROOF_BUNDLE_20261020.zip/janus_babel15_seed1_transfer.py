#!/usr/bin/env python3
"""BABEL-15: construct an exact rational degree-2 transfer *scheme* for seed 1.

The source recurrence is independently replayed elsewhere. This file proves
that every possible anti-deck error from lifting a valid source identity can
be cancelled over Q using legal degree-2 multipliers. It uses an exact tiny
8x8 determinant, not an approximate rank or SDP heuristic.
"""

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators
from janus_babel14_exact_transfer import signed_forest
from janus_babel15_sector_quotient import forced_source_zero_coordinates
from janus_babel6_transfer import signed_graph


def exact_determinant(rows):
    n = len(rows)
    a = [list(row) for row in rows]
    sign = 1
    previous = 1
    for k in range(n - 1):
        if a[k][k] == 0:
            j = next((j for j in range(k + 1, n) if a[j][k]), None)
            if j is None:
                return 0
            a[k], a[j] = a[j], a[k]
            sign = -sign
        pivot = a[k][k]
        for i in range(k + 1, n):
            for j in range(k + 1, n):
                numerator = a[i][j] * pivot - a[i][k] * a[k][j]
                assert numerator % previous == 0
                a[i][j] = numerator // previous
        for i in range(k + 1, n):
            a[i][k] = 0
        previous = pivot
    return sign * a[-1][-1]


def choose_eight(signatures, missing, remaining_eight, modulus=65521):
    indices = {q: i for i, q in enumerate(remaining_eight)}
    pivots = {}
    selected = []
    for sig, (r, u) in sorted(signatures.items(), key=lambda t: (len(t[0]), t[0])):
        raw = {indices[missing[j]]: value
               for j, value in sig if missing[j] in indices}
        if not raw:
            continue
        v = {j: c % modulus for j, c in raw.items() if c % modulus}
        while v:
            first = min(v)
            if first not in pivots:
                inv = pow(v[first], -1, modulus)
                pivots[first] = {j: (c * inv) % modulus for j, c in v.items()}
                selected.append({'row': r, 'multiplier': u,
                                 'signature': [[remaining_eight[j], raw.get(j, 0)]
                                               for j in range(len(remaining_eight))
                                               if raw.get(j, 0)]})
                break
            coeff = v[first]
            for j, z in pivots[first].items():
                new = (v.get(j, 0) - coeff * z) % modulus
                if new:
                    v[j] = new
                else:
                    v.pop(j, None)
        if len(selected) == len(remaining_eight):
            break
    matrix = [[next((v for q, v in selected[col]['signature'] if q == row), 0)
               for col in range(len(selected))] for row in remaining_eight]
    return selected, matrix


def construct(seed=1):
    assert seed == 1
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(seed)
    assert len(missing) == 826
    signatures, supports, singleton, processed = extra_generators(
        source, lift, labels, Q, e, canonical, missing
    )
    forced, classification = forced_source_zero_coordinates(
        source, lift, labels, Q, canonical, missing
    )
    assert len(forced) == 210 and len(singleton) == 608
    assert not {missing[j] for j in singleton} & forced
    remaining_eight = [q for q in missing if q not in forced and q not in {missing[j] for j in singleton}]
    assert len(remaining_eight) == 8
    selected, matrix = choose_eight(signatures, missing, remaining_eight)
    det = exact_determinant(matrix)
    assert len(selected) == 8 and det != 0
    print(f'8x8 exact determinant: {det}; remaining frequencies: {remaining_eight}',flush=True)

    row_edges = signed_graph(source, lift, labels, e)[2]
    forest, chords, roots = signed_forest(row_edges, Q, labels, canonical, touched)
    assert len(forest) + len(chords) == len(touched)
    frozen = Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    poly = json.loads(frozen.read_text())
    assert poly['degree_of_recurrence'] == 556 and poly['polynomial_coefficients_low_to_high'][0]
    return {
        'format': 'JANUS_BABEL15_SEED1_EXACT_RATIONAL_DEGREE2_TRANSFER_SCHEME_V1',
        'seed': 1,
        'source': 'SCL126_flip68',
        'n': 252,
        'extra_character': e,
        'source_krylov_sha256': hashlib.sha256(frozen.read_bytes()).hexdigest(),
        'source_krylov_recurrence': 556,
        'multiplier_degree_bound': 2,
        'canonical_active_degree3_frequencies': len(active),
        'touched_signed_graph_frequencies': len(touched),
        'missing_graph_frequencies': len(missing),
        'base_forced_zero_frequencies': sorted(forced),
        'singleton_witnesses': [
            {'frequency': missing[j], 'row': r, 'multiplier': u, 'signed_coefficient': s}
            for j, (r, u, s) in sorted(singleton.items())
        ],
        'eight_residual_frequencies': remaining_eight,
        'eight_coupled_generators': selected,
        'eight_matrix_rows_by_frequencies_columns_by_generators': matrix,
        'eight_determinant_integer': det,
        'graph_spanning_forest_edges': forest,
        'graph_frustrating_chords': chords,
        'graph_roots': roots,
        'status': 'EXACT_RATIONAL_FULL_DEGREE2_TRANSFER_SCHEME_FROM_SOURCE_IDENTITY',
        'scientific_limit': 'Source identity requires independent exact Krylov replay; no universal polynomial bound is inferred.'
    }


def verify(record):
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(1)
    assert record['extra_character'] == e and len(missing) == record['missing_graph_frequencies']
    forced, _ = forced_source_zero_coordinates(source, lift, labels, Q, canonical, missing)
    assert sorted(forced) == record['base_forced_zero_frequencies']
    signatures, _, singleton, _ = extra_generators(source, lift, labels, Q, e, canonical, missing)
    assert len(singleton) == len(record['singleton_witnesses'])
    for witness in record['singleton_witnesses']:
        q, r, u, s = (witness[k] for k in ('frequency', 'row', 'multiplier', 'signed_coefficient'))
        assert u in Q and u ^ e in Q
        assert singleton[missing.index(q)] == (r, u, s)
    rest = record['eight_residual_frequencies']
    assert set(rest) == set(missing) - forced - {w['frequency'] for w in record['singleton_witnesses']}
    matrix = record['eight_matrix_rows_by_frequencies_columns_by_generators']
    assert matrix == [[next((v for q, v in w['signature'] if q == freq), 0)
                       for w in record['eight_coupled_generators']] for freq in rest]
    for w in record['eight_coupled_generators']:
        r, u = w['row'], w['multiplier']
        assert u in Q and u ^ e in Q and r < len(source)
        coord = defaultdict(int)
        for z in (u, *(u ^ labels[col] for col in lift[r])):
            q, sign = canonical(z)
            if q in rest:
                coord[q] += sign
        assert {q:v for q,v in coord.items() if v} == dict(w['signature'])
    det = exact_determinant(matrix)
    assert det == record['eight_determinant_integer'] and det != 0
    _, _, row_edges = signed_graph(source, lift, labels, e)
    # Reconstruct independent full-rank signed forest and check the frozen
    # witness data byte-for-byte rather than trusting a listed edge count.
    forest, chords, roots = signed_forest(row_edges, Q, labels, canonical, touched)
    assert forest == record['graph_spanning_forest_edges']
    assert chords == record['graph_frustrating_chords']
    assert roots == record['graph_roots']
    return {
        'status': 'BABEL15_SEED1_EXACT_RATIONAL_TRANSFER_SCHEME_PASS',
        'source_degree2_identity': 'REPLAY_SEPARATELY',
        'singleton_witnesses': len(singleton),
        'base_forced_zero_frequencies': len(forced),
        'coupled_system_determinant': det,
        'coupled_system_dimension': len(rest),
        'frustrated_chords': len(chords),
        'signed_forest_edges': len(forest)
    }


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path)
    ap.add_argument('--verify', type=Path)
    args = ap.parse_args()
    record = json.loads(args.verify.read_text()) if args.verify else construct()
    result = verify(record)
    if args.output and not args.verify:
        args.output.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, indent=2, sort_keys=True), flush=True)
