#!/usr/bin/env python3
"""Expand BABEL-15 seed1 exact rational transfer scheme to full integers.

No floating point, prime field, or approximate optimization occurs here.
The sparse Fourier identity is checked over the unrestricted integers.
"""

import argparse
import gzip
import hashlib
import json
from collections import defaultdict, deque
from fractions import Fraction
from pathlib import Path

from janus_babel14_antisector_augmented import prepare
from janus_babel14_exact_transfer import edge_data
from janus_babel14_expand_exact import add, fourier
from janus_babel6_transfer import xor_labels, make_projection, signed_graph
from janus_babel8_krylov_verify import input_data, normal


def unimodular_integer_solve(matrix, rhs):
    n = len(matrix)
    a = [[Fraction(v) for v in row] + [Fraction(rhs[i])]
         for i, row in enumerate(matrix)]
    for k in range(n):
        pivot = next(i for i in range(k, n) if a[i][k])
        a[k], a[pivot] = a[pivot], a[k]
        scale = a[k][k]
        a[k] = [v / scale for v in a[k]]
        for i in range(n):
            if i == k or not a[i][k]:
                continue
            scale = a[i][k]
            a[i] = [a[i][j] - scale * a[k][j] for j in range(n + 1)]
    answer = [row[-1] for row in a]
    assert all(x.denominator == 1 for x in answer), 'unimodular integer solver failed'
    return [int(x) for x in answer]


def build(circuit_path, output_path):
    circuit = json.loads(circuit_path.read_text())
    assert circuit['seed'] == 1 and circuit['eight_determinant_integer'] == 1
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(1)
    source_rows, source_labels, source_basis, eq, origins = input_data(68)
    assert source_rows == source and source_labels == xor_labels(source)[0]
    polynomial_file = Path(__file__).with_name('babel9_BALANCED_BIT68_DEGREE4_KRYLOV.json')
    assert hashlib.sha256(polynomial_file.read_bytes()).hexdigest() == circuit['source_krylov_sha256']
    poly = json.loads(polynomial_file.read_text())['polynomial_coefficients_low_to_high']
    P0 = poly[0]
    v = [0] * 32768
    for step, c in enumerate(reversed(poly[1:])):
        v = normal(v, eq)
        v[0] += c
        if (step + 1) % 100 == 0:
            print(f'seed1 source integer Krylov Horner {step + 1}/{len(poly) - 1}', flush=True)
    check = normal(v, eq)
    assert check[0] == -P0 and not any(check[1:])

    n = len(source)
    pi, _ = make_projection(source_labels, labels, 15, 16)
    representatives = {}
    for u in sorted(Q):
        representatives.setdefault(pi(u), u)
    assert set(representatives) == set(source_basis)

    D = 4 * abs(P0)
    sign = -1 if P0 > 0 else 1
    terms = defaultdict(int)
    for a, b, c, d in eq:
        r, u = origins[(a, b, c, d)]
        coef = 4 * sign * (v[a] + v[b] + v[c] + v[d])
        if coef:
            add(terms, (r, representatives[u]), coef)
    print(f'seed1 lifted {len(terms)} base source terms', flush=True)
    H = fourier(terms, lift, labels)

    forced = set(circuit['base_forced_zero_frequencies'])
    assert len(forced) == 210
    for q in forced:
        assert H.get(q, 0) - H.get(q ^ e, 0) == 0

    def paired_correction(r, u, coef):
        if not coef:
            return
        add(terms, (r, u), coef)
        add(terms, (r, u ^ e), -coef)
        for z in (u, *(u ^ labels[k] for k in lift[r])):
            add(H, z, coef)
            add(H, z ^ e, -coef)

    eight = circuit['eight_residual_frequencies']
    matrix = circuit['eight_matrix_rows_by_frequencies_columns_by_generators']
    rhs = []
    for q in eight:
        anti = H.get(q, 0) - H.get(q ^ e, 0)
        assert anti % 2 == 0
        rhs.append(-anti // 2)
    eight_corrections = unimodular_integer_solve(matrix, rhs)
    for witness, k in zip(circuit['eight_coupled_generators'], eight_corrections):
        paired_correction(witness['row'], witness['multiplier'], k)
    assert all(H.get(q, 0) - H.get(q ^ e, 0) == 0 for q in eight)
    assert all(H.get(q, 0) - H.get(q ^ e, 0) == 0 for q in forced)

    for w in circuit['singleton_witnesses']:
        q, r, u, s = (w[key] for key in ('frequency', 'row', 'multiplier', 'signed_coefficient'))
        anti = H.get(q, 0) - H.get(q ^ e, 0)
        assert anti % (2 * s) == 0
        paired_correction(r, u, -anti // (2 * s))
        assert H.get(q, 0) - H.get(q ^ e, 0) == 0
    assert all(H.get(q, 0) - H.get(q ^ e, 0) == 0 for q in missing)
    print('seed1 all 826 off-graph anti-sector frequencies corrected', flush=True)

    _, _, edges = signed_graph(source, lift, labels, e)
    adjacency = defaultdict(list)
    for r, u in circuit['graph_spanning_forest_edges']:
        a, b, alpha, beta = edge_data(r, u, edges, labels, canonical)
        adjacency[a].append((b, alpha, beta, r, u))
        adjacency[b].append((a, beta, alpha, r, u))
    signs, parent, order, component = {}, {}, [], {}
    for root in circuit['graph_roots']:
        signs[root], parent[root], component[root] = 1, None, root
        todo = deque([root])
        while todo:
            q = todo.popleft()
            order.append(q)
            for other, alpha, beta, r, u in adjacency[q]:
                if other in signs:
                    continue
                signs[other] = -signs[q] * alpha * beta
                parent[other] = (q, alpha, beta, r, u)
                component[other] = root
                todo.append(other)
    assert set(signs) == touched
    b = {}
    for q in touched:
        difference = (D if q == 0 else 0) - (H.get(q, 0) - H.get(q ^ e, 0))
        assert difference % 2 == 0
        b[q] = difference // 2

    def add_row_difference(r, u, k):
        if k:
            add(terms, (r, u), k)
            add(terms, (r + n, u), -k)

    for r, u in circuit['graph_frustrating_chords']:
        a, z, alpha, beta = edge_data(r, u, edges, labels, canonical)
        root = component[a]
        assert root == component[z]
        denom = signs[a] * alpha + signs[z] * beta
        assert abs(denom) == 2
        total = sum(signs[q] * b[q] for q in order if component[q] == root)
        assert total % denom == 0
        k = total // denom
        b[a] -= k * alpha
        b[z] -= k * beta
        add_row_difference(r, u, k)
    for q in reversed(order):
        entry = parent[q]
        if entry is None:
            assert b[q] == 0
            continue
        p, alpha_parent, beta_child, r, u = entry
        k = b[q] * beta_child
        b[p] -= k * alpha_parent
        b[q] = 0
        add_row_difference(r, u, k)

    final = fourier(terms, lift, labels)
    assert final == {0: D}, ('unexpected final support', len(final))
    print(f'SEED1 EXACT FULL IDENTITY: {len(terms)} terms, {len(str(D))} normalization digits', flush=True)
    with gzip.open(output_path, 'wt', encoding='utf-8', compresslevel=6) as out:
        json.dump({'format': 'JANUS_BABEL15_SEED1_EXPLICIT_INTEGER_IDENTITY_V1',
                   'seed': 1, 'degree2': True, 'n': 252, 'terms_count': len(terms),
                   'positive_integer_normalization_D': str(D),
                   'terms': [[r, u, str(c)] for (r, u), c in sorted(terms.items())]},
                  out, sort_keys=True, separators=(',', ':'))
    return {'status': 'BABEL15_SEED1_EXACT_RATIONAL_DEGREE2_IDENTITY_PASS',
            'seed': 1, 'coefficients': len(terms),
            'normalization_digits': len(str(D)),
            'exact_all_frequency_identity': True,
            'expanded_sha256': hashlib.sha256(output_path.read_bytes()).hexdigest()}


def independent_verify(expanded):
    _, lift, labels, Q, _, _, _, _, _ = prepare(1)
    with gzip.open(expanded, 'rt', encoding='utf-8') as infile:
        cert = json.load(infile)
    assert cert['format'] == 'JANUS_BABEL15_SEED1_EXPLICIT_INTEGER_IDENTITY_V1'
    D = int(cert['positive_integer_normalization_D'])
    assert D > 0 and len(cert['terms']) == cert['terms_count']
    sums = defaultdict(int)
    for r, u, v in cert['terms']:
        assert 0 <= r < 252 and u in Q
        c = int(v)
        add(sums, u, c)
        for k in lift[r]:
            add(sums, u ^ labels[k], c)
    assert sums == {0: D}, ('all-frequency independent replay failure', len(sums))
    return {'status': 'BABEL15_SEED1_INDEPENDENT_EXACT_FOURIER_REPLAY_PASS',
            'coefficients': cert['terms_count'], 'positive_integer_normalization': True}


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--circuit', type=Path,
                    default=Path(__file__).with_name('babel15_SEED1_EXACT_RATIONAL_TRANSFER_SCHEME.json'))
    ap.add_argument('--output', type=Path,
                    default=Path(__file__).with_name('babel15_SEED1_EXPLICIT_INTEGER_IDENTITY.json.gz'))
    ap.add_argument('--report', type=Path)
    ap.add_argument('--verify-only', action='store_true')
    args = ap.parse_args()
    result = independent_verify(args.output) if args.verify_only else build(args.circuit, args.output)
    if args.report:
        args.report.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True, indent=2), flush=True)
