#!/usr/bin/env python3
"""BABEL-15: exact structural audit of the missing anti-deck sector.

This is a *necessary-scope* test for a source-certificate transfer. A full
projected rank result modulo a prime proves rational surjectivity of these
correction generators, but is not by itself an explicit SOS certificate.
"""

import argparse
import json
from collections import Counter
from pathlib import Path

from janus_babel14_antisector_augmented import prepare, extra_generators, modular_rank
from janus_babel6_transfer import xor_labels, make_projection


def forced_source_zero_coordinates(source, lift, labels, Q, canonical, missing):
    source_labels, base_Q, dim = xor_labels(source)
    pi, _ = make_projection(source_labels, labels, dim, dim + 1)
    representatives = {}
    for u in sorted(Q):
        representatives.setdefault(pi(u), u)
    assert set(representatives) == base_Q

    target = set(missing)
    orientations = {q: set() for q in missing}
    occurrences = Counter()
    for r, row in enumerate(lift[:len(source)]):
        for u in representatives.values():
            for z in (u, *(u ^ labels[v] for v in row)):
                q, sign = canonical(z)
                if q in target:
                    orientations[q].add(sign)
                    occurrences[q] += 1
    forced = {
        q for q in missing
        if pi(q) != 0 and len(orientations[q]) == 1 and occurrences[q] > 0
    }
    return forced, {
        'missing_with_no_source_occurrences': sum(not occurrences[q] for q in missing),
        'missing_with_mixed_source_orientations': sum(len(orientations[q]) > 1 for q in missing),
        'missing_with_zero_base_projection': sum(pi(q) == 0 for q in missing),
    }


def audit(seed):
    source, lift, labels, Q, e, canonical, touched, active, missing = prepare(seed)
    print(f'seed {seed}: missing {len(missing)} / active {len(active)}', flush=True)
    signatures, supports, singleton, generator_count = extra_generators(
        source, lift, labels, Q, e, canonical, missing
    )
    forced, classification = forced_source_zero_coordinates(
        source, lift, labels, Q, canonical, missing
    )
    remaining = [q for q in missing if q not in forced]
    rem_index = {q: i for i, q in enumerate(remaining)}
    rem_sig = {}
    for sig in signatures:
        projected = tuple(sorted((rem_index[missing[j]], value)
                                 for j, value in sig if missing[j] in rem_index))
        if projected:
            rem_sig.setdefault(projected, (0, 0))
    rank, scanned, pivots = modular_rank(rem_sig, len(remaining))
    all_rank, _, _ = modular_rank(signatures, len(missing))
    result = {
        'gate': 'BABEL-15',
        'seed': seed,
        'row_multiplier_degree_bound': 2,
        'active_canonical_degree3_frequencies': len(active),
        'graph_touched': len(touched),
        'graph_missing': len(missing),
        'paired_generators_scanned': generator_count,
        'projected_paired_signatures': len(signatures),
        'projected_pair_only_rank_lower_bound_mod65521': all_rank,
        'singleton_coverage': len(singleton),
        'base_forced_zero_frequencies': len(forced),
        'remaining_after_base_zero_quotient': len(remaining),
        'projected_rank_after_quotient_mod65521': rank,
        'rational_spanning_certified_by_modular_minor': rank == len(remaining),
        'base_frequency_classification': classification,
        'status': ('ANTISECTOR_TRANSFER_SUBSPACE_SPANS_EXACT_Q'
                   if rank == len(remaining) else
                   'FULL_RATIONAL_RANK_NOT_YET_CERTIFIED'),
        'qualification': 'Modular full rank proves rational full rank. Modular rank deficiency alone does NOT prove rational deficiency. No conclusion yet for the full ideal without a complete lifted identity or rational left-kernel witness.'
    }
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = audit(args.seed)
    if args.output:
        args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n')
    print(json.dumps(report, sort_keys=True, indent=2), flush=True)
