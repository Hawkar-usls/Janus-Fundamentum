#!/usr/bin/env python3
"""BABEL-15 exact seed1 regression; scientific claims are seed-local."""

import json
import unittest
from pathlib import Path

from janus_babel10_degree_scan import frozen_instances
from janus_babel10_lift_family import audit, make_lift
from janus_babel10_transfer_lower import exact_base_lower_functional, verify_lift
from janus_babel15_seed1_transfer import verify as verify_compact
from janus_babel15_seed1_expand_exact import independent_verify, unimodular_integer_solve

HERE = Path(__file__).resolve().parent


class Babel15Exact(unittest.TestCase):
    def test_01_frozen_seed1_is_legal_unsat(self):
        result, _ = audit('SCL126_flip68', frozen_instances()['SCL126_flip68'], 1)
        self.assertTrue(result['legal_linear_cubic'])
        self.assertTrue(result['connected'])
        self.assertEqual(result['GF2_nullity'], 16)
        self.assertEqual(result['exact_SAT_count'], 0)
        self.assertEqual(result['checked_kernel_states'], 65536)

    def test_02_exact_rational_transfer_scheme(self):
        record = json.loads((HERE / 'babel15_SEED1_EXACT_RATIONAL_TRANSFER_SCHEME.json').read_text())
        result = verify_compact(record)
        self.assertEqual(result['status'], 'BABEL15_SEED1_EXACT_RATIONAL_TRANSFER_SCHEME_PASS')
        self.assertEqual(result['singleton_witnesses'], 608)
        self.assertEqual(result['base_forced_zero_frequencies'], 210)
        self.assertEqual(result['coupled_system_determinant'], 1)
        self.assertEqual(result['frustrated_chords'], 2)
        matrix = record['eight_matrix_rows_by_frequencies_columns_by_generators']
        vector = [2, -1, 4, 0, -3, 1, 2, 5]
        rhs = [sum(row[i] * vector[i] for i in range(8)) for row in matrix]
        self.assertEqual(unimodular_integer_solve(matrix, rhs), vector)

    def test_03_source_recurrence_independent_record(self):
        report = json.loads((HERE / 'babel14_SEED2_SOURCE_KRYLOV_REPLAY.json').read_text())
        self.assertEqual(report['exact_integer_frequency_replay'], 'PASS')
        self.assertEqual(report['recurrence_degree'], 556)

    def test_04_exact_lower_degree_obstruction_for_seed1(self):
        src, labels, dimension, functional = exact_base_lower_functional()
        proof = verify_lift(src, labels, dimension, functional, make_lift(src, 1)[0])
        self.assertEqual(proof['degree1_row_generators_checked'], 23862)
        self.assertEqual(proof['SOS_degree_less_than_4'], 'EXCLUDED')

    def test_05_independent_full_integer_frequency_identity(self):
        report = independent_verify(HERE / 'babel15_SEED1_EXPLICIT_INTEGER_IDENTITY.json.gz')
        self.assertEqual(report['status'], 'BABEL15_SEED1_INDEPENDENT_EXACT_FOURIER_REPLAY_PASS')
        self.assertEqual(report['coefficients'], 185726)


if __name__ == '__main__':
    unittest.main(verbosity=2)
